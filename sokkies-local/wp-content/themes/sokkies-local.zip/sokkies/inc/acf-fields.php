<?php
/**
 * Sokkies — ACF-veldgroepen, geregistreerd via PHP (geen sync nodig; de
 * definitie leeft in code en loopt automatisch in de pas met de partials).
 * Elke nieuwe sectie-layout = één entry in 'layouts' + één partial in
 * template-parts/sections/section-{naam}.php.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'acf/init', function () {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	acf_add_local_field_group( array(
		'key'      => 'group_sokkies_secties',
		'title'    => 'Secties',
		'fields'   => array(
			array(
				'key'          => 'field_sokkies_secties',
				'label'        => 'Secties',
				'name'         => 'secties',
				'type'         => 'flexible_content',
				'instructions' => 'Bouw de pagina op uit secties. Sleep om te herordenen.',
				'button_label' => 'Sectie toevoegen',
				// ACF Extended (indien actief): popup-kiezer met categorieën + thumbnails
				'acfe_flexible_advanced'           => 1,
				'acfe_flexible_stylised_button'    => 1,
				'acfe_flexible_layouts_thumbnails' => 1,
				'acfe_flexible_modal'              => array(
					'acfe_flexible_modal_enabled'    => '1',
					'acfe_flexible_modal_title'      => 'Kies een sectie',
					'acfe_flexible_modal_size'       => 'full',
					'acfe_flexible_modal_col'        => '3',
					'acfe_flexible_modal_categories' => '1',
				),
				'layouts'      => array(

					'layout_hero' => array(
						'key'        => 'layout_hero',
						'name'       => 'hero',
						'label'      => 'Paginakop (kruimelpad + titel)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Paginakoppen' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/hero.png',
						'sub_fields' => array(
							array(
								'key'           => 'field_hero_breadcrumb_tonen',
								'label'         => 'Kruimelpad tonen',
								'name'          => 'breadcrumb_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
								'instructions'  => 'Uit op de homepage.',
							),
							array(
								'key'          => 'field_hero_breadcrumb',
								'label'        => 'Kruimelpad-label',
								'name'         => 'breadcrumb',
								'type'         => 'text',
								'instructions' => 'Leeg = paginatitel.',
							),
							array(
								'key'          => 'field_hero_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Het gele deel zet je tussen [ ] óf in <span>…</span>: bijv. "[Hoe duurzaam] zijn we nu écht?". Regelafbraak mag met <br>. Leeg = paginatitel.',
							),
							array(
								'key'          => 'field_hero_subtekst',
								'label'        => 'Subtekst',
								'name'         => 'subtekst',
								'type'         => 'textarea',
								'rows'         => 2,
								'new_lines'    => '',
								'instructions' => 'Optioneel. Een nieuwe regel in dit veld wordt een regelafbraak op de site.',
							),
							array(
								'key'           => 'field_hero_stijl',
								'label'         => 'Kleurstelling',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'instructions'  => 'De achtergrondkleur volgt het paginaontwerp; deze keuze stuurt de kleur van het huisje-icoon in het kruimelpad.',
								'choices'       => array(
									'coral' => 'Coral (witte tekst)',
									'beige' => 'Beige (donkere tekst)',
								),
								'default_value' => 'coral',
							),
							array(
								'key'          => 'field_hero_usps',
								'label'        => 'Pluspunten (regel onder de titel)',
								'name'         => 'usps',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Pluspunt toevoegen',
								'instructions' => 'Optioneel — de vinkjesregel zoals op de homepage en de offertepagina.',
								'sub_fields'   => array(
									array( 'key' => 'field_hero_usp_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
								),
							),
							array(
								'key'           => 'field_hero_rating',
								'label'         => 'Review-score tonen',
								'name'          => 'rating_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 0,
								'instructions'  => 'Score en aantal komen uit Website-instellingen.',
							),
							array(
								'key'          => 'field_hero_knop_1',
								'label'        => 'Knop 1 (geel)',
								'name'         => 'knop_1',
								'type'         => 'link',
								'instructions' => 'Optioneel.',
							),
							array(
								'key'          => 'field_hero_knop_2',
								'label'        => 'Knop 2 (wit)',
								'name'         => 'knop_2',
								'type'         => 'link',
								'instructions' => 'Optioneel. De tweede knop is de secundaire CTA: "Zelf ontwerpen" naar de configurator.',
							),
							array(
								'key'          => 'field_hero_onderregel_tekst',
								'label'        => 'Onderregel (tekst)',
								'name'         => 'onderregel_tekst',
								'type'         => 'text',
								'instructions' => 'Optioneel — de kleine regel onder de knoppen, bijv. "Eigen ontwerp?". Staat op de configuratorpagina; op de homepage is hij bewust leeg (2026-08-25).',
							),
							array(
								'key'          => 'field_hero_onderregel_link',
								'label'        => 'Onderregel (link)',
								'name'         => 'onderregel_link',
								'type'         => 'link',
								'instructions' => 'Optioneel — de link achter de onderregel, bijv. "Klik hier voor de templates" naar /downloads/. De templates staan ook in de footer onder Downloads &amp; templates.',
							),
							array(
								'key'           => 'field_hero_variant',
								'label'         => 'Variant',
								'name'          => 'variant',
								'type'          => 'button_group',
								'choices'       => array(
									'standaard'    => 'Standaard',
									'offerte'      => 'Compact (offertepagina)',
									'configurator' => 'Configurator',
								),
								'default_value' => 'standaard',
							),
							array(
								'key'           => 'field_hero_fotos',
								'label'         => 'Fotoslider onder de titel',
								'name'          => 'fotos',
								'type'          => 'gallery',
								'return_format' => 'array',
								'preview_size'  => 'thumbnail',
								'insert'        => 'append',
								'instructions'  => 'Optioneel — de schuine fotoslider zoals op de homepage. Foto\'s hier plaatsen zet hem aan. Aanbevolen: 850 x 1120 px per foto (staand, 3:4).',
							),
						),
					),

					'layout_coll_hero' => array(
						'key'        => 'layout_coll_hero',
						'name'       => 'coll_hero',
						'label'      => 'Paginakop met fotokolommen',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Paginakoppen' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/coll_hero.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_collhero_breadcrumb',
								'label'        => 'Kruimelpad-label',
								'name'         => 'breadcrumb',
								'type'         => 'text',
								'instructions' => 'Leeg = paginatitel.',
							),
							array(
								'key'          => 'field_collhero_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Geel deel tussen [ ] óf in <span>…</span>; regelafbraak met <br>. Leeg = paginatitel.',
							),
							array(
								'key'          => 'field_collhero_subtekst',
								'label'        => 'Subtekst',
								'name'         => 'subtekst',
								'type'         => 'textarea',
								'rows'         => 2,
								'new_lines'    => '',
								'instructions' => 'Optioneel. Een nieuwe regel wordt een regelafbraak.',
							),
							array(
								'key'          => 'field_collhero_knop_1',
								'label'        => 'Knop 1 (geel)',
								'name'         => 'knop_1',
								'type'         => 'link',
								'instructions' => 'Optioneel. Origineel op Collectie: "Gratis ontwerp aanvragen" naar de offertepagina.',
							),
							array(
								'key'          => 'field_collhero_knop_2',
								'label'        => 'Knop 2 (transparant)',
								'name'         => 'knop_2',
								'type'         => 'link',
								'instructions' => 'Optioneel. Origineel op Collectie: "Open configurator".',
							),
							array(
								'key'          => 'field_collhero_usps',
								'label'        => 'Pluspunten',
								'name'         => 'usps',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Pluspunt toevoegen',
								'instructions' => 'Optioneel — het lijstje onder de knoppen (Collectie heeft er 6).',
								'sub_fields'   => array(
									array(
										'key'   => 'field_collhero_usp_tekst',
										'label' => 'Tekst',
										'name'  => 'tekst',
										'type'  => 'text',
									),
								),
							),
							array(
								'key'           => 'field_collhero_fotos_1',
								'label'         => 'Fotokolom links',
								'name'          => 'fotos_kolom_1',
								'type'          => 'gallery',
								'return_format' => 'array',
								'preview_size'  => 'thumbnail',
								'insert'        => 'append',
								'instructions'  => 'Verticale fotoslider links. Leeg = standaardset. 4 foto\'s is het ritme van het origineel. Aanbevolen: 910 x 1160 px per foto (staand, 4:5).',
							),
							array(
								'key'           => 'field_collhero_fotos_2',
								'label'         => 'Fotokolom rechts',
								'name'          => 'fotos_kolom_2',
								'type'          => 'gallery',
								'return_format' => 'array',
								'preview_size'  => 'thumbnail',
								'insert'        => 'append',
								'instructions'  => 'Verticale fotoslider rechts (loopt tegengesteld). Leeg = standaardset. Aanbevolen: 910 x 1160 px per foto (staand, 4:5).',
							),
						),
					),

					'layout_simple_hero' => array(
						'key'        => 'layout_simple_hero',
						'name'       => 'simple_hero',
						'label'      => 'Paginakop licht (beige, gecentreerd)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Paginakoppen' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/simple_hero.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_sh_breadcrumb',
								'label'        => 'Kruimelpad-label',
								'name'         => 'breadcrumb',
								'type'         => 'text',
								'instructions' => 'Leeg = "Reviews en cases".',
							),
							array(
								'key'          => 'field_sh_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Zet [woord] om een woord geel te maken. Leeg = "Zo pakte het uit voor anderen".',
							),
							array(
								'key'          => 'field_sh_subtekst',
								'label'        => 'Subtekst',
								'name'         => 'subtekst',
								'type'         => 'textarea',
								'rows'         => 2,
								'new_lines'    => '',
								'instructions' => 'Elke regel wordt een eigen regel op de site. Leeg = de standaardtekst.',
							),
						),
					),

					'layout_faq' => array(
						'key'        => 'layout_faq',
						'name'       => 'faq',
						'label'      => 'Veelgestelde vragen (accordeon)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Veelgestelde vragen' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/faq.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_faq_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Geel deel tussen [ ] óf in <span>…</span>; regelafbraak met <br>. Leeg = standaardtitel.',
							),
							array(
								'key'           => 'field_faq_intro',
								'label'         => 'Introtekst (linkerkolom)',
								'name'          => 'intro',
								'type'          => 'wysiwyg',
								'tabs'          => 'all',
								'toolbar'       => 'basic',
								'media_upload'  => 0,
								'instructions'  => 'De tekst links naast de vragen; links naar andere pagina\'s mogen.',
								'default_value' => '<p>De meeste vragen staan hier of op de <a href="' . home_url( '/veelgestelde-vragen/' ) . '">FAQ-pagina</a>. Mist er nog iets, laat het weten. Duidelijkheid is schaars, dus we doen ons best.</p><p>Staat je vraag er niet tussen? Neem <a href="' . home_url( '/contact/' ) . '">contact</a> op, dan kijken we mee.</p>',
							),
							array(
								'key'           => 'field_faq_stijl',
								'label'         => 'Achtergrond',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'choices'       => array(
									'standaard' => 'Beige (standaard)',
									'licht'     => 'Licht (offertepagina)',
								),
								'default_value' => 'standaard',
							),
							array(
								'key'           => 'field_faq_bron',
								'label'         => 'Welke vragen tonen?',
								'name'          => 'bron',
								'type'          => 'button_group',
								'choices'       => array(
									'kies'      => 'Zelf kiezen',
									'categorie' => 'Alles uit één categorie',
								),
								'default_value' => 'kies',
							),
							array(
								'key'               => 'field_faq_categorie',
								'label'             => 'Categorie',
								'name'              => 'categorie',
								'type'              => 'taxonomy',
								'taxonomy'          => 'sokkies_faq_cat',
								'field_type'        => 'select',
								'add_term'          => 0,
								'save_terms'        => 0,
								'load_terms'        => 0,
								'return_format'     => 'id',
								'instructions'      => 'Alle vragen uit deze categorie worden getoond.',
								'conditional_logic' => array( array( array( 'field' => 'field_faq_bron', 'operator' => '==', 'value' => 'categorie' ) ) ),
							),
							array(
								'key'          => 'field_faq_vragen',
								'label'        => 'Vragen',
								'name'         => 'vragen',
								'type'         => 'relationship',
								'post_type'    => array( 'sokkies_faq' ),
								'filters'      => array( 'search' ),
								'return_format' => 'id',
								'conditional_logic' => array( array( array( 'field' => 'field_faq_bron', 'operator' => '==', 'value' => 'kies' ) ) ),
								'instructions' => 'Kies de vragen en sleep ze in de gewenste volgorde. Leeg = de 8 nieuwste vragen. Nieuwe vragen maak je aan onder "Veelgestelde vragen" in het menu links.',
							),
							array(
								'key'           => 'field_faq_eerste_open',
								'label'         => 'Eerste vraag standaard open',
								'name'          => 'eerste_open',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
							),
							array(
								'key'           => 'field_faq_link_alle',
								'label'         => 'Link "Bekijk alle vragen" tonen',
								'name'          => 'link_alle_vragen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
							),
						),
					),

					'layout_collection' => array(
						'key'        => 'layout_collection',
						'name'       => 'collection',
						'label'      => 'Sokkencollectie (kaartenrij)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Collectie' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/collection.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_coll_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Geel deel tussen [ ] óf in <span>…</span>. Leeg = "Onze sokken collectie".',
							),
							array(
								'key'           => 'field_coll_stijl',
								'label'         => 'Achtergrond',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'choices'       => array(
									'standaard' => 'Gele golf (home)',
									'beige'     => 'Beige vlak',
									'patroon'   => 'Wit met sokkenpatroon en blauwe golf (configurator)',
								),
								'default_value' => 'standaard',
							),
							array(
								'key'           => 'field_coll_soktypes',
								'label'         => 'Soktypes (maximaal 4)',
								'name'          => 'soktypes',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_soktype' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'max'           => 4,
								'instructions'  => 'De kaartenrij is ontworpen voor precies 4 kaarten — kies er maximaal 4 en sleep ze in volgorde. Leeg = de 4 nieuwste. Alle 10 typen tonen? Gebruik de layout "Alle soktypes (grid met beschrijving)".',
							),
							array(
								'key'           => 'field_coll_knop_tonen',
								'label'         => 'Knop onder de kaarten tonen',
								'name'          => 'knop_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
							),
							array(
								'key'               => 'field_coll_knop',
								'label'             => 'Knop',
								'name'              => 'knop',
								'type'              => 'link',
								'instructions'      => 'Leeg = "Bekijk collectie" naar de collectiepagina.',
								'conditional_logic' => array( array( array( 'field' => 'field_coll_knop_tonen', 'operator' => '==', 'value' => '1' ) ) ),
							),
						),
					),

					'layout_types_grid' => array(
						'key'        => 'layout_types_grid',
						'name'       => 'types_grid',
						'label'      => 'Alle soktypes (grid met beschrijving)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Collectie' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/types_grid.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_tg_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Alle sokken types". De teller ("10 resultaten") telt vanzelf mee.',
							),
							array(
								'key'           => 'field_tg_soktypes',
								'label'         => 'Soktypes',
								'name'          => 'soktypes',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_soktype' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'instructions'  => 'Leeg = álle soktypes.',
							),
						),
					),

					'layout_cards_suggestion' => array(
						'key'        => 'layout_cards_suggestion',
						'name'       => 'cards_suggestion',
						'label'      => 'Soktypes-slider (Bekijk ook deze)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Collectie' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/cards_suggestion.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_cs_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Bekijk ook deze".',
							),
							array(
								'key'           => 'field_cs_soktypes',
								'label'         => 'Soktypes',
								'name'          => 'soktypes',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_soktype' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'instructions'  => 'Leeg = de 8 nieuwste. Tip: kies hier de ándere types dan die op de pagina zelf staan.',
							),
							array(
								'key'           => 'field_cs_knop_tonen',
								'label'         => 'Knop rechtsboven tonen',
								'name'          => 'knop_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
								'instructions'  => 'Uit = alleen de titel boven de kaarten (landingspagina).',
							),
							array(
								'key'               => 'field_cs_knop',
								'label'             => 'Knop rechtsboven',
								'name'              => 'knop',
								'type'              => 'link',
								'instructions'      => 'Leeg = "Bekijk alle sokken" naar de collectiepagina.',
								'conditional_logic' => array( array( array( 'field' => 'field_cs_knop_tonen', 'operator' => '==', 'value' => '1' ) ) ),
							),
						),
					),

					'layout_faq_geel' => array(
						'key'        => 'layout_faq_geel',
						'name'       => 'faq_geel',
						'label'      => 'Veelgestelde vragen (geel, gecentreerd)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Veelgestelde vragen' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/faq_geel.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_fg_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Veelgestelde vragen".',
							),
							array(
								'key'           => 'field_fg_bron',
								'label'         => 'Welke vragen tonen?',
								'name'          => 'bron',
								'type'          => 'button_group',
								'choices'       => array(
									'kies'      => 'Zelf kiezen',
									'categorie' => 'Alles uit één categorie',
								),
								'default_value' => 'kies',
							),
							array(
								'key'               => 'field_fg_categorie',
								'label'             => 'Categorie',
								'name'              => 'categorie',
								'type'              => 'taxonomy',
								'taxonomy'          => 'sokkies_faq_cat',
								'field_type'        => 'select',
								'add_term'          => 0,
								'save_terms'        => 0,
								'load_terms'        => 0,
								'return_format'     => 'id',
								'conditional_logic' => array( array( array( 'field' => 'field_fg_bron', 'operator' => '==', 'value' => 'categorie' ) ) ),
							),
							array(
								'key'               => 'field_fg_vragen',
								'label'             => 'Vragen',
								'name'              => 'vragen',
								'type'              => 'relationship',
								'post_type'         => array( 'sokkies_faq' ),
								'filters'           => array( 'search' ),
								'return_format'     => 'id',
								'conditional_logic' => array( array( array( 'field' => 'field_fg_bron', 'operator' => '==', 'value' => 'kies' ) ) ),
								'instructions'      => 'Leeg = de 8 nieuwste vragen.',
							),
						),
					),

					'layout_cta_formulier' => array(
						'key'        => 'layout_cta_formulier',
						'name'       => 'cta_formulier',
						'label'      => 'Actieblok met formulier (Mis niets)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Actieblokken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/cta_formulier.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_cf_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Mis [niets]". Geel deel tussen [ ].',
							),
							array(
								'key'          => 'field_cf_subtekst',
								'label'        => 'Subtekst',
								'name'         => 'subtekst',
								'type'         => 'textarea',
								'rows'         => 2,
								'new_lines'    => '',
								'instructions' => 'Leeg = standaardtekst. Het formulier is nog een demo — echte verzending komt met de formulierenfase.',
							),
						),
					),

					'layout_brands' => array(
						'key'        => 'layout_brands',
						'name'       => 'brands',
						'label'      => 'Merkenstrip (logo-loop)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Merken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/brands.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_brands_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Gebruikt door bedrijven in heel Europa".',
							),
							array(
								'key'           => 'field_brands_stijl',
								'label'         => 'Achtergrond',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'choices'       => array(
									'standaard' => 'Standaard (wit)',
									'beige'     => 'Beige vlak',
									'inner'     => 'Compact (offertepagina)',
								),
								'default_value' => 'standaard',
							),
							array(
								'key'           => 'field_brands_logos',
								'label'         => 'Logo\'s',
								'name'          => 'logos',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_logo' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'instructions'  => 'Leeg = álle logo\'s. De strip loopt vanzelf oneindig door. Logo\'s beheer je onder "Merklogo\'s" in het menu links.',
							),
						),
					),

					'layout_process' => array(
						'key'        => 'layout_process',
						'name'       => 'process',
						'label'      => 'Stappenblok (4 stappen met iconen)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Werkwijze' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/process.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_pr_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = de standaardtitel. Geel deel tussen [ ], regelafbraak met <br>.',
							),
							array(
								'key'          => 'field_pr_stappen',
								'label'        => 'Stappen',
								'name'         => 'stappen',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Stap toevoegen',
								'instructions' => 'Leeg = de vier standaardstappen. Nummers (01, 02, …) tellen vanzelf.',
								'sub_fields'   => array(
									array( 'key' => 'field_pr_stap_icoon', 'label' => 'Icoon', 'name' => 'icoon', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'instructions' => 'Vierkant icoon (SVG of PNG). Aanbevolen: 200 x 200 px, of een SVG.' ),
									array( 'key' => 'field_pr_stap_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_pr_stap_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
								),
							),
							array(
								'key'          => 'field_pr_knop',
								'label'        => 'Knop',
								'name'         => 'knop',
								'type'         => 'link',
								'instructions' => 'Leeg = "Gratis ontwerp aanvragen" naar de offertepagina.',
							),
						),
					),

					'layout_process_split' => array(
						'key'        => 'layout_process_split',
						'name'       => 'process_split',
						'label'      => 'Stappen met fotocollage',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Werkwijze' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/process_split.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_ps_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = de standaardtitel van de gekozen variant.',
							),
							array(
								'key'           => 'field_ps_stijl',
								'label'         => 'Variant',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'choices'       => array(
									'standaard'    => 'Standaard (knop onder de stappen)',
									'configurator' => 'Configurator (titel boven + contactblok)',
									'landing'      => 'Landingspagina (rood vlak + actiekaart)',
								),
								'default_value' => 'standaard',
							),
							array(
								'key'          => 'field_ps_stappen',
								'label'        => 'Stappen',
								'name'         => 'stappen',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Stap toevoegen',
								'instructions' => 'Leeg = de standaardstappen van de gekozen variant.',
								'sub_fields'   => array(
									array( 'key' => 'field_ps_stap_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_ps_stap_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
								),
							),
							array(
								'key'               => 'field_ps_knop',
								'label'             => 'Knop',
								'name'              => 'knop',
								'type'              => 'link',
								'instructions'      => 'Leeg = "Gratis ontwerp aanvragen" naar de offertepagina.',
								'conditional_logic' => array( array( array( 'field' => 'field_ps_stijl', 'operator' => '==', 'value' => 'standaard' ) ) ),
							),
							array(
								'key'               => 'field_ps_contact_kop',
								'label'             => 'Contactblok — kop',
								'name'              => 'contact_kop',
								'type'              => 'text',
								'instructions'      => 'Leeg = standaard. Het rode deel zet je tussen [ ].',
								'conditional_logic' => array( array( array( 'field' => 'field_ps_stijl', 'operator' => '==', 'value' => 'configurator' ) ) ),
							),
							array(
								'key'               => 'field_ps_contact_tekst',
								'label'             => 'Contactblok — tekst',
								'name'              => 'contact_tekst',
								'type'              => 'textarea',
								'rows'              => 2,
								'new_lines'         => '',
								'conditional_logic' => array( array( array( 'field' => 'field_ps_stijl', 'operator' => '==', 'value' => 'configurator' ) ) ),
							),
							array(
								'key'               => 'field_ps_contact_sub',
								'label'             => 'Contactblok — regel boven de knoppen',
								'name'              => 'contact_sub',
								'type'              => 'text',
								'instructions'      => 'De contactknoppen (e-mail/bellen/WhatsApp) gebruiken Website-instellingen.',
								'conditional_logic' => array( array( array( 'field' => 'field_ps_stijl', 'operator' => '==', 'value' => 'configurator' ) ) ),
							),
							array(
								'key'               => 'field_ps_land_kop',
								'label'             => 'Actiekaart — kop',
								'name'              => 'land_kop',
								'type'              => 'text',
								'instructions'      => 'De beige kaart onder de stappen. Leeg = "Klaar voor je ontwerp?". Het rode deel zet je tussen [ ].',
								'conditional_logic' => array( array( array( 'field' => 'field_ps_stijl', 'operator' => '==', 'value' => 'landing' ) ) ),
							),
							array(
								'key'               => 'field_ps_land_knop',
								'label'             => 'Actiekaart — knop',
								'name'              => 'land_knop',
								'type'              => 'link',
								'instructions'      => 'Leeg = de standaardknop naar de offertepagina.',
								'conditional_logic' => array( array( array( 'field' => 'field_ps_stijl', 'operator' => '==', 'value' => 'landing' ) ) ),
							),
							array(
								'key'           => 'field_ps_collage',
								'label'         => 'Fotocollage rechts',
								'name'          => 'collage',
								'type'          => 'gallery',
								'return_format' => 'array',
								'preview_size'  => 'thumbnail',
								'insert'        => 'append',
								'instructions'  => '4 foto\'s is het ritme van het origineel. Leeg = de standaardset van de gekozen variant. Aanbevolen: 830 x 830 px per foto (vierkant).',
							),
						),
					),

					'layout_impact' => array(
						'key'        => 'layout_impact',
						'name'       => 'impact',
						'label'      => 'Cijferblok met fotocollage (geel)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Cijfers' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/impact.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_im_stats',
								'label'        => 'Cijfers',
								'name'         => 'stats',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Cijfer toevoegen',
								'instructions' => 'Leeg = "5.000+ Bedrijven geholpen" en "1.000.000+ paar geproduceerd".',
								'sub_fields'   => array(
									array( 'key' => 'field_im_stat_getal', 'label' => 'Getal', 'name' => 'getal', 'type' => 'text' ),
									array( 'key' => 'field_im_stat_label', 'label' => 'Label', 'name' => 'label', 'type' => 'text' ),
								),
							),
							array(
								'key'          => 'field_im_beschrijving',
								'label'        => 'Beschrijving',
								'name'         => 'beschrijving',
								'type'         => 'textarea',
								'rows'         => 2,
								'new_lines'    => '',
								'instructions' => 'Leeg = standaardtekst.',
							),
							array(
								'key'           => 'field_im_fotos',
								'label'         => 'Foto\'s (3 schuivende kolommen)',
								'name'          => 'fotos',
								'type'          => 'gallery',
								'return_format' => 'array',
								'preview_size'  => 'thumbnail',
								'insert'        => 'append',
								'instructions'  => 'Leeg = standaardset. Foto\'s worden automatisch over de 3 kolommen verdeeld. Aanbevolen: 580 x 840 px per foto (staand, 7:10).',
							),
							array(
								'key'           => 'field_im_chips_tonen',
								'label'         => 'Pluspunten-rij tonen',
								'name'          => 'pluspunten_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
								'instructions'  => 'Uit = de Over ons-weergave (alleen cijfers + foto\'s).',
							),
							array(
								'key'               => 'field_im_chips',
								'label'             => 'Pluspunten',
								'name'              => 'pluspunten',
								'type'              => 'repeater',
								'layout'            => 'table',
								'button_label'      => 'Pluspunt toevoegen',
								'max'               => 6,
								'instructions'      => 'Maximaal 6 (het ontwerp is één rij). Leeg = de zes standaardchips met hun iconen.',
								'conditional_logic' => array( array( array( 'field' => 'field_im_chips_tonen', 'operator' => '==', 'value' => '1' ) ) ),
								'sub_fields'        => array(
									array( 'key' => 'field_im_chip_icoon', 'label' => 'Icoon', 'name' => 'icoon', 'type' => 'image', 'instructions' => 'Aanbevolen: 100 x 100 px, of een SVG.', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_im_chip_label', 'label' => 'Tekst', 'name' => 'label', 'type' => 'text' ),
								),
							),
						),
					),

					'layout_calculator' => array(
						'key'        => 'layout_calculator',
						'name'       => 'calculator',
						'label'      => 'Prijscalculator met staffeltabel',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Prijzen' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/calculator.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_calc_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Wat kost het?". De prijzen zelf beheer je onder Website-instellingen → Prijzen & staffels.',
							),
							array(
								'key'           => 'field_calc_stijl',
								'label'         => 'Achtergrond',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'choices'       => array(
									'standaard' => 'Standaard (geel)',
									'beige'     => 'Met sokkenfoto-achtergrond',
									'roze'      => 'Roze (werkwijze)',
								),
								'default_value' => 'standaard',
							),
							array(
								'key'          => 'field_calc_knop',
								'label'        => 'Knop onder de calculator',
								'name'         => 'knop',
								'type'         => 'link',
								'instructions' => 'Leeg = "Gratis ontwerp aanvragen" naar de offertepagina.',
							),
						),
					),

					'layout_gift' => array(
						'key'        => 'layout_gift',
						'name'       => 'gift',
						'label'      => 'Geschenk-opties (kaartenrij)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Extra\'s' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/gift.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_gift_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Maak je sokkengeschenk compleet".',
							),
							array(
								'key'          => 'field_gift_kaarten',
								'label'        => 'Kaarten',
								'name'         => 'kaarten',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Kaart toevoegen',
								'max'          => 4,
								'instructions' => 'Maximaal 4 kaarten (het ontwerp is één rij van vier). Leeg = de vier standaardkaarten (labels, doosjes, wikkels, kaartjes).',
								'sub_fields'   => array(
									array( 'key' => 'field_gift_kaart_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 800 x 800 px (vierkant).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_gift_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array(
										'key'          => 'field_gift_kaart_punten',
										'label'        => 'Punten',
										'name'         => 'punten',
										'type'         => 'repeater',
										'layout'       => 'table',
										'button_label' => 'Punt toevoegen',
										'sub_fields'   => array(
											array( 'key' => 'field_gift_kaart_punt', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
										),
									),
									array( 'key' => 'field_gift_kaart_link', 'label' => 'Link', 'name' => 'link', 'type' => 'link', 'instructions' => 'Leeg = geen "Meer informatie"-regel op de kaart.' ),
								),
							),
						),
					),

					'layout_brand_intro' => array(
						'key'        => 'layout_brand_intro',
						'name'       => 'brand_intro',
						'label'      => 'Tekstblok merkverhaal',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Tekstblokken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/brand_intro.png',
						'sub_fields' => array(
							array(
								'key'           => 'field_bi_stijl',
								'label'         => 'Achtergrond',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'choices'       => array(
									'standaard'       => 'Cyaan (home)',
									'licht'           => 'Licht',
									'licht_werkwijze' => 'Licht (werkwijze)',
									'geel'            => 'Geel (configurator)',
								),
								'default_value' => 'standaard',
							),
							array(
								'key'          => 'field_bi_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = de home-titel.',
							),
							array(
								'key'          => 'field_bi_tekst_1',
								'label'        => 'Tekst (boven)',
								'name'         => 'tekst_1',
								'type'         => 'wysiwyg',
								'toolbar'      => 'sokkies_eenvoudig',
								'media_upload' => 0,
								'tabs'         => 'all',
								'instructions' => 'Vet, cursief, opsommingen en links. Selecteer woorden en gebruik de linkknop — plak GEEN kale URL op een eigen regel, die wordt niet getoond. Koppen, afbeeldingen en citaten verschijnen niet op de site; gebruik daarvoor het veld Tussenkop.',
							),
							array(
								'key'          => 'field_bi_tussenkop',
								'label'        => 'Tussenkop',
								'name'         => 'tussenkop',
								'type'         => 'text',
							),
							array(
								'key'          => 'field_bi_tekst_2',
								'label'        => 'Tekst (onder)',
								'name'         => 'tekst_2',
								'type'         => 'wysiwyg',
								'toolbar'      => 'sokkies_eenvoudig',
								'media_upload' => 0,
								'tabs'         => 'all',
								'instructions' => 'Vet, cursief, opsommingen en links. Selecteer woorden en gebruik de linkknop — plak GEEN kale URL op een eigen regel, die wordt niet getoond. Koppen, afbeeldingen en citaten verschijnen niet op de site; gebruik daarvoor het veld Tussenkop.',
							),
							array(
								'key'          => 'field_bi_link',
								'label'        => 'Lees meer-link',
								'name'         => 'link',
								'type'         => 'link',
								'instructions' => 'Leeg = "Lees meer" naar de Over ons-pagina.',
							),
							array(
								'key'           => 'field_bi_inklappen',
								'label'         => 'Tekst inklappen',
								'name'          => 'inklappen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 0,
								'instructions'  => 'Toont eerst een stuk van de tekst; "Lees meer" klapt de rest uit. LET OP: met inklappen aan wordt de Lees meer-link een uitklapknop en linkt hij dus niet meer door naar een pagina.',
							),
							array(
								'key'               => 'field_bi_inklap_hoogte',
								'label'             => 'Hoogte ingeklapt (px)',
								'name'              => 'inklap_hoogte',
								'type'              => 'number',
								'default_value'     => 340,
								'min'               => 80,
								'append'            => 'px',
								'instructions'      => 'Hoeveel tekst er in ingeklapte staat zichtbaar is. Leeg = 340.',
								'conditional_logic' => array( array( array( 'field' => 'field_bi_inklappen', 'operator' => '==', 'value' => '1' ) ) ),
							),
							array(
								'key'               => 'field_bi_label_open',
								'label'             => 'Knoptekst uitgeklapt',
								'name'              => 'label_open',
								'type'              => 'text',
								'instructions'      => 'Wat er op de knop staat zodra de tekst openstaat. Leeg = "Lees minder".',
								'placeholder'       => 'Lees minder',
								'conditional_logic' => array( array( array( 'field' => 'field_bi_inklappen', 'operator' => '==', 'value' => '1' ) ) ),
							),
						),
					),

					'layout_cases' => array(
						'key'        => 'layout_cases',
						'name'       => 'cases',
						'label'      => 'Klantcases (slider)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Cases' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/cases.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_cs2_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Wat we maakten".',
							),
							array(
								'key'           => 'field_cs2_stijl',
								'label'         => 'Achtergrond',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'choices'       => array(
									'blauw'   => 'Blauwe golf (home)',
									'effen'   => 'Effen blauw',
									'roze'    => 'Roze golf',
									'pdp'     => 'Met gele strip (productpagina)',
									'reviews' => 'Reviews-pagina',
									'collectie' => 'Collectiepagina (volledig blauw vlak)',
								),
								'default_value' => 'blauw',
							),
							array(
								'key'           => 'field_cs2_cases',
								'label'         => 'Cases',
								'name'          => 'cases',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_case' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'instructions'  => 'Leeg = de 3 nieuwste. Cases beheer je onder "Cases" in het menu links.',
							),
							array(
								'key'           => 'field_cs2_feet',
								'label'         => 'Voetjes-foto tonen',
								'name'          => 'voetjes_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
								'instructions'  => 'De effen en productpagina-varianten hebben ze in het ontwerp niet.',
							),
							array(
								'key'           => 'field_cs2_strip',
								'label'         => 'Fotostrip "Door onze klanten ontworpen" eronder',
								'name'          => 'fotostrip_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 0,
							),
							array(
								'key'               => 'field_cs2_strip_titel',
								'label'             => 'Fotostrip — titel',
								'name'              => 'fotostrip_titel',
								'type'              => 'text',
								'instructions'      => 'Leeg = "Door onze klanten ontworpen".',
								'conditional_logic' => array( array( array( 'field' => 'field_cs2_strip', 'operator' => '==', 'value' => '1' ) ) ),
							),
							array(
								'key'               => 'field_cs2_strip_link',
								'label'             => 'Fotostrip — link',
								'name'              => 'fotostrip_link',
								'type'              => 'link',
								'instructions'      => 'Leeg = "Bekijk volledige gallery" naar reviews & cases.',
								'conditional_logic' => array( array( array( 'field' => 'field_cs2_strip', 'operator' => '==', 'value' => '1' ) ) ),
							),
							array(
								'key'               => 'field_cs2_strip_fotos',
								'label'             => 'Fotostrip — foto\'s',
								'name'              => 'fotostrip_fotos',
								'type'              => 'gallery',
								'return_format'     => 'array',
								'preview_size'      => 'thumbnail',
								'insert'            => 'append',
								'instructions'      => 'Leeg = standaardset. Aanbevolen: 820 x 820 px per foto (vierkant).',
								'conditional_logic' => array( array( array( 'field' => 'field_cs2_strip', 'operator' => '==', 'value' => '1' ) ) ),
							),
						),
					),

					'layout_designed' => array(
						'key'        => 'layout_designed',
						'name'       => 'designed',
						'label'      => 'Fotostrip klantontwerpen (cyaan)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Foto\'s' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/designed.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_dz_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Door onze klanten ontworpen".',
							),
							array(
								'key'          => 'field_dz_link',
								'label'        => 'Link rechtsboven',
								'name'         => 'link',
								'type'         => 'link',
								'instructions' => 'Leeg = "Bekijk volledige gallery" naar reviews & cases.',
							),
							array(
								'key'           => 'field_dz_fotos',
								'label'         => 'Foto\'s',
								'name'          => 'fotos',
								'type'          => 'gallery',
								'return_format' => 'array',
								'preview_size'  => 'thumbnail',
								'insert'        => 'append',
								'instructions'  => 'Leeg = standaardset. De strip schuift langzaam vanzelf door. Aanbevolen: 820 x 820 px per foto (vierkant).',
							),
						),
					),

					'layout_testimonial' => array(
						'key'        => 'layout_testimonial',
						'name'       => 'testimonial',
						'label'      => 'Reviews-slider',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Reviews' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/testimonial.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_tm_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Wat klanten zeggen". De score ernaast komt uit Website-instellingen.',
							),
							array(
								'key'           => 'field_tm_stijl',
								'label'         => 'Achtergrond',
								'name'          => 'stijl',
								'type'          => 'button_group',
								'choices'       => array(
									'standaard' => 'Standaard (beige)',
									'licht'     => 'Licht (configurator)',
									'geel'      => 'Geel (productpagina)',
									'offerte'   => 'Offertepagina',
								),
								'default_value' => 'standaard',
							),
							array(
								'key'           => 'field_tm_reviews',
								'label'         => 'Reviews',
								'name'          => 'reviews',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_review' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'instructions'  => 'Leeg = álle reviews (nieuwste eerst). Reviews beheer je onder "Reviews" in het menu links.',
							),
						),
					),

					'layout_case_grid' => array(
						'key'        => 'layout_case_grid',
						'name'       => 'case_grid',
						'label'      => 'Cases-overzicht met filters',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Cases' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/case_grid.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_cg_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Cases". De filterchips komen automatisch uit de case-categorieën (Type sok en Branche).',
							),
							array(
								'key'           => 'field_cg_cases',
								'label'         => 'Cases',
								'name'          => 'cases',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_case' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'instructions'  => 'Leeg = álle cases (nieuwste eerst). Er verschijnen er 8; "Meer laden" toont de rest.',
							),
						),
					),

					/* Blogoverzicht: beige kop met kruimelpad, titel en
					   categoriechips, daaronder het kaartraster. Kop en raster
					   zitten in ÉÉN layout omdat de chips in het ontwerp op het
					   beige vlak staan — met een losse kop-sectie ertussen zou
					   die achtergrond precies op de verkeerde plek ophouden. */
					'layout_blog_overzicht' => array(
						'key'        => 'layout_blog_overzicht',
						'name'       => 'blog_overzicht',
						'label'      => 'Blogoverzicht (kop + filters + kaarten)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Cases' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/case_grid.png',
						'sub_fields' => array(
							array( 'key' => 'field_bo_breadcrumb', 'label' => 'Kruimelpad-label', 'name' => 'breadcrumb', 'type' => 'text', 'instructions' => 'Leeg = "Blogs".' ),
							array( 'key' => 'field_bo_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Tekst tussen [haken] wordt geel. Leeg = "Inzichten & inspiratie".' ),
							array( 'key' => 'field_bo_subtekst', 'label' => 'Subtekst', 'name' => 'subtekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '', 'instructions' => 'Optionele regel onder de titel. Leeg = geen subtekst, zoals in het ontwerp.' ),
							array( 'key' => 'field_bo_alles', 'label' => 'Label van de eerste chip', 'name' => 'alles_label', 'type' => 'text', 'instructions' => 'Leeg = "Alles".' ),
							array(
								'key'           => 'field_bo_blogs',
								'label'         => 'Blogs',
								'name'          => 'blogs',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_blog' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'instructions'  => 'Leeg = álle blogs (nieuwste eerst). Er verschijnen er 9; "Meer laden" toont de rest. De chips komen automatisch uit de categorieën die op de getoonde blogs staan, in de volgorde waarin de categorieën zijn aangemaakt.',
							),
						),
					),

					'layout_faq_pagina' => array(
						'key'        => 'layout_faq_pagina',
						'name'       => 'faq_pagina',
						'label'      => 'FAQ-pagina (zoeken + categorie\u00ebn)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Veelgestelde vragen' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/faq_pagina.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_fp_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Veelgestelde vragen". Alle categorie\u00ebn en vragen komen automatisch uit "Veelgestelde vragen" in het menu links.',
							),
							array(
								'key'          => 'field_fp_subtekst',
								'label'        => 'Subtekst',
								'name'         => 'subtekst',
								'type'         => 'text',
								'instructions' => 'Leeg = "Vind snel antwoord, of stel je vraag rechtstreeks.".',
							),
							array(
								'key'          => 'field_fp_placeholder',
								'label'        => 'Zoekveld-tekst',
								'name'         => 'zoek_placeholder',
								'type'         => 'text',
								'instructions' => 'Leeg = "Zoek in vragen...".',
							),
							array(
								'key'           => 'field_fp_kruimel_tonen',
								'label'         => 'Kruimelpad tonen',
								'name'          => 'kruimelpad_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
							),
							array(
								'key'               => 'field_fp_kruimel',
								'label'             => 'Kruimelpad-label',
								'name'              => 'kruimelpad',
								'type'              => 'text',
								'instructions'      => 'Leeg = de sectietitel.',
								'conditional_logic' => array( array( array( 'field' => 'field_fp_kruimel_tonen', 'operator' => '==', 'value' => '1' ) ) ),
							),
						),
					),

					'layout_steps' => array(
						'key'        => 'layout_steps',
						'name'       => 'steps',
						'label'      => 'Stappenkaarten (slider met foto\'s)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Werkwijze' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/steps.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_st2_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Zo werkt het, stap voor stap".',
							),
							array(
								'key'          => 'field_st2_stappen',
								'label'        => 'Stappen',
								'name'         => 'stappen',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Stap toevoegen',
								'instructions' => 'Nummers tellen vanzelf. Zonder foto toont de kaart een nette plek voor de foto (zoals het ontwerp). Leeg = de vier standaardstappen.',
								'sub_fields'   => array(
									array( 'key' => 'field_st2_stap_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 1600 x 1000 px (liggend, 8:5).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_st2_stap_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_st2_stap_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '' ),
								),
							),
							array(
								'key'           => 'field_st2_chips_tonen',
								'label'         => 'Pluspunten-chips tonen',
								'name'          => 'pluspunten_tonen',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
								'instructions'  => 'De zes iconen-chips onder de stappen (Gratis ontwerp, Snelle levering, …).',
							),
							array(
								'key'               => 'field_st2_chips',
								'label'             => 'Pluspunten',
								'name'              => 'pluspunten',
								'type'              => 'repeater',
								'layout'            => 'table',
								'button_label'      => 'Pluspunt toevoegen',
								'max'               => 6,
								'instructions'      => 'Maximaal 6 (het ontwerp is één rij). Leeg = de zes standaardchips.',
								'conditional_logic' => array( array( array( 'field' => 'field_st2_chips_tonen', 'operator' => '==', 'value' => '1' ) ) ),
								'sub_fields'        => array(
									array( 'key' => 'field_st2_chip_icoon', 'label' => 'Icoon', 'name' => 'icoon', 'type' => 'image', 'instructions' => 'Aanbevolen: 100 x 100 px, of een SVG.', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_st2_chip_label', 'label' => 'Tekst', 'name' => 'label', 'type' => 'text' ),
								),
							),
						),
					),

					'layout_compare' => array(
						'key'        => 'layout_compare',
						'name'       => 'compare',
						'label'      => 'Vergelijkingstabel soktypes',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Collectie' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/compare.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_cmp_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Welk type sok past bij jouw bedrijf?".',
							),
							array(
								'key'          => 'field_cmp_kolommen',
								'label'        => 'Kolommen (soktypes)',
								'name'         => 'kolommen',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Kolom toevoegen',
								'instructions' => 'Leeg = de standaardtabel. Kolom 1, 3 en 5 krijgen automatisch de uitgelichte opmaak.',
								'sub_fields'   => array(
									array( 'key' => 'field_cmp_kol_naam', 'label' => 'Naam', 'name' => 'naam', 'type' => 'text' ),
									array( 'key' => 'field_cmp_kol_badge', 'label' => 'Badge (optioneel)', 'name' => 'badge', 'type' => 'text' ),
								),
							),
							array(
								'key'          => 'field_cmp_rijen',
								'label'        => 'Rijen',
								'name'         => 'rijen',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Rij toevoegen',
								'instructions' => 'Per rij één waarde per kolom. Leeg = groen vinkje, "X" = rood kruis, andere tekst toont als tekst.',
								'sub_fields'   => array(
									array( 'key' => 'field_cmp_rij_label', 'label' => 'Label', 'name' => 'label', 'type' => 'text' ),
									array(
										'key'          => 'field_cmp_rij_waarden',
										'label'        => 'Waarden',
										'name'         => 'waarden',
										'type'         => 'repeater',
										'layout'       => 'table',
										'button_label' => 'Waarde toevoegen',
										'sub_fields'   => array(
											array( 'key' => 'field_cmp_waarde_tekst', 'label' => 'Tekst (leeg = vinkje)', 'name' => 'tekst', 'type' => 'text' ),
										),
									),
								),
							),
						),
					),

					'layout_conf_demo' => array(
						'key'        => 'layout_conf_demo',
						'name'       => 'conf_demo',
						'label'      => 'Configurator-voorbeeld (preview + pluspunten)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Extra\'s' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/conf_demo.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_cd_foto',
								'label'        => 'Voorbeeld-afbeelding',
								'name'         => 'foto',
								'type'         => 'image',
								'return_format' => 'array',
								'preview_size' => 'thumbnail',
								'instructions' => 'Leeg = de standaard demo-afbeelding. Aanbevolen: 1200 x 1100 px (bijna vierkant).',
							),
							array(
								'key'          => 'field_cd_punten',
								'label'        => 'Pluspunten (3)',
								'name'         => 'punten',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Punt toevoegen',
								'instructions' => 'Leeg = de drie standaardpunten.',
								'sub_fields'   => array(
									array( 'key' => 'field_cd_punt_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_cd_punt_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
								),
							),
						),
					),

					'layout_dl_cards' => array(
						'key'        => 'layout_dl_cards',
						'name'       => 'dl_cards',
						'label'      => 'Download-kaarten',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Extra\'s' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/dl_cards.png',
						'sub_fields' => array(
							array( 'key' => 'field_dl_titel', 'label' => 'Kop boven deze groep', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Bijvoorbeeld "Downloads" of "Templates". Leeg = geen kop, precies zoals het nu staat. Meer groepen? Zet dan nog een blok "Download-kaarten" op de pagina met een eigen kop.' ),
							array(
								'key'          => 'field_dl_kaarten',
								'label'        => 'Kaarten',
								'name'         => 'kaarten',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Kaart toevoegen',
								'instructions' => 'Leeg = de vier standaardkaarten. Upload een bestand \u00f3f kies een link; een bestand wint en opent als download. Met het veld "Kop boven deze kaart" deel je de rij op in groepen, bijvoorbeeld Downloads en Templates.',
								'sub_fields'   => array(
									/* De vier afbeeldingen staan NAAST elkaar (wrapper-width 25%),
									   zodat de taalversies van één cover in één oogopslag te
									   vergelijken zijn in plaats van over vier schermen verspreid.
									   Daarom staat de technische uitleg hieronder kort: in een
									   kolom van een kwart scherm wordt een lange instructie een
									   blok van zes regels en wordt de rij onnodig hoog. */
									array( 'key' => 'field_dl_kaart_foto', 'label' => 'Afbeelding (NL)', 'name' => 'foto', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'wrapper' => array( 'width' => '25' ), 'instructions' => 'Laatste terugval: alleen als er voor de taal én in het Engels niets staat. Leeg = nette placeholder. LIGGEND, 16:9 (bijv. 1600 x 900 px); een andere verhouding krijgt beige randen.' ),
									array( 'key' => 'field_dl_kaart_foto_en', 'label' => 'Afbeelding (EN)', 'name' => 'foto_en', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'wrapper' => array( 'width' => '25' ), 'instructions' => 'Engelse cover, en de terugval voor alle andere talen. Leeg = Nederlands.' ),
									array( 'key' => 'field_dl_kaart_foto_de', 'label' => 'Afbeelding (DE)', 'name' => 'foto_de', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'wrapper' => array( 'width' => '25' ), 'instructions' => 'Duitse cover. Leeg = Engels, anders Nederlands.' ),
									array( 'key' => 'field_dl_kaart_foto_fr', 'label' => 'Afbeelding (FR)', 'name' => 'foto_fr', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'wrapper' => array( 'width' => '25' ), 'instructions' => 'Franse cover. Leeg = Engels, anders Nederlands.' ),
									array( 'key' => 'field_dl_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_dl_kaart_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
									/* Vier op een rij, net als de afbeeldingen hierboven: zo staat
									   elke taal onder zijn eigen cover en lees je de kaart als twee
									   rijen (covers boven, PDF's eronder). Instructies kort houden,
									   anders wordt een kolom van een kwart scherm onnodig hoog. */
									array( 'key' => 'field_dl_kaart_bestand', 'label' => 'Bestand (NL)', 'name' => 'bestand', 'type' => 'file', 'return_format' => 'array', 'wrapper' => array( 'width' => '25' ), 'instructions' => 'Laatste terugval: alleen als er voor de taal én in het Engels niets staat.' ),
									array( 'key' => 'field_dl_kaart_bestand_en', 'label' => 'Bestand (EN)', 'name' => 'bestand_en', 'type' => 'file', 'return_format' => 'array', 'wrapper' => array( 'width' => '25' ), 'instructions' => 'Engelse versie, en de terugval voor alle andere talen. Leeg = Nederlands.' ),
									array( 'key' => 'field_dl_kaart_bestand_de', 'label' => 'Bestand (DE)', 'name' => 'bestand_de', 'type' => 'file', 'return_format' => 'array', 'wrapper' => array( 'width' => '25' ), 'instructions' => 'Duitse versie. Leeg = Engels, anders Nederlands.' ),
									array( 'key' => 'field_dl_kaart_bestand_fr', 'label' => 'Bestand (FR)', 'name' => 'bestand_fr', 'type' => 'file', 'return_format' => 'array', 'wrapper' => array( 'width' => '25' ), 'instructions' => 'Franse versie. Leeg = Engels, anders Nederlands.' ),
									array( 'key' => 'field_dl_kaart_link', 'label' => 'Of een link', 'name' => 'link', 'type' => 'link' ),
								),
							),
						),
					),

					'layout_contact_formulier' => array(
						'key'        => 'layout_contact_formulier',
						'name'       => 'contact_formulier',
						'label'      => 'Contactformulier met contactkaart',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Actieblokken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/contact_formulier.png',
						'sub_fields' => array(
							array(
								'key'     => 'field_ctf_uitleg',
								'label'   => '',
								'type'    => 'message',
								'message' => 'Dit blok toont het Gravity Forms-contactformulier ("Contact — website"). Velden, validatiemeldingen, bevestiging en notificaties beheer je onder Formulieren. De gele contactkaart gebruikt de gegevens uit Website-instellingen.',
							),
						),
					),

					'layout_usecase_why' => array(
						'key'        => 'layout_usecase_why',
						'name'       => 'usecase_why',
						'label'      => 'Waarom-blok (intro + 4 punten)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Tekstblokken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/usecase_why.png',
						'sub_fields' => array(
							array( 'key' => 'field_uw_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = standaardtitel. Regelafbraak met <br>.' ),
							array( 'key' => 'field_uw_intro', 'label' => 'Introtekst', 'name' => 'intro', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '' ),
							array(
								'key'          => 'field_uw_punten',
								'label'        => 'Punten',
								'name'         => 'punten',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Punt toevoegen',
								'instructions' => 'Leeg = de vier standaardpunten.',
								'sub_fields'   => array(
									array( 'key' => 'field_uw_punt_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_uw_punt_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
								),
							),
						),
					),

					'layout_usecases_flat' => array(
						'key'        => 'layout_usecases_flat',
						'name'       => 'usecases_flat',
						'label'      => 'Toepassingen (6 kaarten)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Extra\'s' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/usecases_flat.png',
						'sub_fields' => array(
							array( 'key' => 'field_uf_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = standaardtitel. Regelafbraak met <br>.' ),
							array(
								'key'          => 'field_uf_kaarten',
								'label'        => 'Kaarten',
								'name'         => 'kaarten',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Kaart toevoegen',
								'instructions' => 'Leeg = de zes standaardkaarten.',
								'sub_fields'   => array(
									array( 'key' => 'field_uf_kaart_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 1060 x 840 px (liggend, 5:4).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_uf_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_uf_kaart_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
									array( 'key' => 'field_uf_kaart_link', 'label' => 'Link', 'name' => 'link', 'type' => 'link', 'instructions' => 'Leeg = de vaste "Bekijk"-regel zonder doel (zoals het ontwerp).' ),
								),
							),
						),
					),

					'layout_dz_certs' => array(
						'key'        => 'layout_dz_certs',
						'name'       => 'dz_certs',
						'label'      => 'Certificaten-tabs (coral)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Duurzaamheid' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/dz_certs.png',
						'sub_fields' => array(
							array( 'key' => 'field_dzc_intro', 'label' => 'Introregel', 'name' => 'intro', 'type' => 'text', 'instructions' => 'Leeg = standaard. Geel deel tussen [ ], regelafbraak met <br>.' ),
							array(
								'key'          => 'field_dzc_tabs',
								'label'        => 'Tabs',
								'name'         => 'tabs',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Tab toevoegen',
								'instructions' => 'Leeg = de zes standaardtabs. Eerste tab staat open.',
								'sub_fields'   => array(
									array( 'key' => 'field_dzc_tab_label', 'label' => 'Tab-naam', 'name' => 'label', 'type' => 'text' ),
									array( 'key' => 'field_dzc_tab_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_dzc_tab_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'wysiwyg', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 0, 'tabs' => 'all', 'instructions' => 'Verdeel de tekst in alinea\'s met Enter. Vet, cursief, opsommingen en links kunnen hier; gebruik vet voor tussenkopjes zoals "Milieuaspect". Koppen en afbeeldingen verschijnen niet op de site.' ),
									array( 'key' => 'field_dzc_tab_noot', 'label' => 'Certificaatregel (optioneel)', 'name' => 'noot', 'type' => 'text' ),
									array( 'key' => 'field_dzc_tab_keurmerk', 'label' => 'Certificaatlogo (optioneel)', 'name' => 'keurmerk', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'instructions' => 'Het zegel of logo van het certificaat, komt onder de tekst te staan. PNG met transparante achtergrond werkt het beste op het corale vlak. Leeg = geen logo. Aanbevolen: 520 px breed, of een SVG.' ),
									array( 'key' => 'field_dzc_tab_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'instructions' => 'De grote foto rechts naast de tekst. Aanbevolen: 1120 x 870 px (liggend, 13:10).' ),
									array( 'key' => 'field_dzc_tab_foto_logo', 'label' => 'Beeld rechts is een logo', 'name' => 'foto_logo', 'type' => 'true_false', 'ui' => 1, 'default_value' => 0, 'instructions' => 'AAN voor een logo of zegel: het beeld wordt dan helemaal getoond op zijn eigen formaat. UIT (standaard) voor een foto: die vult het vlak en wordt bijgesneden. Zet dit aan als een logo er uitvergroot of afgesneden uitziet.' ),
								),
							),
						),
					),

					'layout_dz_keur' => array(
						'key'        => 'layout_dz_keur',
						'name'       => 'dz_keur',
						'label'      => 'Keurmerk-kaarten (3 logo\'s)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Duurzaamheid' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/dz_keur.png',
						'sub_fields' => array(
							array( 'key' => 'field_dzk_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Certificaten en keurmerken".' ),
							array(
								'key'          => 'field_dzk_kaarten',
								'label'        => 'Kaarten',
								'name'         => 'kaarten',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Kaart toevoegen',
								'instructions' => 'Leeg = de drie standaardkaarten (OEKO-TEX/GOTS/BSCI).',
								'sub_fields'   => array(
									array( 'key' => 'field_dzk_kaart_logo', 'label' => 'Logo', 'name' => 'logo', 'type' => 'image', 'instructions' => 'Aanbevolen: 180 px hoog, of een SVG.', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_dzk_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_dzk_kaart_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
								),
							),
						),
					),

					'layout_dz_points' => array(
						'key'        => 'layout_dz_points',
						'name'       => 'dz_points',
						'label'      => 'Puntenblok met fotocollage',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Duurzaamheid' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/dz_points.png',
						'sub_fields' => array(
							array( 'key' => 'field_dzp_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = standaardtitel.' ),
							array( 'key' => 'field_dzp_intro', 'label' => 'Introregel', 'name' => 'intro', 'type' => 'text' ),
							array( 'key' => 'field_dzp_foto_klein', 'label' => 'Foto (klein)', 'name' => 'foto_klein', 'type' => 'image', 'instructions' => 'Aanbevolen: 660 x 840 px (staand, 4:5).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
							array( 'key' => 'field_dzp_foto_groot', 'label' => 'Foto (groot)', 'name' => 'foto_groot', 'type' => 'image', 'instructions' => 'Aanbevolen: 930 x 1250 px (staand, 3:4).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
							array(
								'key'          => 'field_dzp_punten',
								'label'        => 'Punten',
								'name'         => 'punten',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Punt toevoegen',
								'instructions' => 'Nummers (1. 2. 3.) tellen vanzelf. Leeg = de drie standaardpunten.',
								'sub_fields'   => array(
									array( 'key' => 'field_dzp_punt_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
								),
							),
							array( 'key' => 'field_dzp_slot', 'label' => 'Slotregel', 'name' => 'slot', 'type' => 'text', 'instructions' => 'Leeg = standaard.' ),
							array( 'key' => 'field_dzp_knop', 'label' => 'Knop', 'name' => 'knop', 'type' => 'link', 'instructions' => 'Leeg = "Neem contact op" naar de contactpagina.' ),
						),
					),

					'layout_pt_perks' => array(
						'key'        => 'layout_pt_perks',
						'name'       => 'pt_perks',
						'label'      => 'Voordelen-kaarten (4 beige)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Partners' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/pt_perks.png',
						'sub_fields' => array(
							array( 'key' => 'field_pp_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Voordelen voor partners".' ),
							array(
								'key'          => 'field_pp_kaarten',
								'label'        => 'Kaarten',
								'name'         => 'kaarten',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Kaart toevoegen',
								'instructions' => 'Leeg = de vier standaardkaarten.',
								'sub_fields'   => array(
									array( 'key' => 'field_pp_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_pp_kaart_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
								),
							),
						),
					),

					'layout_pt_partners' => array(
						'key'        => 'layout_pt_partners',
						'name'       => 'pt_partners',
						'label'      => 'Partnerlogo-grid met filter',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Partners' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/pt_partners.png',
						'sub_fields' => array(
							array( 'key' => 'field_ppg_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Onze partners". Filterchips komen automatisch uit de Partnercategorieën op de logo\'s.' ),
							array(
								'key'           => 'field_ppg_logos',
								'label'         => 'Logo\'s',
								'name'          => 'logos',
								'type'          => 'relationship',
								'post_type'     => array( 'sokkies_logo' ),
								'filters'       => array( 'search' ),
								'return_format' => 'id',
								'instructions'  => 'Leeg = álle logo\'s.',
							),
						),
					),

					'layout_pt_otp' => array(
						'key'        => 'layout_pt_otp',
						'name'       => 'pt_otp',
						'label'      => 'One Tree Planted-blok (coral)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Partners' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/pt_otp.png',
						'sub_fields' => array(
							array( 'key' => 'field_po_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = standaard. Regelafbraak met <br>.' ),
							array( 'key' => 'field_po_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '' ),
							array( 'key' => 'field_po_foto_klein', 'label' => 'Foto (klein)', 'name' => 'foto_klein', 'type' => 'image', 'instructions' => 'Aanbevolen: 670 x 710 px (bijna vierkant).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
							array( 'key' => 'field_po_foto_groot', 'label' => 'Foto (groot)', 'name' => 'foto_groot', 'type' => 'image', 'instructions' => 'Aanbevolen: 920 x 710 px (liggend, 13:10).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
						),
					),

					'layout_pt_dl' => array(
						'key'        => 'layout_pt_dl',
						'name'       => 'pt_dl',
						'label'      => 'Brochure-download met formulier',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Partners' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/pt_dl.png',
						'sub_fields' => array(
							array( 'key' => 'field_pd_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Brochure en inspiratiegids".' ),
							array( 'key' => 'field_pd_intro', 'label' => 'Introregel', 'name' => 'intro', 'type' => 'text' ),
							array(
								'key'          => 'field_pd_kaarten',
								'label'        => 'Brochure-kaarten (2)',
								'name'         => 'kaarten',
								'type'         => 'repeater',
								'layout'       => 'block',
								'min'          => 2,
								'max'          => 2,
								'button_label' => 'Kaart toevoegen',
								'instructions' => 'Leeg = de twee standaardkaarten. Upload een bestand óf kies een link.',
								'sub_fields'   => array(
									array( 'key' => 'field_pd_kaart_foto', 'label' => 'Afbeelding', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 880 x 690 px (liggend, 5:4).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_pd_kaart_tag', 'label' => 'Label', 'name' => 'tag', 'type' => 'text' ),
									array( 'key' => 'field_pd_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_pd_kaart_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
									array( 'key' => 'field_pd_kaart_bestand', 'label' => 'Bestand', 'name' => 'bestand', 'type' => 'file', 'return_format' => 'array' ),
									array( 'key' => 'field_pd_kaart_link', 'label' => 'Of een link', 'name' => 'link', 'type' => 'link' ),
								),
							),
							array( 'key' => 'field_pd_form_kop', 'label' => 'Formulier-kop', 'name' => 'form_kop', 'type' => 'text', 'instructions' => 'Leeg = "Ontvang beide downloads". Het formulier is nog een demo tot de formulierenfase.' ),
							array( 'key' => 'field_pd_sticker', 'label' => 'Regel onder de knop', 'name' => 'sticker', 'type' => 'text', 'instructions' => 'Korte geruststelling onder de verzendknop. Leeg = "We mailen ze meteen toe."' ),
						),
					),

					'layout_ws_intro' => array(
						'key'        => 'layout_ws_intro',
						'name'       => 'ws_intro',
						'label'      => 'Waarom-intro (6 fotokaarten)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Waarom Sokkies' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/ws_intro.png',
						'sub_fields' => array(
							array( 'key' => 'field_wi_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Waarom Sokkies".' ),
							array( 'key' => 'field_wi_subtekst', 'label' => 'Subtekst', 'name' => 'subtekst', 'type' => 'text' ),
							array(
								'key'          => 'field_wi_kaarten',
								'label'        => 'Fotokaarten (precies 6)',
								'name'         => 'kaarten',
								'type'         => 'repeater',
								'layout'       => 'block',
								'min'          => 6,
								'max'          => 6,
								'button_label' => 'Kaart toevoegen',
								'instructions' => 'De collage heeft 6 vaste posities. Leeg = de standaardkaarten.',
								'sub_fields'   => array(
									array( 'key' => 'field_wi_kaart_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 930 x 750 px (liggend, 5:4).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_wi_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_wi_kaart_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
								),
							),
						),
					),

					'layout_ws_compare' => array(
						'key'        => 'layout_ws_compare',
						'name'       => 'ws_compare',
						'label'      => 'Sokkies vs. de rest (tabel)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Waarom Sokkies' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/ws_compare.png',
						'sub_fields' => array(
							array( 'key' => 'field_wc_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Hoe verhoudt Sokkies zich?".' ),
							array(
								'key'          => 'field_wc_rijen',
								'label'        => 'Rijen',
								'name'         => 'rijen',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Rij toevoegen',
								'instructions' => 'Sokkies-kolom leeg = groen vinkje. Rest-kolom: "X" = rode X, andere tekst (Soms/Vaak) toont als tekst. Leeg = de standaardtabel.',
								'sub_fields'   => array(
									array( 'key' => 'field_wc_rij_label', 'label' => 'Wat je krijgt', 'name' => 'label', 'type' => 'text' ),
									array( 'key' => 'field_wc_rij_wij', 'label' => 'Sokkies', 'name' => 'wij', 'type' => 'text' ),
									array( 'key' => 'field_wc_rij_rest', 'label' => 'De rest', 'name' => 'rest', 'type' => 'text' ),
								),
							),
						),
					),

					'layout_ws_gets' => array(
						'key'        => 'layout_ws_gets',
						'name'       => 'ws_gets',
						'label'      => 'Wat je krijgt (lijst + collage)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Waarom Sokkies' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/ws_gets.png',
						'sub_fields' => array(
							array( 'key' => 'field_wg_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Wat je bij ons krijgt".' ),
							array(
								'key'          => 'field_wg_punten',
								'label'        => 'Punten',
								'name'         => 'punten',
								'type'         => 'repeater',
								'layout'       => 'table',
								'button_label' => 'Punt toevoegen',
								'instructions' => 'Nummers (01, 02, …) tellen vanzelf. Leeg = de zes standaardpunten.',
								'sub_fields'   => array(
									array( 'key' => 'field_wg_punt_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
								),
							),
							array( 'key' => 'field_wg_fotos', 'label' => 'Collage (4 foto\'s)', 'name' => 'fotos', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'Kolom 1 = foto 1 en 3, kolom 2 = foto 2 en 4. Leeg = de standaardset. Aanbevolen: 830 x 840 px per foto (vierkant).' ),
						),
					),

					'layout_overons_story' => array(
						'key' => 'layout_overons_story', 'name' => 'overons_story', 'label' => 'Verhaalblok met fotocollage', 'display' => 'block',
						'acfe_flexible_category'  => array( 'Over ons' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/overons_story.png',
						'sub_fields' => array(
							array( 'key' => 'field_os_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Hoe het begon".' ),
							array( 'key' => 'field_os_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'wysiwyg', 'tabs' => 'all', 'toolbar' => 'basic', 'media_upload' => 0, 'instructions' => 'Leeg = de standaardtekst (twee alinea\'s).' ),
							array( 'key' => 'field_os_fotos', 'label' => 'Collage (4 foto\'s)', 'name' => 'fotos', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'Dambord: klein/groot/klein/groot. Leeg = de standaardset. Aanbevolen: 920 x 1240 px per foto (staand, 3:4).' ),
						),
					),

					'layout_timeline' => array(
						'key' => 'layout_timeline', 'name' => 'timeline', 'label' => 'Tijdlijn-slider (jaren)', 'display' => 'block',
						'acfe_flexible_category'  => array( 'Over ons' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/timeline.png',
						'sub_fields' => array(
							array( 'key' => 'field_tl_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Door de jaren heen".' ),
							array(
								'key' => 'field_tl_slides', 'label' => 'Kaarten', 'name' => 'slides', 'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Kaart toevoegen',
								'instructions' => 'Leeg = de acht standaardkaarten (2025 t/m 2016). Elke regel in het tekstveld wordt een eigen alinea.',
								'sub_fields' => array(
									array( 'key' => 'field_tl_slide_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 800 x 800 px (vierkant).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_tl_slide_jaar', 'label' => 'Jaar', 'name' => 'jaar', 'type' => 'text' ),
									array( 'key' => 'field_tl_slide_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_tl_slide_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '' ),
								),
							),
						),
					),

					'layout_overons_values' => array(
						'key' => 'layout_overons_values', 'name' => 'overons_values', 'label' => 'Waarden (genummerde blokken)', 'display' => 'block',
						'acfe_flexible_category'  => array( 'Over ons' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/overons_values.png',
						'sub_fields' => array(
							array( 'key' => 'field_ov_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Waar we voor staan".' ),
							array(
								'key' => 'field_ov_waarden', 'label' => 'Waarden', 'name' => 'waarden', 'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Waarde toevoegen',
								'instructions' => 'Nummers tellen vanzelf. Zonder icoon blijft het vak leeg (zoals het ontwerp, tot de icoon-exports er zijn). Leeg = de vier standaardwaarden.',
								'sub_fields' => array(
									array( 'key' => 'field_ov_waarde_icoon', 'label' => 'Icoon/foto', 'name' => 'icoon', 'type' => 'image', 'instructions' => 'Aanbevolen: 240 x 240 px, of een SVG.', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_ov_waarde_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_ov_waarde_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
								),
							),
						),
					),

					'layout_overons_reviews' => array(
						'key' => 'layout_overons_reviews', 'name' => 'overons_reviews', 'label' => 'Reviews-carrousel (volle breedte)', 'display' => 'block',
						'acfe_flexible_category'  => array( 'Reviews' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/overons_reviews.png',
						'sub_fields' => array(
							array( 'key' => 'field_or_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Wat klanten zeggen". Score/aantal komen uit Website-instellingen.' ),
							array( 'key' => 'field_or_reviews', 'label' => 'Reviews', 'name' => 'reviews', 'type' => 'relationship', 'post_type' => array( 'sokkies_review' ), 'filters' => array( 'search' ), 'return_format' => 'id', 'instructions' => 'Leeg = alle reviews.' ),
						),
					),

					'layout_overons_duurz' => array(
						'key' => 'layout_overons_duurz', 'name' => 'overons_duurz', 'label' => 'Duurzaamheidsblok met collage', 'display' => 'block',
						'acfe_flexible_category'  => array( 'Over ons' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/overons_duurz.png',
						'sub_fields' => array(
							array( 'key' => 'field_od_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Met oog voor duurzaamheid".' ),
							array( 'key' => 'field_od_kop', 'label' => 'Tussenkop', 'name' => 'kop', 'type' => 'text' ),
							array( 'key' => 'field_od_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '' ),
							array( 'key' => 'field_od_fotos', 'label' => 'Collage (3 foto\'s)', 'name' => 'fotos', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'Foto 1 = groot, 2 en 3 = klein. Leeg = de standaardset. Aanbevolen: 800 x 880 px per foto (staand, 9:10).' ),
							array( 'key' => 'field_od_link', 'label' => 'Link', 'name' => 'link', 'type' => 'link', 'instructions' => 'Leeg = "Lees over onze duurzaamheid" naar de duurzaamheidspagina.' ),
						),
					),

					'layout_offerte_funnel' => array(
						'key' => 'layout_offerte_funnel', 'name' => 'offerte_funnel', 'label' => 'Offerteformulier (3 stappen — demo)', 'display' => 'block',
						'acfe_flexible_category'  => array( 'Funnel' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/offerte_funnel.png',
						'sub_fields' => array(
							array( 'key' => 'field_offerte_funnel_uitleg', 'label' => '', 'type' => 'message', 'message' => 'Deze sectie is een 1:1-demo van de statische funnelpagina. Inhoud en echte verzending worden bewerkbaar in de formulierenfase (Gravity Forms).' ),
						),
					),

					'layout_sample_funnel' => array(
						'key' => 'layout_sample_funnel', 'name' => 'sample_funnel', 'label' => 'Sample-aanvraagformulier (demo)', 'display' => 'block',
						'acfe_flexible_category'  => array( 'Funnel' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/sample_funnel.png',
						'sub_fields' => array(
							array( 'key' => 'field_sample_funnel_uitleg', 'label' => '', 'type' => 'message', 'message' => 'Deze sectie is een 1:1-demo van de statische funnelpagina. Inhoud en echte verzending worden bewerkbaar in de formulierenfase (Gravity Forms).' ),
						),
					),

					/* Eén layout voor ALLE bedankpagina's (contact, offerte, sample).
					   Elk formulier verwijst na verzending naar zijn eigen pagina, en
					   die pagina's verschillen alleen in tekst — dus geen drie losse
					   sectietemplates maar één met velden. Alles leeg laten geeft
					   exact de oorspronkelijke offerte-bedankpagina terug; de
					   standaardwaarden staan in de sectietemplate. */
					'layout_bedankt_inhoud' => array(
						'key' => 'layout_bedankt_inhoud', 'name' => 'bedankt_inhoud', 'label' => 'Bedankt-inhoud (bevestiging + volg ons)', 'display' => 'block',
						'acfe_flexible_category'  => array( 'Funnel' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/bedankt_inhoud.png',
						'sub_fields' => array(
							array( 'key' => 'field_bd_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Tekst tussen [haken] wordt geel. Leeg = "[Bedankt] voor je aanvraag!".' ),
							array( 'key' => 'field_bd_intro', 'label' => 'Introtekst', 'name' => 'intro', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '', 'instructions' => 'De regel onder de titel. <br> mag. Leeg = de standaardzin.' ),
							array( 'key' => 'field_bd_ref_tonen', 'label' => 'Referentienummer tonen', 'name' => 'ref_tonen', 'type' => 'true_false', 'ui' => 1, 'default_value' => 1, 'instructions' => 'Het nummer van de aanvraag. Verschijnt alleen als de bezoeker hier via een verzonden formulier komt — bij een gewoon paginabezoek valt de regel weg.' ),
							array( 'key' => 'field_bd_stappen_titel', 'label' => 'Kop boven de stappen', 'name' => 'stappen_titel', 'type' => 'text', 'instructions' => 'Leeg = "Wat gebeurt er nu?".' ),
							array(
								'key' => 'field_bd_stappen', 'label' => 'Stappen', 'name' => 'stappen', 'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Stap toevoegen',
								'instructions' => 'Houd het op DRIE stappen: het ontwerp zet ze in drie kolommen naast elkaar, bij een ander aantal ontstaan er gaten of loopt de rij over. De eerste stap krijgt automatisch het vinkje (die is immers al gebeurd), de rest wordt genummerd. Leeg = de standaardstappen.',
								'sub_fields' => array(
									array( 'key' => 'field_bd_stap_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_bd_stap_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
								),
							),
							array( 'key' => 'field_bd_wacht_titel', 'label' => 'Kop boven de kaarten', 'name' => 'wacht_titel', 'type' => 'text', 'instructions' => 'Leeg = "Terwijl je wacht".' ),
							array(
								'key' => 'field_bd_kaarten', 'label' => 'Kaarten', 'name' => 'kaarten', 'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Kaart toevoegen',
								'instructions' => 'Suggesties om te lezen tijdens het wachten. Ook hier zijn DRIE kaarten de bedoeling; de sok-achtergrond eronder is op die hoogte afgestemd. Leeg = de standaardkaarten.',
								'sub_fields' => array(
									array( 'key' => 'field_bd_kaart_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 890 x 680 px (liggend, 13:10).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
									array( 'key' => 'field_bd_kaart_tag', 'label' => 'Label', 'name' => 'tag', 'type' => 'text', 'instructions' => 'Het woordje boven de titel, bijvoorbeeld "Brochure".' ),
									array( 'key' => 'field_bd_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_bd_kaart_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
									array( 'key' => 'field_bd_kaart_link', 'label' => 'Link', 'name' => 'link', 'type' => 'link' ),
								),
							),
							array( 'key' => 'field_bd_volg_titel', 'label' => 'Kop "Volg ons"', 'name' => 'volg_titel', 'type' => 'text', 'instructions' => 'Leeg = "Volg ons voor inspiratie".' ),
							array( 'key' => 'field_bd_volg_tekst', 'label' => 'Tekst onder "Volg ons"', 'name' => 'volg_tekst', 'type' => 'text', 'instructions' => 'Leeg = "Nieuwe ontwerpen, achter-de-schermen, case-studies.".' ),
						),
					),

					/* ── Landingspagina's ──────────────────────────────────────
					   Vier losse blokken, bewust generiek gehouden zodat een
					   volgende landingspagina ze met andere inhoud opnieuw kan
					   gebruiken. Alles wat het ontwerp toont is een veld; leeg
					   laten geeft de tekst van het ontwerp terug. De overige
					   secties van de landingspagina zijn bestaande layouts
					   (merkenstrip, soktypes-slider, reviews, veelgestelde
					   vragen, afsluitend actieblok en de stappen met
					   fotocollage in de landingsvariant). */

					'layout_lp_hero' => array(
						'key'        => 'layout_lp_hero',
						'name'       => 'lp_hero',
						'label'      => 'Landingskop (tekst + fotocollage)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Paginakoppen' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/lp_hero.png',
						'sub_fields' => array(
							array( 'key' => 'field_lph_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Tekst tussen [haken] wordt geel. Leeg = "Sokken [bedrukken] vanaf 50 paar" (het aantal komt uit Website-instellingen).' ),
							array( 'key' => 'field_lph_subtekst', 'label' => 'Tekst onder de titel', 'name' => 'subtekst', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '', 'instructions' => 'Leeg = de standaardzin van het ontwerp.' ),
							array( 'key' => 'field_lph_knop', 'label' => 'Knop', 'name' => 'knop', 'type' => 'link', 'instructions' => 'Leeg = de standaardknop naar de offertepagina.' ),
							array( 'key' => 'field_lph_rating', 'label' => 'Reviewregel tonen', 'name' => 'rating', 'type' => 'true_false', 'ui' => 1, 'default_value' => 1, 'instructions' => 'De score en het aantal reviews komen uit Website-instellingen.' ),
							array( 'key' => 'field_lph_kolom_1', 'label' => 'Fotogalerij — kolom 1', 'name' => 'fotos_kolom_1', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'De linkerkolom van de doorlopende galerij rechts (zelfde mechaniek als de paginakop met fotokolommen). 4 foto\'s is het ritme; leeg = de standaardset uit het thema. Aanbevolen: 890 x 1040 px per foto (staand, 6:7).' ),
							array( 'key' => 'field_lph_kolom_2', 'label' => 'Fotogalerij — kolom 2', 'name' => 'fotos_kolom_2', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'De rechterkolom; loopt tegengesteld aan kolom 1. Leeg = de standaardset uit het thema. Aanbevolen: 890 x 1040 px per foto (staand, 6:7).' ),
							array( 'key' => 'field_lph_stijl', 'label' => 'Achtergrond', 'name' => 'stijl', 'type' => 'button_group', 'choices' => array( 'coral' => 'Rood', 'beige' => 'Beige', 'wit' => 'Wit' ), 'default_value' => 'coral' ),
						),
					),

					'layout_lp_media' => array(
						'key'        => 'layout_lp_media',
						'name'       => 'lp_media',
						'label'      => 'Foto naast tekst (50/50)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Tekstblokken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/lp_media.png',
						'sub_fields' => array(
							array( 'key' => 'field_lpm_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 1340 x 840 px (liggend, 8:5).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
							array( 'key' => 'field_lpm_leeg', 'label' => 'Zonder foto', 'name' => 'leeg', 'type' => 'button_group', 'choices' => array( 'standaardfoto' => 'Themafoto tonen', 'placeholder' => 'Neutraal vak (image placeholder)' ), 'default_value' => 'standaardfoto', 'instructions' => 'Wat er staat zolang er geen foto is gekozen. Zodra je een foto kiest, geldt die.', 'conditional_logic' => array( array( array( 'field' => 'field_lpm_foto', 'operator' => '==empty' ) ) ) ),
							array( 'key' => 'field_lpm_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Tekst tussen [haken] wordt geel.' ),
							array( 'key' => 'field_lpm_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'wysiwyg', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 0, 'tabs' => 'visual' ),
							array( 'key' => 'field_lpm_knop', 'label' => 'Link onder de tekst', 'name' => 'knop', 'type' => 'link', 'instructions' => 'Leeg = geen link.' ),
							array( 'key' => 'field_lpm_positie', 'label' => 'Foto staat', 'name' => 'foto_positie', 'type' => 'button_group', 'choices' => array( 'links' => 'Links', 'rechts' => 'Rechts' ), 'default_value' => 'links' ),
							array( 'key' => 'field_lpm_stijl', 'label' => 'Achtergrond', 'name' => 'stijl', 'type' => 'button_group', 'choices' => array( 'wit' => 'Wit', 'beige' => 'Beige' ), 'default_value' => 'wit' ),
						),
					),

					'layout_lp_usps' => array(
						'key'        => 'layout_lp_usps',
						'name'       => 'lp_usps',
						'label'      => 'Pluspunten-raster (geel vlak)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Waarom Sokkies' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/lp_usps.png',
						'sub_fields' => array(
							array( 'key' => 'field_lpu_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Waarom Sokkies?". Tekst tussen [haken] wordt geel.' ),
							array(
								'key' => 'field_lpu_punten', 'label' => 'Pluspunten', 'name' => 'punten', 'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Pluspunt toevoegen',
								'instructions' => 'Het raster loopt in drie kolommen; zes punten vullen precies twee rijen. Leeg = de zes punten van het ontwerp.',
								'sub_fields' => array(
									array( 'key' => 'field_lpu_icoon', 'label' => 'Icoon', 'name' => 'icoon', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'instructions' => 'Klein vierkant icoon. Leeg = alleen tekst. Aanbevolen: 240 x 240 px, of een SVG.' ),
									array( 'key' => 'field_lpu_titel_r', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_lpu_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
								),
							),
							array( 'key' => 'field_lpu_stijl', 'label' => 'Achtergrond', 'name' => 'stijl', 'type' => 'button_group', 'choices' => array( 'geel' => 'Geel vlak met golfranden', 'wit' => 'Wit' ), 'default_value' => 'geel' ),
						),
					),

					'layout_lp_keurmerken' => array(
						'key'        => 'layout_lp_keurmerken',
						'name'       => 'lp_keurmerken',
						'label'      => 'Keurmerkenstrip (logo\'s op een rij)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Duurzaamheid' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/lp_keurmerken.png',
						'sub_fields' => array(
							array( 'key' => 'field_lpk_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = "Duurzaam met certificaat".' ),
							array( 'key' => 'field_lpk_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '', 'instructions' => 'Een regel onder de titel. Leeg = de standaardzin.' ),
							array( 'key' => 'field_lpk_logos', 'label' => 'Logo\'s', 'name' => 'logos', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'Leeg = de vier keurmerken uit het thema (BSCI, GOTS, OEKO-TEX, One Tree Planted). Aanbevolen: 300 x 200 px per logo, of een SVG.' ),
						),
					),

					/* ── Flexibele pagina ─────────────────────────────────────
					   Drie blokken uit het ontwerp voor vrij samen te stellen
					   pagina's. De paginakop (simple_hero), foto-naast-tekst
					   (lp_media) en het afsluitende actieblok (cta_final)
					   bestonden al en worden hergebruikt. Leeg = de
					   voorbeeldtekst van het ontwerp. */

					'layout_fp_tekst_kolommen' => array(
						'key'        => 'layout_fp_tekst_kolommen',
						'name'       => 'fp_tekst_kolommen',
						'label'      => 'Kop met intro en twee tekstkolommen',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Tekstblokken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/fp_tekst_kolommen.png',
						'sub_fields' => array(
							array( 'key' => 'field_fpk_kop', 'label' => 'Sectiekop', 'name' => 'kop', 'type' => 'text', 'instructions' => 'Tekst tussen [haken] wordt geel. Leeg = "Sectiekop".' ),
							array( 'key' => 'field_fpk_intro', 'label' => 'Intro', 'name' => 'intro', 'type' => 'wysiwyg', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 0, 'tabs' => 'visual', 'instructions' => 'Een korte inleiding over de volle breedte, onder de kop.' ),
							array( 'key' => 'field_fpk_kolom_1', 'label' => 'Linkerkolom', 'name' => 'kolom_1', 'type' => 'wysiwyg', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 0, 'tabs' => 'visual' ),
							array( 'key' => 'field_fpk_kolom_2', 'label' => 'Rechterkolom', 'name' => 'kolom_2', 'type' => 'wysiwyg', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 0, 'tabs' => 'visual', 'instructions' => 'Op smalle schermen komt deze kolom onder de linker.' ),
							array( 'key' => 'field_fpk_knop', 'label' => 'Knop (optioneel)', 'name' => 'knop', 'type' => 'link', 'instructions' => 'Laat leeg als het blok alleen tekst is. Ingevuld verschijnt er een gele knop onder de tekst - handig als het blok met een oproep eindigt, zoals "Neem contact op".' ),
							array( 'key' => 'field_fpk_uitlijning', 'label' => 'Uitlijning', 'name' => 'uitlijning', 'type' => 'button_group', 'choices' => array( 'links' => 'Links', 'midden' => 'Gecentreerd' ), 'default_value' => 'links', 'instructions' => 'Gecentreerd past bij een kort blok met een oproep; links bij lopende tekst in twee kolommen.' ),
						),
					),

					'layout_fp_citaat' => array(
						'key'        => 'layout_fp_citaat',
						'name'       => 'fp_citaat',
						'label'      => 'Citaat (kaart op geel vlak)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Tekstblokken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/fp_citaat.png',
						'sub_fields' => array(
							array( 'key' => 'field_fpc_citaat', 'label' => 'Citaat', 'name' => 'citaat', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '', 'instructions' => 'Zonder aanhalingstekens; de kaart zet ze er zelf omheen. Leeg = de voorbeeldzin.' ),
							array( 'key' => 'field_fpc_naam', 'label' => 'Naam / bron', 'name' => 'naam', 'type' => 'text', 'instructions' => 'Optioneel, komt onder het citaat.' ),
							array( 'key' => 'field_fpc_stijl', 'label' => 'Achtergrond', 'name' => 'stijl', 'type' => 'button_group', 'choices' => array( 'geel' => 'Geel vlak met golfrand', 'wit' => 'Wit' ), 'default_value' => 'geel', 'instructions' => 'Zet je hierna een "Lees ook" in het geel, dan lopen de twee als één band door.' ),
						),
					),

					'layout_fp_lees_ook' => array(
						'key'        => 'layout_fp_lees_ook',
						'name'       => 'fp_lees_ook',
						'label'      => 'Lees ook (kaartenrij met links)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Extra\'s' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/fp_lees_ook.png',
						'sub_fields' => array(
							array( 'key' => 'field_fpl_kop', 'label' => 'Kop', 'name' => 'kop', 'type' => 'text', 'instructions' => 'Leeg = "Lees ook".' ),
							array(
								'key' => 'field_fpl_kaarten', 'label' => 'Kaarten', 'name' => 'kaarten', 'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Kaart toevoegen',
								'instructions' => 'Drie kaarten is het ritme van het ontwerp. Leeg = drie voorbeeldkaarten.',
								'sub_fields' => array(
									array( 'key' => 'field_fpl_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
									array( 'key' => 'field_fpl_tekst', 'label' => 'Korte omschrijving', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
									array( 'key' => 'field_fpl_link', 'label' => 'Link', 'name' => 'link', 'type' => 'link', 'instructions' => 'De linktekst wordt het "Lees meer"-label; leeg = "Lees meer".' ),
								),
							),
							array( 'key' => 'field_fpl_stijl', 'label' => 'Achtergrond', 'name' => 'stijl', 'type' => 'button_group', 'choices' => array( 'geel' => 'Geel', 'wit' => 'Wit' ), 'default_value' => 'geel' ),
						),
					),

					'layout_optie_kaarten' => array(
						'key'        => 'layout_optie_kaarten',
						'name'       => 'optie_kaarten',
						'label'      => 'Optiekaarten (raster met pagina\'s)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Extra\'s' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/optie_kaarten.png',
						'sub_fields' => array(
							array( 'key' => 'field_ok_titel', 'label' => 'Kop boven de kaarten', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = geen kop. Meestal niet nodig: de paginakop staat er al boven. Tekst tussen [haken] wordt geel.' ),
							array(
								'key' => 'field_ok_kaarten', 'label' => 'Kaarten', 'name' => 'kaarten', 'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Optie toevoegen',
								'instructions' => 'Kies per kaart een pagina; titel, omschrijving en foto komen dan van die pagina zelf. Vul je een veld hieronder toch in, dan wint dat. Bij precies vier kaarten staan ze op één rij, anders in drie kolommen.',
								'sub_fields' => array(
									array( 'key' => 'field_ok_pagina', 'label' => 'Pagina', 'name' => 'pagina', 'type' => 'post_object', 'post_type' => array( 'page' ), 'return_format' => 'id', 'ui' => 1, 'allow_null' => 1, 'instructions' => 'De pagina waar de kaart heen linkt.' ),
									array( 'key' => 'field_ok_kaart_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Leeg = de titel van de gekozen pagina.' ),
									array( 'key' => 'field_ok_kaart_tekst', 'label' => 'Korte omschrijving', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '', 'instructions' => 'Leeg = de subtekst uit de kop van die pagina.' ),
									array( 'key' => 'field_ok_kaart_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'instructions' => 'Leeg = de uitgelichte afbeelding van de pagina, en anders de eerste foto op die pagina. Aanbevolen: 800 x 600 px (liggend).' ),
									array( 'key' => 'field_ok_kaart_link', 'label' => 'Of een eigen link', 'name' => 'link', 'type' => 'link', 'instructions' => 'Alleen nodig als de kaart niet naar een pagina hierboven wijst. Een link hier wint van de gekozen pagina.' ),
								),
							),
						),
					),

					'layout_juridisch' => array(
						'key'        => 'layout_juridisch',
						'name'       => 'juridisch',
						'label'      => 'Juridische pagina (index + artikelen)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Juridisch' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/juridisch.png',
						'sub_fields' => array(
							array(
								'key'     => 'field_jr_uitleg',
								'label'   => '',
								'type'    => 'message',
								'message' => 'Voor juridische pagina\'s: algemene voorwaarden, privacyverklaring, cookieverklaring. De nummering (1. 2. 3.) en de index links tellen vanzelf mee met de artikelen hieronder — je hoeft ze niet zelf te nummeren of te koppelen.',
							),
							array(
								'key'          => 'field_jr_kruimelpad',
								'label'        => 'Kruimelpad-label',
								'name'         => 'kruimelpad',
								'type'         => 'text',
								'instructions' => 'Leeg = de titel hieronder.',
							),
							array(
								'key'          => 'field_jr_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Leeg = de paginatitel.',
								'placeholder'  => 'Algemene voorwaarden',
							),
							array(
								'key'          => 'field_jr_datum',
								'label'        => 'Laatst bijgewerkt',
								'name'         => 'datum',
								'type'         => 'text',
								'instructions' => 'De regel onder de titel. Leeg = de regel valt weg (bewust geen standaarddatum: een verkeerde datum op een juridische pagina is misleidend).',
								'placeholder'  => 'Laatst bijgewerkt: 25 juni 2026',
							),
							array(
								'key'          => 'field_jr_intro',
								'label'        => 'Inleiding',
								'name'         => 'intro',
								'type'         => 'wysiwyg',
								'tabs'         => 'visual',
								'toolbar'      => 'sokkies_eenvoudig',
								'media_upload' => 0,
								'instructions' => 'Staat boven het eerste artikel. Leeg = geen inleiding.',
							),
							array(
								'key'          => 'field_jr_cookiebot',
								'label'        => 'Cookiebot-ID',
								'name'         => 'cookiebot',
								'type'         => 'text',
								'instructions' => 'Alleen voor de cookieverklaring: het domain-group-ID uit Cookiebot. De verklaring wordt dan live door Cookiebot in de pagina gezet, zoals op de huidige site. Leeg = geen Cookiebot-blok.',
							),
							array(
								'key'          => 'field_jr_index_titel',
								'label'        => 'Kop boven de index',
								'name'         => 'index_titel',
								'type'         => 'text',
								'instructions' => 'Leeg = "Op deze pagina:".',
							),
							array(
								'key'          => 'field_jr_artikelen',
								'label'        => 'Artikelen',
								'name'         => 'artikelen',
								'type'         => 'repeater',
								'layout'       => 'block',
								'button_label' => 'Artikel toevoegen',
								'instructions' => 'Elk artikel wordt automatisch genummerd en krijgt een eigen regel in de index. Lege rijen worden overgeslagen.',
								'sub_fields'   => array(
									array( 'key' => 'field_jr_art_titel', 'label' => 'Kop', 'name' => 'titel', 'type' => 'text', 'instructions' => 'Zonder nummer — die telt vanzelf.' ),
									array( 'key' => 'field_jr_art_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'wysiwyg', 'tabs' => 'all', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 0, 'instructions' => 'Selecteer woorden en gebruik de linkknop om ze te linken. Een tabel plak je vanuit Word/Excel/Google Docs, of je zet hem via het tabblad Tekst in HTML; de opmaak komt uit de stylesheet.' ),
								),
							),
							array(
								'key'           => 'field_jr_print',
								'label'         => 'Printknop tonen',
								'name'          => 'print_knop',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
								'instructions'  => 'Het printicoon rechtsboven de tekst.',
							),
						),
					),

					'layout_cta_final' => array(
						'key'        => 'layout_cta_final',
						'name'       => 'cta_final',
						'label'      => 'Afsluitend actieblok (rood paneel)',
						'display'    => 'block',
						'acfe_flexible_category'  => array( 'Actieblokken' ),
						'acfe_flexible_thumbnail' => get_template_directory_uri() . '/assets/acf-previews/cta_final.png',
						'sub_fields' => array(
							array(
								'key'          => 'field_cta_titel',
								'label'        => 'Titel',
								'name'         => 'titel',
								'type'         => 'text',
								'instructions' => 'Regelafbraak mag met <br>; een geel deel zet je tussen [ ] óf in <span>…</span>. Leeg = standaardtekst.',
								'placeholder'  => 'Klaar om jouw eigen<br>sokken te ontwerpen?',
							),
							array(
								'key'         => 'field_cta_subtekst',
								'label'       => 'Subtekst',
								'name'        => 'subtekst',
								'type'        => 'text',
								'placeholder' => 'Binnen 24 uur digitaal ontwerp in je inbox',
							),
							array(
								'key'          => 'field_cta_knop',
								'label'        => 'Knop',
								'name'         => 'knop',
								'type'         => 'link',
								'instructions' => 'Leeg = standaardknop naar de offertepagina.',
							),
							array(
								'key'           => 'field_cta_feet',
								'label'         => 'Sokken-voetjes tonen',
								'name'          => 'sokken_voetjes',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 1,
							),
							array(
								'key'               => 'field_cta_feet_positie',
								'label'             => 'Voetjes-positie',
								'name'              => 'voetjes_positie',
								'type'              => 'button_group',
								'choices'           => array(
									'achter' => 'Achter het rode paneel',
									'over'   => 'Over het rode paneel',
								),
								'default_value'     => 'achter',
								'conditional_logic' => array( array( array( 'field' => 'field_cta_feet', 'operator' => '==', 'value' => '1' ) ) ),
							),
							array(
								'key'               => 'field_cta_feet_foto',
								'label'             => 'Voetjes-foto',
								'name'              => 'voetjes_foto',
								'type'              => 'image',
								'return_format'     => 'array',
								'preview_size'      => 'medium',
								'instructions'      => 'Leeg = de standaardfoto (sokkenbenen). Een PNG met transparante achtergrond werkt het mooist. Aanbevolen: 1200 x 1030 px (liggend, 7:6).',
								'conditional_logic' => array( array( array( 'field' => 'field_cta_feet', 'operator' => '==', 'value' => '1' ) ) ),
							),
							array(
								'key'          => 'field_cta_knop_2',
								'label'        => 'Knop 2 (wit, optioneel)',
								'name'         => 'knop_2',
								'type'         => 'link',
								'instructions' => 'Gevuld = twee knoppen naast elkaar (zoals op Over ons en Duurzaamheid).',
							),
							array(
								'key'           => 'field_cta_contactregel',
								'label'         => 'Contactregel onder de knop',
								'name'          => 'contactregel',
								'type'          => 'true_false',
								'ui'            => 1,
								'default_value' => 0,
								'instructions'  => '"Of bel … • WhatsApp …" — nummers komen uit Website-instellingen.',
							),
						),
					),

				),
			),
			array(
				'key'           => 'field_sokkies_mobiele_balk',
				'label'         => 'Vaste knoppenbalk op mobiel',
				'name'          => 'mobiele_balk',
				'type'          => 'select',
				'choices'       => array(
					'geen'         => 'Geen',
					'knop'         => 'Eén knop (Gratis ontwerp aanvragen)',
					'twee_knoppen' => 'Twee knoppen (offerte + collectie)',
					'contact'      => 'Contactbalk (bel/WhatsApp/e-mail)',
				),
				'default_value' => 'geen',
				'instructions'  => 'De balk die op telefoons onder in beeld blijft staan.',
			),
			array(
				'key'           => 'field_sokkies_header_variant',
				'label'         => 'Header',
				'name'          => 'header_variant',
				'type'          => 'button_group',
				'choices'       => array(
					'volledig' => 'Volledige header (menu)',
					'landing'  => 'Landingsheader (logo, telefoon en knop — geen menu)',
				),
				'default_value' => 'volledig',
				'instructions'  => 'De landingsheader houdt bezoekers op de pagina: geen menu, wel het telefoonnummer en de gele knop uit Website-instellingen.',
			),
			array(
				'key'           => 'field_sokkies_footer_variant',
				'label'         => 'Footer',
				'name'          => 'footer_variant',
				'type'          => 'button_group',
				'choices'       => array(
					'volledig' => 'Volledige footer',
					'mini'     => 'Mini-footer (funnelpagina\'s)',
				),
				'default_value' => 'volledig',
			),
			array(
				'key'           => 'field_sokkies_promo_kaart',
				'label'         => 'Promokaart op deze pagina',
				'name'          => 'promo_kaart',
				'type'          => 'button_group',
				'choices'       => array( 'aan' => 'Tonen', 'uit' => 'Verbergen' ),
				'default_value' => 'aan',
				'instructions'  => 'De zwevende kaart linksonder (inhoud via Website-instellingen → Promokaart). Niet op mobiel en niet bij de mini-footer — conform het ontwerp.',
				// Bij de mini-footer (funnel/contact) rendert de kaart nooit (ontwerp);
				// veld verbergen zodat de keuze daar niet ten onrechte wordt aangeboden.
				'conditional_logic' => array( array( array( 'field' => 'field_sokkies_footer_variant', 'operator' => '!=', 'value' => 'mini' ) ) ),
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'page',
				),
			),
		),
		'hide_on_screen' => array( 'the_content' ),
	) );

	// —— Opties-pagina: Website-instellingen (contactgegevens & cijfers) ——
	if ( function_exists( 'acf_add_options_page' ) ) {
		acf_add_options_page( array(
			'page_title' => 'Website-instellingen',
			'menu_title' => 'Website-instellingen',
			'menu_slug'  => 'sokkies-instellingen',
			'capability' => 'manage_options',
			'icon_url'   => 'dashicons-admin-settings',
			'position'   => 25,
			'redirect'   => false,
		) );
	}

	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_instellingen',
		'title'  => 'Website-instellingen',
		'fields' => array(
			array( 'key' => 'field_si_tab_contact', 'label' => 'Contactgegevens', 'type' => 'tab' ),
			array(
				'key'           => 'field_si_telefoon_weergave',
				'label'         => 'Telefoonnummer (weergave)',
				'name'          => 'telefoon_weergave',
				'type'          => 'text',
				'instructions'  => 'Zo staat het nummer op de site.',
				'default_value' => '+31 (0)413 410 411',
			),
			array(
				'key'           => 'field_si_telefoon_internationaal',
				'label'         => 'Telefoonnummer (internationaal)',
				'name'          => 'telefoon_internationaal',
				'type'          => 'text',
				'instructions'  => 'Met landcode, zonder spaties — voor bel- en WhatsApp-links. Bijv. +31413410411.',
				'default_value' => '+31413410411',
			),
			array(
				'key'           => 'field_si_email',
				'label'         => 'E-mailadres',
				'name'          => 'email',
				'type'          => 'email',
				'default_value' => 'info@sokkies.nl',
			),
			array(
				'key'           => 'field_si_adres',
				'label'         => 'Adres',
				'name'          => 'adres',
				'type'          => 'textarea',
				'rows'          => 3,
				'new_lines'     => '',
				'instructions'  => 'Elke adresregel op een eigen regel. Gewoon enter gebruiken; een &lt;br&gt; typen hoeft niet.',
				'default_value' => "De Morgenstond 45,\n5473 HE, Heeswijk Dinther\nNederland",
			),
			array( 'key' => 'field_si_tab_cijfers', 'label' => 'Cijfers & reviews', 'type' => 'tab' ),
			array(
				'key'           => 'field_si_review_score',
				'label'         => 'Review-score',
				'name'          => 'review_score',
				'type'          => 'text',
				'default_value' => '9.5/10',
			),
			array(
				'key'           => 'field_si_review_aantal',
				'label'         => 'Aantal reviews',
				'name'          => 'review_aantal',
				'type'          => 'text',
				'instructions'  => 'Bijv. 450+ — toont als "uit 450+ reviews".',
				'default_value' => '450+',
			),
			array(
				'key'           => 'field_si_minimale_afname',
				'label'         => 'Minimale afname (paar)',
				'name'          => 'minimale_afname',
				'type'          => 'number',
				'instructions'  => 'Het aantal dat overal op de site staat: de topbalk, het uitklapmenu, de kaarten op de collectiepagina, de pluspunten-blokken, waar de slider van de prijscalculator begint en het minimum van het offerte- en sampleformulier. Eén keer hier wijzigen is genoeg. Staat het getal midden in een tekst (een pluspunt, een rij in de vergelijkingstabel, een FAQ-antwoord)? Typ daar {minimum} in plaats van het getal, dan volgt die tekst dit veld ook.',
				'default_value' => 50,
			),
			array( 'key' => 'field_si_tab_promo', 'label' => 'Promokaart', 'type' => 'tab' ),
			array( 'key' => 'field_si_promo_actief', 'label' => 'Promokaart tonen', 'name' => 'promo_actief', 'type' => 'true_false', 'ui' => 1, 'default_value' => 1, 'instructions' => 'De zwevende kaart linksonder. Per pagina uit te zetten bij de pagina-instellingen.' ),
			array( 'key' => 'field_si_promo_foto', 'label' => 'Afbeelding', 'name' => 'promo_foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 340 x 340 px (vierkant).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
			array( 'key' => 'field_si_promo_titel', 'label' => 'Titel', 'name' => 'promo_titel', 'type' => 'text', 'instructions' => 'Leeg = "Bekijk onze kerstcollectie".' ),
			array( 'key' => 'field_si_promo_tekst', 'label' => 'Tekst', 'name' => 'promo_tekst', 'type' => 'text', 'instructions' => 'Leeg = "Bestel op tijd voor de feestdagen.".' ),
			array( 'key' => 'field_si_promo_link', 'label' => 'Link', 'name' => 'promo_link', 'type' => 'link', 'instructions' => 'Leeg = de collectiepagina.' ),
			array( 'key' => 'field_si_tab_hoofdmenu', 'label' => 'Hoofdmenu', 'type' => 'tab' ),
			array(
				'key'          => 'field_si_hoofdmenu',
				'label'        => 'Menu-items',
				'name'         => 'hoofdmenu',
				'type'         => 'repeater',
				'layout'       => 'block',
				'button_label' => 'Menu-item toevoegen',
				'instructions' => 'De items in de bovenbalk, van links naar rechts — sleep om de volgorde te wijzigen. Helemaal leeg = het standaardmenu (Home, Sokkencollectie, Configurator, Inspiratie, Werkwijze, Over ons, Contact).

Het item is vanzelf gemarkeerd als "huidige pagina" wanneer de bezoeker op de gekoppelde pagina staat.',
				'sub_fields'   => array(
					array(
						'key'          => 'field_si_hm_label',
						'label'        => 'Label',
						'name'         => 'label',
						'type'         => 'text',
						'instructions' => 'De tekst in het menu. Leeg = de titel van de link.',
					),
					array(
						'key'          => 'field_si_hm_link',
						'label'        => 'Link',
						'name'         => 'link',
						'type'         => 'link',
						'instructions' => 'Kies een pagina of vul een eigen adres in.',
					),
					array(
						'key'           => 'field_si_hm_mega',
						'label'         => 'Uitklapmenu tonen',
						'name'          => 'mega',
						'type'          => 'true_false',
						'ui'            => 1,
						'default_value' => 0,
						'instructions'  => 'Hangt het sokkencollectie-uitklapmenu onder dit item (inhoud staat op het tabblad hiernaast). Zet dit bij ÉÉN item aan.',
					),
					array(
						'key'           => 'field_si_hm_mobiel',
						'label'         => 'Alleen in het mobiele menu',
						'name'          => 'alleen_mobiel',
						'type'          => 'true_false',
						'ui'            => 1,
						'default_value' => 0,
						'instructions'  => 'Verbergt het item op desktop. Zo staat "Home" in het ontwerp alleen in het mobiele uitklapmenu.',
					),
					array(
						'key'          => 'field_si_hm_actief_bij',
						'label'        => 'Ook oplichten op',
						'name'         => 'actief_bij',
						'type'         => 'post_object',
						'post_type'    => array( 'page' ),
						'multiple'     => 1,
						'return_format'=> 'id',
						'ui'           => 1,
						'allow_null'   => 1,
						'instructions' => 'Extra pagina\'s waarbij dit item als huidige pagina telt. Nodig bij verzamelitems: "Inspiratie" licht zo ook op bij Toepassingen, Reviews en cases en Downloads.',
					),
				),
			),

			array(
				'key'     => 'field_si_cta_uitleg',
				'label'   => '',
				'type'    => 'message',
				'message' => 'De gele knop rechts in de bovenbalk. In het ontwerp was dit een knop zonder link; hier stel je label en bestemming in.',
			),
			array(
				'key'           => 'field_si_cta_tonen',
				'label'         => 'Knop tonen',
				'name'          => 'cta_tonen',
				'type'          => 'true_false',
				'ui'            => 1,
				'default_value' => 1,
			),
			array(
				'key'          => 'field_si_cta_label',
				'label'        => 'Knoptekst',
				'name'         => 'cta_label',
				'type'         => 'text',
				'instructions' => 'Leeg = "Gratis ontwerp aanvragen".',
				'placeholder'  => 'Gratis ontwerp aanvragen',
			),
			array(
				'key'          => 'field_si_cta_link',
				'label'        => 'Knoplink',
				'name'         => 'cta_link',
				'type'         => 'link',
				'instructions' => 'Leeg = de offertepagina.',
			),

			array( 'key' => 'field_si_tab_footermenu', 'label' => 'Footermenu', 'type' => 'tab' ),
			array(
				'key'          => 'field_si_footer_titel',
				'label'        => 'Kop boven de kolommen',
				'name'         => 'footer_titel',
				'type'         => 'text',
				'instructions' => 'Leeg = "Sokkies".',
			),
			array(
				'key'          => 'field_si_footermenu',
				'label'        => 'Links',
				'name'         => 'footermenu',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Link toevoegen',
				'instructions' => 'De linklijst in de footer, verdeeld over twee kolommen — sleep om de volgorde te wijzigen. Helemaal leeg = de standaardlijst uit het ontwerp.',
				'sub_fields'   => array(
					array(
						'key'          => 'field_si_fm_label',
						'label'        => 'Label',
						'name'         => 'label',
						'type'         => 'text',
						'instructions' => 'Leeg = de titel van de link.',
					),
					array(
						'key'          => 'field_si_fm_link',
						'label'        => 'Link',
						'name'         => 'link',
						'type'         => 'link',
					),
					array(
						'key'           => 'field_si_fm_kolom',
						'label'         => 'Kolom',
						'name'          => 'kolom',
						'type'          => 'button_group',
						'choices'       => array( '1' => 'Links', '2' => 'Rechts' ),
						'default_value' => '1',
						'instructions'  => 'In welke van de twee kolommen het item staat.',
					),
					array(
						'key'          => 'field_si_fm_talen',
						'label'        => 'Alleen in deze talen',
						'name'         => 'talen',
						'type'         => 'checkbox',
						'choices'      => sokkies_taal_keuzes(),
						'layout'       => 'vertical',
						'instructions' => 'Niets aanvinken = de link staat in ALLE talen (zo staan alle bestaande links ingesteld). Vink je talen aan, dan verschijnt de link alleen in die talen — bijvoorbeeld het Impressum, dat een Duitse wettelijke plicht is en alleen in de Duitse footer hoort. De pagina zelf blijft in elke taal bereikbaar via de URL; dit verbergt alleen de link.',
					),
				),
			),

			/* ── Footer-inhoud ────────────────────────────────────────────────
			   Alles ONDER en NAAST de linkkolommen: de tekst bij het logo, de
			   keurmerken, de socials, het nieuwsbriefblok, de partnerlogo's,
			   de betaal- en verzendlogo's, de reviewblokken en de slotregel.
			   De linkkolommen zelf staan op het tabblad Footermenu hiernaast.

			   Overal geldt de vaste regel van dit thema: LEEG = de inhoud uit
			   het ontwerp. Wie niets invult ziet exact wat er nu staat. */
			array( 'key' => 'field_si_tab_footer', 'label' => 'Footer-inhoud', 'type' => 'tab' ),
			array(
				'key'          => 'field_si_fi_intro',
				'label'        => 'Tekst onder het logo',
				'name'         => 'footer_intro',
				'type'         => 'textarea',
				'rows'         => 3,
				'new_lines'    => '',
				'instructions' => 'Leeg = de tekst uit het ontwerp.',
			),
			array(
				'key'          => 'field_si_fi_certs_label',
				'label'        => 'Label bij de keurmerken',
				'name'         => 'footer_certs_label',
				'type'         => 'text',
				'instructions' => 'Leeg = "Gecertificeerd".',
			),
			array(
				'key'          => 'field_si_fi_certs',
				'label'        => 'Keurmerken',
				'name'         => 'footer_certs',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Keurmerk toevoegen',
				'instructions' => 'Leeg = OEKO-TEX en BSCI.',
				'sub_fields'   => array(
					array( 'key' => 'field_si_fi_cert_logo', 'label' => 'Logo', 'name' => 'logo', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
				),
			),
			array(
				'key'          => 'field_si_fi_socials',
				'label'        => 'Social media',
				'name'         => 'footer_socials',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Social toevoegen',
				'instructions' => 'Het icoon hoort bij het gekozen platform en zit in het thema. Leeg = LinkedIn, Facebook en Instagram.',
				'sub_fields'   => array(
					array(
						'key'     => 'field_si_fi_social_platform',
						'label'   => 'Platform',
						'name'    => 'platform',
						'type'    => 'select',
						'choices' => array(
							'linkedin'  => 'LinkedIn',
							'facebook'  => 'Facebook',
							'instagram' => 'Instagram',
							'tiktok'    => 'TikTok',
						),
						'default_value' => 'linkedin',
					),
					array( 'key' => 'field_si_fi_social_url', 'label' => 'Adres', 'name' => 'url', 'type' => 'url' ),
				),
			),
			array(
				'key'          => 'field_si_fi_news_titel',
				'label'        => 'Nieuwsbrief — kop',
				'name'         => 'footer_news_titel',
				'type'         => 'text',
				'instructions' => 'Leeg = "Mis niets".',
			),
			array(
				'key'          => 'field_si_fi_news_tekst',
				'label'        => 'Nieuwsbrief — regel erboven',
				'name'         => 'footer_news_tekst',
				'type'         => 'text',
				'instructions' => 'Leeg = "Of schrijf je in voor de nieuwsbrief".',
			),
			array(
				'key'          => 'field_si_fi_partners_label',
				'label'        => 'Label bij de goede doelen',
				'name'         => 'footer_partners_label',
				'type'         => 'text',
				'instructions' => 'Leeg = "In samenwerking met".',
			),
			array(
				'key'          => 'field_si_fi_partners',
				'label'        => 'Goede doelen',
				'name'         => 'footer_partners',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Logo toevoegen',
				'instructions' => 'Leeg = One Tree Planted en Voedselbanken.',
				'sub_fields'   => array(
					array( 'key' => 'field_si_fi_partner_logo', 'label' => 'Logo', 'name' => 'logo', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
					array( 'key' => 'field_si_fi_partner_link', 'label' => 'Link', 'name' => 'link', 'type' => 'url', 'instructions' => 'Leeg = geen link.' ),
				),
			),
			array(
				'key'          => 'field_si_fi_pay_label',
				'label'        => 'Label bij de betaalmethoden',
				'name'         => 'footer_pay_label',
				'type'         => 'text',
				'instructions' => 'Leeg = "Betaal eenvoudig".',
			),
			array(
				'key'          => 'field_si_fi_pay',
				'label'        => 'Betaalmethoden',
				'name'         => 'footer_pay',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Logo toevoegen',
				'instructions' => 'Leeg = de negen logo\'s uit het ontwerp.',
				'sub_fields'   => array(
					array( 'key' => 'field_si_fi_pay_logo', 'label' => 'Logo', 'name' => 'logo', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
				),
			),
			array(
				'key'          => 'field_si_fi_ship_label',
				'label'        => 'Label bij de verzendpartners',
				'name'         => 'footer_ship_label',
				'type'         => 'text',
				'instructions' => 'Leeg = "Onze verzendpartners".',
			),
			array(
				'key'          => 'field_si_fi_ship',
				'label'        => 'Verzendpartners',
				'name'         => 'footer_ship',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Logo toevoegen',
				'instructions' => 'Leeg = FedEx, PostNL, UPS, DPD en DHL.',
				'sub_fields'   => array(
					array( 'key' => 'field_si_fi_ship_logo', 'label' => 'Logo', 'name' => 'logo', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
				),
			),
			array(
				'key'          => 'field_si_fi_reviews',
				'label'        => 'Reviewblokken',
				'name'         => 'footer_reviews',
				'type'         => 'repeater',
				'layout'       => 'row',
				'button_label' => 'Reviewblok toevoegen',
				'instructions' => 'De blokken onderaan met het cijfer en de sterren. Leeg = Feedback Company en Google.',
				'sub_fields'   => array(
					array( 'key' => 'field_si_fi_rev_logo', 'label' => 'Logo', 'name' => 'logo', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
					array( 'key' => 'field_si_fi_rev_score', 'label' => 'Cijfer', 'name' => 'score', 'type' => 'text', 'instructions' => 'Bijvoorbeeld 9.5/10.' ),
					array( 'key' => 'field_si_fi_rev_aantal', 'label' => 'Aantal', 'name' => 'aantal', 'type' => 'text', 'instructions' => 'Bijvoorbeeld 300+. Komt te staan als "uit 300+ reviews".' ),
					array( 'key' => 'field_si_fi_rev_link', 'label' => 'Link naar de reviews', 'name' => 'link', 'type' => 'url' ),
				),
			),
			array(
				'key'          => 'field_si_fi_copyright',
				'label'        => 'Slotregel — eerste deel',
				'name'         => 'footer_copyright',
				'type'         => 'text',
				'instructions' => 'Leeg = "© 2026 Sokkies". Let op: het jaartal verandert niet vanzelf.',
			),
			array(
				'key'          => 'field_si_fi_kvk',
				'label'        => 'KVK-nummer',
				'name'         => 'footer_kvk',
				'type'         => 'text',
				'instructions' => 'Leeg = 89538226. Alleen het nummer; "KVK:" staat er al voor.',
			),
			array(
				'key'          => 'field_si_fi_btw',
				'label'        => 'BTW-nummer',
				'name'         => 'footer_btw',
				'type'         => 'text',
				'instructions' => 'Leeg = NL865014218B01. Alleen het nummer; "BTW:" staat er al voor.',
			),
			array(
				'key'          => 'field_si_fi_legal',
				'label'        => 'Juridische links',
				'name'         => 'footer_legal',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Link toevoegen',
				'instructions' => 'Staan tussen de slotregel en het KVK-nummer. Leeg = Algemene voorwaarden en Cookieverklaring.',
				'sub_fields'   => array(
					array( 'key' => 'field_si_fi_legal_label', 'label' => 'Label', 'name' => 'label', 'type' => 'text' ),
					array( 'key' => 'field_si_fi_legal_link', 'label' => 'Link', 'name' => 'link', 'type' => 'link' ),
					array(
						'key'          => 'field_si_fi_legal_talen',
						'label'        => 'Alleen in deze talen',
						'name'         => 'talen',
						'type'         => 'checkbox',
						'choices'      => sokkies_taal_keuzes(),
						'layout'       => 'vertical',
						'instructions' => 'Niets aanvinken = in ALLE talen. Zelfde regel als bij het Footermenu hiernaast: het Impressum staat alleen in het Duits.',
					),
				),
			),

			array( 'key' => 'field_si_tab_mega', 'label' => 'Uitklapmenu (Sokkencollectie)', 'type' => 'tab' ),
			array(
				'key'           => 'field_si_mega_bestsellers',
				'label'         => 'Bestsellers (4 grote kaarten)',
				'name'          => 'mega_bestsellers',
				'type'          => 'relationship',
				'post_type'     => array( 'sokkies_soktype' ),
				'filters'       => array( 'search' ),
				'return_format' => 'id',
				'max'           => 4,
				'instructions'  => 'De vier grote kaarten in het uitklapmenu. Foto en prijs komen van het soktype zelf.',
			),
			array(
				'key'           => 'field_si_mega_types',
				'label'         => 'Meer types (kleine rij)',
				'name'          => 'mega_meer_types',
				'type'          => 'relationship',
				'post_type'     => array( 'sokkies_soktype' ),
				'filters'       => array( 'search' ),
				'return_format' => 'id',
				'instructions'  => 'De kleine lijst naast de bestsellers. Gebruikt de "Korte naam (menu)" van het soktype als die is ingevuld.',
			),
			array(
				'key'          => 'field_si_mega_usps',
				'label'        => 'Pluspunten in het menu',
				'name'         => 'mega_usps',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Pluspunt toevoegen',
				'instructions' => 'De regel "Vanaf X paar" staat er altijd automatisch boven (uit het veld Minimale afname). Leeg = "Gratis ontwerp binnen 24u" en "Gratis verzending".',
				'sub_fields'   => array(
					array( 'key' => 'field_si_mega_usp_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
				),
			),

			/* ── Aanvullende opties ───────────────────────────────────────────
			   De vier kaartjes bij "Aanvullende opties" op het offerteformulier.
			   De soktypekaarten halen hun foto van het soktype zelf, maar deze
			   vier zijn geen soktype en hebben dus geen eigen post; daarom
			   staan ze hier bij de website-instellingen.
			   Leeg laten mag: dan valt de kaart terug op het beeld uit het
			   thema, zoals het nu ook staat. ───────────────────────────────── */
			/* ── Productbadges ────────────────────────────────────────────────
			   Rick vroeg of Sokkies zelf badges kan toevoegen (feedback). De
			   lijst stond hardgecodeerd in het thema (alleen Bestseller en
			   Nieuw); nu staat hij hier. Leeg laten mag: dan blijven precies
			   die twee bestaan, dus de site verandert pas als iemand hier iets
			   invult. ─────────────────────────────────────────────────────── */
			array( 'key' => 'field_si_tab_badges', 'label' => 'Productbadges', 'type' => 'tab' ),
			array(
				'key'          => 'field_si_badges',
				'label'        => 'Badges',
				'name'         => 'badges',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Badge toevoegen',
				'instructions' => 'De badges die je per soktype kunt kiezen (Soktypes &rsaquo; een soktype &rsaquo; "Badge op de kaart"). Leeg = alleen Bestseller en Nieuw, zoals nu. LET OP: hernoem je een badge, dan moet je hem op de soktypes opnieuw kiezen — de koppeling loopt via de tekst.',
				'sub_fields'   => array(
					array(
						'key'          => 'field_si_badge_label',
						'label'        => 'Tekst op de badge',
						'name'         => 'label',
						'type'         => 'text',
						'instructions' => 'Komt in hoofdletters op de kaart te staan. Kort houden — er is weinig ruimte.',
					),
					array(
						'key'     => 'field_si_badge_kleur',
						'label'   => 'Kleur',
						'name'    => 'kleur',
						'type'    => 'select',
						'choices' => array(
							'beige'  => 'Beige (standaard)',
							'rood'   => 'Rood (opvallend)',
							'geel'   => 'Geel',
							'groen'  => 'Groen',
							'cyaan'  => 'Lichtblauw',
							'roze'   => 'Roze',
							'donker' => 'Donker',
						),
						'default_value' => 'beige',
						'allow_null'    => 0,
						'multiple'      => 0,
						'ui'            => 0,
						'ajax'          => 0,
						'return_format' => 'value',
					),
				),
			),
			array( 'key' => 'field_si_tab_extras', 'label' => 'Aanvullende opties', 'type' => 'tab' ),
			array(
				'key'          => 'field_si_extras',
				'label'        => 'Foto per optie',
				'name'         => 'offerte_extras',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Optie toevoegen',
				'instructions' => 'De kaartjes bij "Aanvullende opties" op het offerteformulier. De lijst bij Optie komt rechtstreeks uit Gravity Forms, dus kiezen is genoeg — komt er een optie bij in het formulier, dan staat hij hier vanzelf tussen. Een optie zonder foto houdt het beeld uit het thema. "Geen extra&#039;s" krijgt bewust geen foto: dat is in het ontwerp het grijze vlak.',
				'sub_fields'   => array(
					array( 'key' => 'field_si_extra_naam', 'label' => 'Optie', 'name' => 'naam', 'type' => 'text' ),
					array(
						'key'           => 'field_si_extra_foto',
						'label'         => 'Foto',
						'name'          => 'foto',
						'type'          => 'image',
						'return_format' => 'id',
						'preview_size'  => 'thumbnail',
						'library'       => 'all',
					),
					array(
						'key'          => 'field_si_extra_types',
						'label'        => 'Alleen bij deze soktypes',
						'name'         => 'soktypes',
						'type'         => 'select',
						'multiple'     => 1,
						'ui'           => 1,
						'allow_null'   => 1,
						/* ACF Extended leest deze twee ZONDER isset() uit
						   (field-select.php 196/201), dus zonder ze logt elke
						   keer dat dit scherm rendert een Undefined array key. */
						'search_placeholder' => '',
						'allow_custom'       => 0,
						'instructions' => 'Leeg = de optie staat er altijd. Kies je een of meer soktypes, dan verschijnt de kaart alleen als de bezoeker in stap 1 zo&#039;n sok kiest — en verdwijnt hij weer als hij iets anders kiest.',
					),
				),
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'options_page',
					'operator' => '==',
					'value'    => 'sokkies-instellingen',
				),
			),
		),
	) );

	// —— Opties-subpagina: Prijzen & staffels (bron van de calculator) ——
	if ( function_exists( 'acf_add_options_sub_page' ) ) {
		acf_add_options_sub_page( array(
			'page_title'  => 'Prijzen & staffels',
			'menu_title'  => 'Prijzen & staffels',
			'parent_slug' => 'sokkies-instellingen',
			'menu_slug'   => 'sokkies-prijzen',
			'capability'  => 'manage_options',
		) );
	}

	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_prijzen',
		'title'  => 'Prijzen & staffels',
		'fields' => array(
			array(
				'key'          => 'field_prijzen_staffel',
				'label'        => 'Staffelprijzen per soktype',
				'name'         => 'staffel',
				'type'         => 'repeater',
				'layout'       => 'block',
				'button_label' => 'Soktype toevoegen',
				'instructions' => 'Dit is de prijsbron voor álle calculators op de site. Volgorde = volgorde in de keuzelijst; het eerste type staat standaard geselecteerd.',
				'sub_fields'   => array(
					array(
						'key'   => 'field_st_naam',
						'label' => 'Naam in de keuzelijst',
						'name'  => 'naam',
						'type'  => 'text',
					),
					array(
						'key'          => 'field_st_prijzen',
						'label'        => 'Staffel',
						'name'         => 'prijzen',
						'type'         => 'repeater',
						'layout'       => 'table',
						'button_label' => 'Staffelregel toevoegen',
						'sub_fields'   => array(
							array( 'key' => 'field_st_vanaf', 'label' => 'Vanaf (aantal paar)', 'name' => 'vanaf', 'type' => 'number' ),
							array( 'key' => 'field_st_prijs', 'label' => 'Prijs per paar (€)', 'name' => 'prijs', 'type' => 'number', 'step' => '0.01' ),
						),
					),
				),
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'options_page',
					'operator' => '==',
					'value'    => 'sokkies-prijzen',
				),
			),
		),
	) );

	// —— Veldgroep op de Veelgestelde vragen-CPT ——
	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_faq',
		'title'  => 'Antwoord',
		'fields' => array(
			array(
				'key'          => 'field_faq_antwoord',
				'label'        => 'Antwoord',
				'name'         => 'antwoord',
				'type'         => 'wysiwyg',
				'tabs'         => 'all',
				'toolbar'      => 'sokkies_eenvoudig',
				'media_upload' => 0,
				'instructions' => 'Het antwoord op de vraag (de vraag zelf is de titel hierboven).',
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'sokkies_faq',
				),
			),
		),
	) );

	// —— FAQ-categorie: wel of niet op de algemene FAQ-pagina ——
	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_faq_cat',
		'title'  => 'Weergave',
		'fields' => array(
			array(
				'key'           => 'field_faqcat_op_faq_pagina',
				'label'         => 'Tonen op de FAQ-pagina',
				'name'          => 'toon_op_faq_pagina',
				'type'          => 'true_false',
				'ui'            => 1,
				'default_value' => 1,
				'instructions'  => 'Staat dit uit, dan komt deze hele categorie niet op /veelgestelde-vragen/ te staan — ook het knopje erboven verdwijnt. De vragen zelf blijven gewoon bestaan en blijven zichtbaar op de pagina\'s waar ze gekozen zijn (bijvoorbeeld een productpagina). Staat dit aan, dan verschijnen alleen de vragen die NIET aan een soktype gekoppeld zijn.',
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'taxonomy',
					'operator' => '==',
					'value'    => 'sokkies_faq_cat',
				),
			),
		),
	) );


	// —— Merklogo: in welke talen verschijnt dit logo ——
	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_logo',
		'title'  => 'Zichtbaarheid',
		'fields' => array(
			array(
				'key'           => 'field_logo_talen',
				'label'         => 'Tonen in deze talen',
				'name'          => 'talen',
				'type'          => 'checkbox',
				'choices'       => sokkies_taal_keuzes(),
				'layout'        => 'horizontal',
				'instructions'  => 'Niets aanvinken = het logo verschijnt in ALLE talen (zo werkt het nu). Vink talen aan om het logo alleen daar te tonen — handig als de Franse of Duitse site andere merken laat zien.',
				'return_format' => 'value',
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'sokkies_logo',
				),
			),
		),
	) );

	// —— Opties-subpagina: vaste productpagina-secties (1x bewerken → alle
	// soktypes) ——
	if ( function_exists( 'acf_add_options_sub_page' ) ) {
		acf_add_options_sub_page( array(
			'page_title'  => 'Productpagina — vaste secties',
			'menu_title'  => 'Productpagina',
			'parent_slug' => 'sokkies-instellingen',
			'menu_slug'   => 'sokkies-pdp-secties',
			'capability'  => 'manage_options',
		) );
	}

	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_pdp_secties',
		'title'  => 'Vaste secties op alle productpagina\'s',
		'fields' => array(
			array( 'key' => 'field_pps_tab_beloftes', 'label' => 'Onze beloftes', 'type' => 'tab' ),
			array(
				'key'          => 'field_pps_beloftes',
				'label'        => 'Belofte-kaarten',
				'name'         => 'pdp_beloftes',
				'type'         => 'repeater',
				'layout'       => 'block',
				'button_label' => 'Belofte toevoegen',
				'sub_fields'   => array(
					array( 'key' => 'field_pps_belofte_icoon', 'label' => 'Icoon', 'name' => 'icoon', 'type' => 'image', 'instructions' => 'Aanbevolen: 140 x 140 px, of een SVG.', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
					array( 'key' => 'field_pps_belofte_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
					array( 'key' => 'field_pps_belofte_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
				),
			),
			array(
				'key'          => 'field_pps_chips',
				'label'        => 'Pluspunten-rij eronder',
				'name'         => 'pdp_beloftes_chips',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Pluspunt toevoegen',
				'sub_fields'   => array(
					array( 'key' => 'field_pps_chip_icoon', 'label' => 'Icoon', 'name' => 'icoon', 'type' => 'image', 'instructions' => 'Aanbevolen: 100 x 100 px, of een SVG.', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
					array( 'key' => 'field_pps_chip_label', 'label' => 'Tekst', 'name' => 'label', 'type' => 'text' ),
				),
			),
			array( 'key' => 'field_pps_tab_weave', 'label' => 'Druktechniek', 'type' => 'tab' ),
			array( 'key' => 'field_pps_weave_titel', 'label' => 'Titel', 'name' => 'pdp_weave_titel', 'type' => 'text', 'instructions' => 'Leeg = "Geweven vs. sublimatiedruk".' ),
			array(
				'key'          => 'field_pps_weave_kaarten',
				'label'        => 'Vergelijkingskaarten (2)',
				'name'         => 'pdp_weave_kaarten',
				'type'         => 'repeater',
				'layout'       => 'block',
				'min'          => 2,
				'max'          => 2,
				'button_label' => 'Kaart toevoegen',
				'instructions'  => 'Kaart 1 = de groene "Onze methode"-kaart, kaart 2 = de rode vergelijkingskaart (vaste opmaakrollen).',
				'sub_fields'   => array(
					array( 'key' => 'field_pps_wk_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 1650 x 840 px (breed liggend, 2:1).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
					array( 'key' => 'field_pps_wk_tag', 'label' => 'Label (bijv. Onze methode)', 'name' => 'tag', 'type' => 'text' ),
					array( 'key' => 'field_pps_wk_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
					array( 'key' => 'field_pps_wk_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
					array(
						'key'          => 'field_pps_wk_punten',
						'label'        => 'Punten',
						'name'         => 'punten',
						'type'         => 'repeater',
						'layout'       => 'table',
						'button_label' => 'Punt toevoegen',
						'sub_fields'   => array(
							array( 'key' => 'field_pps_wk_punt_kop', 'label' => 'Dikgedrukt', 'name' => 'kop', 'type' => 'text' ),
							array( 'key' => 'field_pps_wk_punt_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'text' ),
						),
					),
				),
			),
			array( 'key' => 'field_pps_tab_design', 'label' => 'Ontwerp-promo', 'type' => 'tab' ),
			array( 'key' => 'field_pps_design_titel', 'label' => 'Titel', 'name' => 'pdp_design_titel', 'type' => 'text', 'instructions' => 'Leeg = "Ontwerp je sokken nu zelf".' ),
			array( 'key' => 'field_pps_design_foto', 'label' => 'Voorbeeld-afbeelding', 'name' => 'pdp_design_foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 2280 x 1240 px (breed liggend, 16:9).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
			array( 'key' => 'field_pps_design_knop', 'label' => 'Knop', 'name' => 'pdp_design_knop', 'type' => 'link', 'instructions' => 'Leeg = "Zelf ontwerpen" naar de configuratorpagina.' ),
			array( 'key' => 'field_pps_tab_usecases', 'label' => 'Toepassingen', 'type' => 'tab' ),
			array(
				'key'          => 'field_pps_usecases_titel',
				'label'        => 'Titel',
				'name'         => 'pdp_usecases_titel',
				'type'         => 'text',
				'instructions' => 'Leeg = "Voor welke bedrijven&lt;br&gt;werken {soktype}?". Gebruik {soktype} voor de naam van het soktype, dan klopt de kop op elke productpagina. &lt;br&gt; mag, voor een regelafbreking.',
			),
			array(
				'key'          => 'field_pps_usecases',
				'label'        => 'Toepassings-kaarten (precies 6)',
				'name'         => 'pdp_usecases',
				'type'         => 'repeater',
				'layout'       => 'block',
				'min'          => 6,
				'max'          => 6,
				'button_label' => 'Kaart toevoegen',
				'instructions' => 'De collage heeft 6 vaste posities; de sectietitel volgt het soktype vanzelf.',
				'sub_fields'   => array(
					array( 'key' => 'field_pps_uc_foto', 'label' => 'Foto', 'name' => 'foto', 'type' => 'image', 'instructions' => 'Aanbevolen: 920 x 760 px (liggend, 6:5).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
					array( 'key' => 'field_pps_uc_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
					array( 'key' => 'field_pps_uc_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
				),
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'options_page',
					'operator' => '==',
					'value'    => 'sokkies-pdp-secties',
				),
			),
		),
	) );

	// —— Veldgroep op de Review-CPT ——
	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_review',
		'title'  => 'Review-gegevens',
		'fields' => array(
			array( 'key' => 'field_rev_quote', 'label' => 'Quote', 'name' => 'quote', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '', 'instructions' => 'Zonder aanhalingstekens — die zet de site er zelf omheen.' ),
			array( 'key' => 'field_rev_functie', 'label' => 'Functie/bedrijf', 'name' => 'functie', 'type' => 'text', 'instructions' => 'Bijv. "HR Manager" — toont als "Naam — Functie".' ),
			array( 'key' => 'field_rev_sterren', 'label' => 'Sterren (1-5)', 'name' => 'sterren', 'type' => 'number', 'min' => 1, 'max' => 5, 'default_value' => 5 ),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'sokkies_review',
				),
			),
		),
	) );

	// —— Veldgroep op de Case-CPT ——
	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_case',
		'title'  => 'Case-gegevens',
		'fields' => array(
			array( 'key' => 'field_case_tab_overzicht', 'label' => 'Kaart & slider', 'type' => 'tab' ),
			array( 'key' => 'field_case_foto_groot', 'label' => 'Grote foto', 'name' => 'foto_groot', 'type' => 'image', 'instructions' => 'Aanbevolen: 840 x 840 px (vierkant).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
			array( 'key' => 'field_case_foto_klein_1', 'label' => 'Kleine foto (boven)', 'name' => 'foto_klein_1', 'type' => 'image', 'instructions' => 'Aanbevolen: 540 x 400 px (liggend, 4:3).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
			array( 'key' => 'field_case_foto_klein_2', 'label' => 'Kleine foto (onder)', 'name' => 'foto_klein_2', 'type' => 'image', 'instructions' => 'Aanbevolen: 540 x 400 px (liggend, 4:3).', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
			array( 'key' => 'field_case_badge', 'label' => 'Badge', 'name' => 'badge', 'type' => 'text', 'instructions' => 'Leeg = "Klantcase".' ),
			/* De drie punten op de kaart als REPEATER, zodat er ook meer of
			   minder dan drie kunnen staan en het opschrift vrij is.

			   De drie vaste velden hieronder BLIJVEN staan en blijven werken:
			   ze bevatten de inhoud van alle bestaande cases, ook op live. Een
			   veldtype omzetten zou een schemawijziging zijn en de repeater
			   leest andere meta — code deployt wel, de database niet, dus dan
			   stond live zonder kaarttekst (zie de blog-les van 2026-08-29).
			   Staat er minstens één rij in de repeater, dan wint die. */
			array(
				'key' => 'field_case_punten', 'label' => 'Punten op de kaart', 'name' => 'punten',
				'type' => 'repeater', 'layout' => 'block', 'button_label' => 'Punt toevoegen',
				'instructions' => 'Laat leeg om de drie vaste velden hieronder te blijven gebruiken. Zodra hier een rij staat, bepaalt deze lijst de regels op de kaart.',
				'sub_fields' => array(
					array( 'key' => 'field_case_punt_label', 'label' => 'Opschrift', 'name' => 'label', 'type' => 'text', 'placeholder' => 'Probleem', 'instructions' => 'Leeg = alleen de tekst, zonder opschrift.' ),
					array( 'key' => 'field_case_punt_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
				),
			),
			/* De drie regels op de kaart stonden met een vast opschrift in de
			   template (Probleem/Aanpak/Resultaat). Deze velden maken dat
			   opschrift per case aanpasbaar; leeg laten houdt het oude woord.
			   Alleen VELDEN TOEGEVOEGD, de bestaande blijven ongemoeid. */
			array( 'key' => 'field_case_probleem_label', 'label' => 'Opschrift bij Probleem', 'name' => 'probleem_label', 'type' => 'text', 'placeholder' => 'Probleem', 'instructions' => 'Leeg = Probleem.' ),
			array( 'key' => 'field_case_aanpak_label', 'label' => 'Opschrift bij Aanpak', 'name' => 'aanpak_label', 'type' => 'text', 'placeholder' => 'Aanpak', 'instructions' => 'Leeg = Aanpak.' ),
			array( 'key' => 'field_case_resultaat_label', 'label' => 'Opschrift bij Resultaat', 'name' => 'resultaat_label', 'type' => 'text', 'placeholder' => 'Resultaat', 'instructions' => 'Leeg = Resultaat.' ),
			array( 'key' => 'field_case_probleem', 'label' => 'Probleem', 'name' => 'probleem', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
			array( 'key' => 'field_case_aanpak', 'label' => 'Aanpak', 'name' => 'aanpak', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
			array( 'key' => 'field_case_resultaat', 'label' => 'Resultaat', 'name' => 'resultaat', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
			array( 'key' => 'field_case_ondertitel', 'label' => 'Kaart-ondertitel', 'name' => 'kaart_ondertitel', 'type' => 'text', 'instructions' => 'Regel op de overzichtskaart, bijv. "25.000 paar voor bloeddonoren".' ),
			array( 'key' => 'field_case_link', 'label' => 'Link (Bekijk case)', 'name' => 'link', 'type' => 'link', 'instructions' => 'Leeg = de eigen detailpagina van deze case.' ),
			array( 'key' => 'field_case_tab_detail', 'label' => 'Detailpagina', 'type' => 'tab' ),
			array( 'key' => 'field_case_intro', 'label' => 'Intro (onder de titel)', 'name' => 'intro', 'type' => 'textarea', 'rows' => 3, 'new_lines' => '', 'instructions' => 'De tekst in de paginakop van de detailpagina.' ),
			array( 'key' => 'field_case_aanleiding', 'label' => 'Hoe het ging — Aanleiding', 'name' => 'aanleiding', 'type' => 'textarea', 'rows' => 4, 'new_lines' => '' ),
			array( 'key' => 'field_case_verhaal_resultaat', 'label' => 'Hoe het ging — Resultaat', 'name' => 'verhaal_resultaat', 'type' => 'textarea', 'rows' => 4, 'new_lines' => '' ),
			array(
				'key'           => 'field_case_story_variant',
				'label'         => 'Weergave "Hoe het ging"',
				'name'          => 'story_variant',
				'type'          => 'button_group',
				'choices'       => array(
					'standaard' => 'Twee schuivende fotokolommen',
					'licht'     => 'Drie foto\'s, daaronder de tekst',
				),
				'default_value' => 'standaard',
				'instructions'  => 'Standaard: de tekst links, twee langzaam schuivende fotokolommen rechts. Licht: een stilstaande rij van maximaal drie foto\'s met het verhaal eronder — handig als er maar een paar foto\'s zijn.',
			),
			array( 'key' => 'field_case_story_fotos', 'label' => 'Foto\'s naast het verhaal', 'name' => 'story_fotos', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'Leeg = de drie kaartfoto\'s. De lichte weergave toont er maximaal drie. Aanbevolen: 860 x 860 px per foto (vierkant).' ),
			array(
				'key'          => 'field_case_specs',
				'label'        => 'Wat we maakten (specs)',
				'name'         => 'specs',
				'type'         => 'repeater',
				'layout'       => 'table',
				'button_label' => 'Spec toevoegen',
				'instructions' => 'Bijv. Soktype / Aantal paar / Kleuren / Levertijd. Leeg = sectie verborgen.',
				'sub_fields'   => array(
					array( 'key' => 'field_case_spec_label', 'label' => 'Label', 'name' => 'label', 'type' => 'text' ),
					array( 'key' => 'field_case_spec_waarde', 'label' => 'Waarde', 'name' => 'waarde', 'type' => 'text' ),
				),
			),
			array( 'key' => 'field_case_resultaat_fotos', 'label' => 'Het resultaat in beeld (3 foto\'s)', 'name' => 'resultaat_fotos', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'Leeg = sectie verborgen. Aanbevolen: 1190 x 1190 px per foto (vierkant).' ),
			array( 'key' => 'field_case_quote', 'label' => 'Quote', 'name' => 'quote', 'type' => 'textarea', 'rows' => 4, 'new_lines' => '' ),
			array( 'key' => 'field_case_quote_naam', 'label' => 'Quote — naam', 'name' => 'quote_naam', 'type' => 'text' ),
			array( 'key' => 'field_case_quote_functie', 'label' => 'Quote — functie/organisatie', 'name' => 'quote_functie', 'type' => 'text' ),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'sokkies_case',
				),
			),
		),
	) );

	// —— Veldgroep op de Blog-CPT ——
	//
	// De DATUM staat hier bewust NIET tussen: die komt uit de
	// publicatiedatum van WordPress zelf (rechterkolom bij het bewerken) en
	// wordt op de voorkant Nederlands opgemaakt. Een los datumveld ernaast
	// levert alleen maar twee data op die uit elkaar kunnen lopen.
	// De categorieën komen uit de taxonomie 'Blogcategorieën'.
	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_blog',
		'title'  => 'Bloggegevens',
		'fields' => array(
			array( 'key' => 'field_blog_foto', 'label' => 'Uitgelichte afbeelding', 'name' => 'foto', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'instructions' => 'Staat groot boven het artikel en op de kaart in het overzicht. Aanbevolen: 2280 x 1240 px (breed liggend, 16:9).' ),
			array( 'key' => 'field_blog_auteur', 'label' => 'Auteur', 'name' => 'auteur', 'type' => 'text', 'instructions' => 'De naam achter "Auteur:" boven het artikel. Leeg = de regel valt weg.' ),
			array( 'key' => 'field_blog_intro', 'label' => 'Intro', 'name' => 'intro', 'type' => 'wysiwyg', 'tabs' => 'visual', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 1, 'instructions' => 'De alinea('."'".'s) boven de eerste tussenkop. Afbeeldingen kunnen via "Media toevoegen".' ),
			array(
				/* TERUGGEDRAAID naar de repeater (2026-08-29, correctie Kulwant):
				   de eerdere ombouw naar flexible content VERVING de bestaande
				   blokstructuur, en omdat de code wél deployt en de database
				   niet, stonden alle artikelen op dev zonder tekst. De opzet is
				   nu: dezelfde tekstblokken als voorheen, met foto's en een
				   review als EXTRA, optionele velden per blok — bestaande
				   inhoud en veldsleutels blijven ongemoeid. */
				'key'          => 'field_blog_secties',
				'label'        => 'Tekstblokken',
				'name'         => 'secties',
				'type'         => 'repeater',
				'layout'       => 'block',
				'button_label' => 'Tekstblok toevoegen',
				'instructions' => 'Elk blok is een tussenkop met tekst, en optioneel een fotorij en\/of een review eronder. De kop komt er letterlijk zo op de site — wil je nummering (1. 2. 3.), typ die dan zelf.',
				'sub_fields'   => array(
					array( 'key' => 'field_blog_sectie_kop', 'label' => 'Tussenkop', 'name' => 'kop', 'type' => 'text' ),
					array( 'key' => 'field_blog_sectie_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'wysiwyg', 'tabs' => 'visual', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 1, 'instructions' => 'Ook losse afbeeldingen kunnen hier, via "Media toevoegen".' ),
					array( 'key' => 'field_blog_sectie_fotos', 'label' => 'Foto\x27s onder dit blok', 'name' => 'fotos', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'Optioneel — de indeling volgt vanzelf uit het aantal: één foto = volle breedte, twee = 50/50, drie = de eerste vol met twee eronder, vier = tweemaal 50/50. Aanbevolen: 1760 x 880 px per foto (2:1); staan er twee of drie naast elkaar, dan 880 x 880 px.' ),
					/* Eigen review per blok (verzoek Kulwant 2026-09-01): niet kiezen
					   uit de bestaande Reviews, maar rechtstreeks hier invullen. */
					array( 'key' => 'field_blog_sectie_review_quote', 'label' => 'Review onder dit blok — quote', 'name' => 'review_quote', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '', 'instructions' => 'Optioneel — de uitspraak zelf, zonder aanhalingstekens (die zet de site er zelf omheen). Leeg = geen reviewblok.' ),
					array( 'key' => 'field_blog_sectie_review_naam', 'label' => 'Review — naam', 'name' => 'review_naam', 'type' => 'text' ),
					array( 'key' => 'field_blog_sectie_review_functie', 'label' => 'Review — functie/organisatie', 'name' => 'review_functie', 'type' => 'text', 'instructions' => 'Bijv. "CEO, OneTreePlanted". Leeg = alleen de naam.' ),
					array( 'key' => 'field_blog_sectie_review_sterren', 'label' => 'Review — sterren', 'name' => 'review_sterren', 'type' => 'number', 'min' => 1, 'max' => 5, 'step' => 1, 'default_value' => 5 ),
					array( 'key' => 'field_blog_sectie_review_foto', 'label' => 'Foto\/logo bij de review', 'name' => 'review_foto', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'instructions' => 'Optioneel — zoals het OneTreePlanted-logo op de huidige site. Aanbevolen: 120 x 120 px (vierkant), of een SVG.' ),
				),
			),
			array( 'key' => 'field_blog_tab_slot', 'label' => 'Afsluitblok', 'type' => 'tab' ),
			array( 'key' => 'field_blog_slot_kop', 'label' => 'Kop', 'name' => 'slot_kop', 'type' => 'text', 'instructions' => 'Het blok onder de streep, bijv. "Deadline in zicht?". Leeg = het hele blok valt weg.' ),
			array( 'key' => 'field_blog_slot_tekst', 'label' => 'Tekst', 'name' => 'slot_tekst', 'type' => 'textarea', 'rows' => 2, 'new_lines' => '' ),
			array( 'key' => 'field_blog_slot_knop', 'label' => 'Knop', 'name' => 'slot_knop', 'type' => 'link', 'instructions' => 'Leeg = "Neem contact op" naar de contactpagina.' ),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'sokkies_blog',
				),
			),
		),
	) );

	// —— Veldgroep op de Soktype-CPT ——
	acf_add_local_field_group( array(
		'key'    => 'group_sokkies_soktype',
		'title'  => 'Soktype-gegevens',
		'fields' => array(
			array(
				'key'          => 'field_soktype_prijs',
				'label'        => 'Prijs vanaf',
				'name'         => 'prijs_vanaf',
				'type'         => 'text',
				'instructions' => 'Alleen het bedrag, bijv. €2,99 — op de site wordt het "Vanaf €2,99 per paar".',
			),
			array(
				'key'          => 'field_soktype_korte_naam',
				'label'        => 'Korte naam (menu)',
				'name'         => 'korte_naam',
				'type'         => 'text',
				'instructions' => 'Optioneel — kortere naam voor het uitklapmenu, bijv. "Yoga & pilates". Leeg = de titel.',
			),
			array(
				'key'          => 'field_soktype_formulier_keuze',
				'label'        => 'Keuze in de formulieren',
				'name'         => 'formulier_keuze',
				'type'         => 'select',
				'allow_null'   => 1,
				'ui'           => 1,
				'multiple'     => 0,
				'ajax'         => 0,
				'return_format'=> 'value',
				'search_placeholder' => '',
				'allow_custom' => 0,
				'choices'      => array(),
				'instructions' => 'Bij welke keuze op het offerte- en sampleformulier hoort dit soktype? De uitgelichte afbeelding hierboven wordt dan de foto op dat kaartje. Leeg = zelf uitzoeken op naam, wat misgaat zodra een keuze anders gaat heten.',
			),
			array(
				'key'           => 'field_soktype_badge',
				'label'         => 'Badge op de kaart',
				'name'          => 'badge',
				'type'          => 'select',
				/* De keuzes komen uit Website-instellingen > Productbadges; zie
				   sokkies_badges(). Meerdere badges mogen: ze komen naast elkaar
				   linksboven op de kaart. */
				'choices'       => array(),
				'multiple'      => 1,
				'allow_null'    => 1,
				/* ui = de keuzelijst met zoekveld en verwijderkruisjes. Zonder dit
				   rendert WordPress een kale lijst waarin je met ctrl moet klikken om
				   er twee te kiezen — dat leest niet als "meerdere mogen". */
				'ui'            => 1,
				'ajax'          => 0,
				'return_format' => 'value',
				'search_placeholder' => '',
				'allow_custom'  => 0,
				'placeholder'   => 'Geen badge',
				'instructions'  => 'Meerdere mogen. Nieuwe badges maak je aan onder Website-instellingen &rsaquo; Productbadges.',
			),
			array(
				'key'          => 'field_soktype_promotie',
				'label'        => 'Actie of promotie',
				'name'         => 'promotie_type',
				'type'         => 'select',
				/* Eén keuze is voorlopig genoeg: wel of geen actie. Komt er later
				   behoefte aan soorten (kerst, seizoen, ...), dan kunnen die er hier
				   bij; sokkies_soktype_actie_ids() kijkt alleen of er iets gekozen is. */
				'choices'      => array(
					'actie' => 'Actieproduct',
				),
				'allow_null'   => 1,
				'placeholder'  => 'Geen — hoort bij het vaste assortiment',
				'instructions' => 'Laat dit leeg voor een gewoon soktype. Kies je hier een actie, dan verdwijnt dit soktype uit de automatische "Bekijk ook deze"-slider op de andere productpagina\'s. Het blijft gewoon in de collectie staan en blijft via zijn eigen pagina bereikbaar; een handmatig gekozen lijst blijft ook ongemoeid.',
			),
			array(
				'key'          => 'field_soktype_beschrijving',
				'label'        => 'Korte beschrijving',
				'name'         => 'korte_beschrijving',
				'type'         => 'textarea',
				'rows'         => 2,
				'new_lines'    => '',
				'instructions' => 'Eén zin — wordt gebruikt op de collectiepagina.',
			),
			array(
				'key'          => 'field_soktype_link',
				'label'        => 'Kaart verwijst naar',
				'name'         => 'pagina_link',
				'type'         => 'link',
				'instructions' => 'Leeg = de eigen productpagina van dit type.',
			),
			array( 'key' => 'field_soktype_tab_pdp', 'label' => 'Productpagina', 'type' => 'tab' ),
			array( 'key' => 'field_soktype_pdp_titel', 'label' => 'Paginatitel', 'name' => 'pdp_titel', 'type' => 'text', 'instructions' => 'Leeg = "{naam} bedrukken".' ),
			array( 'key' => 'field_soktype_pdp_beschrijving', 'label' => 'Beschrijving', 'name' => 'pdp_beschrijving', 'type' => 'wysiwyg', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 0, 'tabs' => 'all', 'instructions' => 'De tekst naast de grote foto; de Specificaties-link komt er automatisch achter de laatste alinea. Vet, cursief, opsommingen en links kunnen hier — plak GEEN kale URL op een eigen regel, die wordt niet getoond. Koppen en afbeeldingen verschijnen niet op de site.' ),
			array( 'key' => 'field_soktype_pdp_fotos', 'label' => 'Productfoto\'s', 'name' => 'pdp_fotos', 'type' => 'gallery', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'insert' => 'append', 'instructions' => 'Eerste foto = grote foto; de rest wordt de miniaturenrij. Leeg = de kaartfoto. Aanbevolen: 1480 x 1480 px per foto (vierkant).' ),
			array( 'key' => 'field_soktype_pdp_video', 'label' => 'Productvideo', 'name' => 'pdp_video', 'type' => 'file', 'return_format' => 'array', 'mime_types' => 'mp4,webm,mov', 'instructions' => 'Optioneel — komt als laatste miniatuur met een afspeelknop; speelt af in het grote vak.' ),
			array( 'key' => 'field_soktype_pdp_video_still', 'label' => 'Video-miniatuur', 'name' => 'pdp_video_still', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail', 'instructions' => 'Het plaatje op de video-miniatuur. Leeg = de eerste productfoto. Aanbevolen: 280 x 280 px (vierkant).' ),
			array( 'key' => 'field_soktype_expivi_product_id', 'label' => 'Expivi-product-ID', 'name' => 'expivi_product_id', 'type' => 'number', 'min' => 0, 'step' => 1, 'instructions' => 'Het ID van dit soktype in Expivi (de 3D-configurator). Leeg = geen configurator voor dit type.' ),
			array(
				'key'          => 'field_soktype_pdp_specs',
				'label'        => 'De specs (uitklaplijst)',
				'name'         => 'pdp_specs',
				'type'         => 'repeater',
				'layout'       => 'block',
				'button_label' => 'Spec toevoegen',
				'instructions' => 'Per type, bijv. materiaal/maten/wasadvies. Leeg = de standaardset.',
				'sub_fields'   => array(
					array( 'key' => 'field_soktype_spec_titel', 'label' => 'Titel', 'name' => 'titel', 'type' => 'text' ),
					array( 'key' => 'field_soktype_spec_tekst', 'label' => 'Tekst', 'name' => 'tekst', 'type' => 'wysiwyg', 'toolbar' => 'sokkies_eenvoudig', 'media_upload' => 0, 'tabs' => 'all', 'instructions' => 'Selecteer woorden en gebruik de linkknop om ze te linken. Een tabel plak je vanuit Word/Excel/Google Docs, of je zet hem via het tabblad Tekst in HTML; de opmaak komt uit de stylesheet.' ),
				),
			),
			array(
				'key'           => 'field_soktype_faq_vragen',
				'label'         => 'Veelgestelde vragen',
				'name'          => 'faq_vragen',
				'type'          => 'relationship',
				'post_type'     => array( 'sokkies_faq' ),
				'filters'       => array( 'search', 'taxonomy' ),
				'return_format' => 'id',
				'instructions'  => 'Kies de vragen die bij dit soktype horen en sleep ze in de volgorde waarin ze op de productpagina moeten staan; de bovenste staat standaard open. Filter links op categorie om snel de vragen van dit type te vinden. LEEG = het vragenblok staat NIET op deze pagina. Nieuwe vragen maak je aan onder "Veelgestelde vragen" in het menu links.',
			),
		),
		'location' => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'sokkies_soktype',
				),
			),
		),
	) );
} );
