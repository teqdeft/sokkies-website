<?php
/**
 * Logica voor het offerteformulier ("Offerte — website", Gravity Forms).
 *
 * Drie dingen die Gravity Forms zelf niet kan en die dus hier zitten:
 *  1. maximaal twee soorten sokken kiezen
 *  2. "Geen extra's" sluit de andere extra opties uit
 *  3. adresopzoeking (postcode + huisnummer -> straat/plaats/provincie)
 *
 * Het formulier-ID staat NIET hardgecodeerd: bij een import op live deelt GF
 * een nieuw ID uit (GFAPI::add_form overschrijft het geëxporteerde ID). Net
 * als bij het contactformulier zoeken we daarom op titel.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Titel waarop het formulier herkend wordt. */
function sokkies_offerte_titel() {
	return 'Offerte — website';
}

/** ID van het offerteformulier, of 0 als het er niet is. */
function sokkies_offerte_form_id() {
	static $id = null;
	if ( null !== $id ) {
		return $id;
	}
	if ( defined( 'SOKKIES_OFFERTE_FORM_ID' ) ) {
		return $id = (int) SOKKIES_OFFERTE_FORM_ID;
	}
	$vast = (int) get_option( 'sokkies_offerte_form_id' );
	if ( $vast ) {
		return $id = $vast;
	}
	$id = 0;
	if ( class_exists( 'GFAPI' ) ) {
		foreach ( (array) GFAPI::get_forms() as $f ) {
			if ( isset( $f['title'] ) && sokkies_offerte_titel() === $f['title'] ) {
				$id = (int) $f['id'];
				break;
			}
		}
	}
	return $id;
}

/** Is dit het offerteformulier? */
function sokkies_is_offerte( $form ) {
	$id = sokkies_offerte_form_id();
	return $id && ! empty( $form['id'] ) && (int) $form['id'] === $id;
}

/**
 * Formulieren die de kaartopmaak uit htmlv gebruiken.
 *
 * Het offerte- en het sampleformulier delen de soktypekaarten met foto, het
 * uploadveld als gestippeld vlak, de (optioneel)-markering en de
 * adresopzoeking. De filters die dáárover gaan gelden dus voor allebei.
 * Wat ALLEEN bij de offerte hoort — de stappenbalk en de vorige/volgende-
 * knoppen — blijft op sokkies_is_offerte() staan; het sampleformulier is
 * één pagina.
 *
 * Neemt een formulier-array of een ID, zodat hij ook werkt in filters die
 * alleen een veld met ->formId meegeven.
 */
function sokkies_form_eigen_opmaak( $form_of_id ) {
	$id = is_array( $form_of_id ) ? (int) rgar( $form_of_id, 'id' ) : (int) $form_of_id;
	if ( ! $id ) {
		return false;
	}
	$ids = array( sokkies_offerte_form_id() );
	if ( function_exists( 'sokkies_sample_form_id' ) ) {
		$ids[] = sokkies_sample_form_id();
	}
	return in_array( $id, array_filter( $ids ), true );
}

/**
 * Hoeveel soorten sokken mag de bezoeker aanvinken?
 *
 * Het OFFERTEformulier staat er ÉÉN toe (verzoek Kulwant 2026-09-17), het
 * SAMPLEformulier er twee — daar gaan ook twee paar de deur uit. Beide
 * formulieren delen dezelfde kaarten, dezelfde validatie en hetzelfde
 * script, dus het getal hangt aan het FORMULIER en niet aan de code
 * eromheen. Onbekend formulier = twee, de oude waarde.
 */
function sokkies_max_soktypes( $form_of_id ) {
	$id = is_array( $form_of_id ) ? (int) rgar( $form_of_id, 'id' ) : (int) $form_of_id;

	return ( $id && $id === sokkies_offerte_form_id() ) ? 1 : 2;
}

/** Zoekt een veld op label; geeft het GF_Field of null. */
function sokkies_offerte_veld( $form, $label ) {
	foreach ( (array) $form['fields'] as $v ) {
		if ( $label === $v->label ) {
			return $v;
		}
	}
	return null;
}

/**
 * Aangevinkte waarden van een checkboxveld uit de POST halen.
 *
 * GF post elke aangevinkte optie los als input_<id>_<sub>, waarbij de
 * sub-index nummers die op 0 eindigen overslaat (1.9 -> 1.11). Daarom lopen
 * we over de inputs van het veld in plaats van zelf te tellen.
 */
/**
 * Keuzeteksten vergelijkbaar maken.
 *
 * Gravity Forms bewaart de tekst van een keuze niet overal hetzelfde: soms
 * rauw ("Yoga & pilates sokken"), soms HTML-gecodeerd ("Yoga &amp; pilates
 * sokken"), afhankelijk van hoe het formulier is aangemaakt of geïmporteerd.
 * Op live bleek dat lokaal niet: daar matchten precies de opties met een &
 * niet, waardoor hun foto terugviel op het lege icoon. Dezelfde valkuil geldt
 * voor "Geen extra's" (apostrof → &#039;), en dan wordt de uitsluiting
 * serverzijdig stilletjes niet meer afgedwongen.
 *
 * Daarom loopt ELKE vergelijking van keuzetekst via deze functie.
 */
function sokkies_offerte_keuzetekst( $tekst ) {
	return trim( html_entity_decode( (string) $tekst, ENT_QUOTES, 'UTF-8' ) );
}

function sokkies_offerte_aangevinkt( $veld ) {
	$gekozen = array();
	foreach ( (array) $veld->inputs as $input ) {
		$naam = 'input_' . str_replace( '.', '_', $input['id'] );
		if ( isset( $_POST[ $naam ] ) && '' !== $_POST[ $naam ] ) {
			$gekozen[] = sokkies_offerte_keuzetekst( wp_unslash( $_POST[ $naam ] ) );
		}
	}
	return $gekozen;
}

/**
 * Validatie per veld.
 *
 * Meldingen in dezelfde toon als de rest van het formulier (zie de
 * vertaalkaart in functions.php): kort, Nederlands, "je"-vorm.
 */
add_filter( 'gform_field_validation', function ( $resultaat, $waarde, $form, $veld ) {
	// Geldt voor beide eigen formulieren: het sampleformulier heeft dezelfde
	// soktypekaarten met dezelfde regel van maximaal twee.
	if ( ! sokkies_form_eigen_opmaak( $form ) ) {
		return $resultaat;
	}

	// 1. Aantal soorten sokken — één op de offerte, twee op de sample.
	if ( 'Wat wil je laten bedrukken?' === $veld->label ) {
		$gekozen = sokkies_offerte_aangevinkt( $veld );
		$max     = sokkies_max_soktypes( $form );
		if ( count( $gekozen ) > $max ) {
			$resultaat['is_valid'] = false;
			$resultaat['message']  = 1 === $max
				? sokkies_form_zin( 'Kies één soort sok.' )
				: sokkies_form_zin( 'Kies maximaal twee soorten sokken.' );
		}
	}

	// 2. "Geen extra's" kan niet samen met de andere opties.
	if ( 'Aanvullende opties' === $veld->label ) {
		$gekozen = sokkies_offerte_aangevinkt( $veld );
		$geen    = in_array( "Geen extra's", $gekozen, true );
		if ( $geen && count( $gekozen ) > 1 ) {
			$resultaat['is_valid'] = false;
			$resultaat['message']  = sokkies_form_zin( 'Kies óf een of meer extra opties, óf "Geen extra\'s" — niet allebei.' );
		}
	}

	return $resultaat;
}, 10, 4 );

/* -------------------------------------------------------------------------
 * Adresopzoeking
 * -------------------------------------------------------------------------
 * De bezoeker vult postcode + huisnummer in, straat/plaats/provincie worden
 * automatisch aangevuld.
 *
 * BEWUST VIA DE SERVER en niet rechtstreeks vanuit de browser. De standaard
 * provider (PDOK Locatieserver) heeft geen sleutel nodig, maar een
 * pan-Europese dienst wél — en zo'n sleutel hoort niet in de front-end. Door
 * er nu al een eigen endpoint voor te zetten kan de provider later gewisseld
 * worden zonder dat de JavaScript verandert.
 *
 * LET OP: PDOK dekt ALLEEN Nederland. Voor België en de rest van Europa is
 * een betaalde dienst nodig (Loqate, Postcode.eu, Google Places). Zie
 * sokkies_offerte_adres_provider().
 * ------------------------------------------------------------------------- */

/**
 * De landen waarvoor we het adres automatisch invullen, met hun landcode
 * volgens ISO 3166-1 alfa-2.
 *
 * LET OP: de SLEUTEL is de Engelse landnaam uit de oude ingebouwde lijst van
 * Gravity Forms. Het formulier verstuurt sinds de omzetting naar landcodes de
 * CODE, dus voor een vergelijking met een ingestuurde waarde gebruik je
 * sokkies_land_code() en niet deze sleutels. Waar het hier om gaat is de reeks
 * WAARDEN: dat zijn de landen die we automatisch invullen.
 *
 * Dit is BEWUST dezelfde lijst als toen Postcode.eu de opzoeking deed, ook al
 * kan Google er meer aan. Zo verandert er voor geen enkel land iets aan wat de
 * bezoeker ziet behalve daar waar het moest. Een land erbij is één regel — dan
 * gaat het meteen langs Google.
 */
function sokkies_adres_landen() {
	return array(
		'Netherlands'    => 'NL',
		'Belgium'        => 'BE',
		'Germany'        => 'DE',
		'France'         => 'FR',
		'United Kingdom' => 'GB',
		'Austria'        => 'AT',
		'Switzerland'    => 'CH',
		'Denmark'        => 'DK',
		'Spain'          => 'ES',
		'Finland'        => 'FI',
		'Italy'          => 'IT',
		'Luxembourg'     => 'LU',
		'Norway'         => 'NO',
		'Sweden'         => 'SE',
	);
}

/** Staan de inloggegevens van Postcode.eu klaar? Beide zijn nodig. */
function sokkies_postcode_eu_gereed() {
	return defined( 'SOKKIES_POSTCODE_EU_KEY' ) && defined( 'SOKKIES_POSTCODE_EU_SECRET' )
		&& SOKKIES_POSTCODE_EU_KEY && SOKKIES_POSTCODE_EU_SECRET;
}

/**
 * Het land raden aan de VORM van de postcode.
 *
 * Zo hoeft de bezoeker net als in Nederland alleen postcode + huisnummer te
 * typen; het land vult zichzelf. Alleen vormen die niet met elkaar te
 * verwarren zijn staan hier:
 *
 *   Nederland        1234AB      vier cijfers, dan twee letters
 *   Verenigd Kon.    SW1A2AA     begint met letters, eindigt op cijfer+2 letters
 *
 * BELGIË, DUITSLAND EN FRANKRIJK STAAN ER BEWUST NIET BIJ. Die hebben alle
 * drie een postcode van louter cijfers (1000, 10115, 75001) en zijn dus niet
 * uit elkaar te houden — en ze leveren met postcode + huisnummer toch geen
 * eenduidig adres op. Daar vragen we gewoon om het land.
 *
 * @param string $postcode Postcode zonder spaties, hoofdletters.
 * @return string De Engelse landnaam, of '' als de vorm niets verraadt.
 */
function sokkies_land_uit_postcode( $postcode ) {
	if ( preg_match( '/^[1-9][0-9]{3}[A-Z]{2}$/', $postcode ) ) {
		return 'NL';
	}
	/* Britse postcode: 1-2 letters, een cijfer, eventueel nog een letter of
	   cijfer, en dan het 'inward code'-deel van een cijfer plus twee letters.
	   Dekt SW1A2AA, EC2R8AH, M11AD, CB21TN en W1A1AA. Botst niet met de
	   Nederlandse vorm, want die begint met een cijfer. */
	if ( preg_match( '/^[A-Z]{1,2}[0-9][A-Z0-9]?[0-9][A-Z]{2}$/', $postcode ) ) {
		return 'GB';
	}

	return '';
}

/**
 * Zoekt een adres op. Geeft array(straat, plaats, provincie, land) of WP_Error.
 *
 * Los gehouden van het REST-endpoint zodat een andere provider alleen deze
 * functie hoeft te vervangen.
 *
 * TWEE ROUTES, afhankelijk van het land:
 *
 *   NEDERLAND -> de Nederlandse dienst van Postcode.eu. Dat is een EXACTE
 *   opzoeking op postcode + huisnummer: bestaat de combinatie niet, dan zegt
 *   de dienst dat ook. Zonder inloggegevens valt hij terug op PDOK (gratis,
 *   geen sleutel) zodat een clone zonder abonnement blijft werken.
 *
 *   BUITENLAND -> de internationale dienst. Die is eigenlijk een TYPE-AHEAD
 *   (suggesties per toetsaanslag), maar hij accepteert ook "<postcode>
 *   <huisnummer>" als een zoekterm. Levert dat precies EEN treffer op van
 *   het niveau "Address", dan is het adres eenduidig en vullen we het in.
 *
 * WAAROM DIE EIS VAN EEN ADRES-TREFFER (gemeten 2026-09-21): een postcode
 * betekent per land iets heel anders. In het Verenigd Koninkrijk hoort hij
 * bij een stukje straat, dus "SW1A 2AA 10" geeft precies een adres. In
 * Belgie, Duitsland en Frankrijk dekt hij een hele gemeente: "1000 1" levert
 * alleen "1000 Brussel" op niveau PostalCode. En een huisnummer dat niet
 * bestaat ("SW1A 1AA 11") zakt ook terug naar PostalCode. In al die gevallen
 * vullen we dus NIETS in en gaan de velden open — beter een adres dat de
 * bezoeker zelf typt dan een gok die er plausibel uitziet.
 */
function sokkies_offerte_adres_provider( $postcode, $huisnummer, $land = '', $land_bron = 'keuze', $straat = '' ) {
	$postcode   = strtoupper( preg_replace( '/\s+/', '', (string) $postcode ) );
	$huisnummer = trim( (string) $huisnummer );
	$land       = trim( (string) $land );

	if ( '' === $huisnummer ) {
		return new WP_Error( 'geen_huisnummer', 'Vul ook een huisnummer in.' );
	}

	$landen = sokkies_adres_landen();

	/* De landkeuze komt binnen als landcode (NL, BE, ...). Een oudere inzending
	   of een pagina die nog in de cache zat stuurt de Engelse naam; die wordt
	   hier alsnog een code, zodat beide schrijfwijzen blijven werken. */
	$land = sokkies_land_code( $land );

	/* Geen land gekozen? Dan gaan we uit van Nederland zolang de postcode
	   Nederlands oogt (4 cijfers + 2 letters). Zo blijft het formulier voor
	   de grootste groep bezoekers werken zonder dat ze eerst een land hoeven
	   te kiezen — precies zoals het tot nu toe werkte. */
	$gok = sokkies_land_uit_postcode( $postcode );

	if ( '' === $land ) {
		/* Niets gekozen: de vorm van de postcode beslist. Zegt die niets
		   (België, Duitsland, Frankrijk — allemaal alleen cijfers), dan vragen
		   we het land. */
		if ( '' === $gok ) {
			return new WP_Error(
				'kies_land',
				'Kies eerst een land, dan vullen we het adres voor je in.'
			);
		}
		$land = $gok;
	} elseif ( 'auto' === $land_bron && $gok && $gok !== $land ) {
		/* Er staat nog een land van een VORIGE opzoeking, en de postcode hoort
		   duidelijk bij een ander land. Dan is de postcode leidend: die heeft de
		   bezoeker net getypt, dat andere land hebben wij zelf ingevuld. */
		$land = $gok;
	}

	if ( '' === $land || ! in_array( $land, $landen, true ) ) {
		return new WP_Error(
			'buiten_dekking',
			'Voor dit land vullen we het adres niet automatisch in. Vul de velden hieronder zelf in.'
		);
	}

	if ( 'NL' === $land ) {
		if ( ! preg_match( '/^[1-9][0-9]{3}[A-Z]{2}$/', $postcode ) ) {
			/* Stond Nederland er nog van een VORIGE opzoeking (we vullen het
			   land zelf in zodra we een adres vinden), dan is dit geen fout van
			   de bezoeker maar een verouderde waarde: bij een Britse postcode
			   vragen we dan gewoon om het land in plaats van "niet gevonden"
			   te roepen. Koos de bezoeker Nederland zelf, dan klopt die melding
			   wel en blijft hij staan. */
			if ( 'auto' === $land_bron ) {
				return new WP_Error( 'kies_land', 'Kies eerst een land, dan vullen we het adres voor je in.' );
			}
			return new WP_Error( 'niet_gevonden', 'We konden dit adres niet vinden. Controleer postcode en huisnummer.' );
		}
		if ( sokkies_postcode_eu_gereed() ) {
			return sokkies_adres_postcode_eu( $postcode, $huisnummer );
		}
		return sokkies_adres_pdok( $postcode, $huisnummer );
	}

	if ( ! sokkies_google_gereed() ) {
		return new WP_Error(
			'buiten_dekking',
			'Voor dit land vullen we het adres niet automatisch in. Vul de velden hieronder zelf in.'
		);
	}

	return sokkies_google_adres( $land, $land, $postcode, $huisnummer, $straat );
}

/** Een aanroep naar Postcode.eu. Geeft de body als array, of WP_Error. */
function sokkies_postcode_eu_call( $url ) {
	$headers = array(
		'Authorization' => 'Basic ' . base64_encode( SOKKIES_POSTCODE_EU_KEY . ':' . SOKKIES_POSTCODE_EU_SECRET ),
	);

	$antwoord = wp_remote_get( $url, array( 'timeout' => 6, 'headers' => $headers ) );
	if ( is_wp_error( $antwoord ) ) {
		return new WP_Error( 'onbereikbaar', 'De adresservice is even niet bereikbaar. Vul de gegevens zelf in.' );
	}

	$status = (int) wp_remote_retrieve_response_code( $antwoord );

	// 404 = de combinatie bestaat niet. Dat is een antwoord, geen storing.
	if ( 404 === $status ) {
		return new WP_Error( 'niet_gevonden', 'We konden dit adres niet vinden. Controleer postcode en huisnummer.' );
	}

	/* 401/403 = sleutel, geheim of tegoed klopt niet. Dat is een
	   BEHEERPROBLEEM en geen fout van de bezoeker: die krijgt de nette "vul
	   zelf in"-route, maar het moet wel in het log staan, anders staat de
	   opzoeking stil zonder dat iemand het merkt. */
	if ( 200 !== $status ) {
		error_log( sprintf( 'Sokkies: Postcode.eu gaf status %d voor %s', $status, $url ) );
		return new WP_Error( 'onbereikbaar', 'De adresservice is even niet bereikbaar. Vul de gegevens zelf in.' );
	}

	$data = json_decode( wp_remote_retrieve_body( $antwoord ), true );
	if ( ! is_array( $data ) ) {
		return new WP_Error( 'onbereikbaar', 'De adresservice is even niet bereikbaar. Vul de gegevens zelf in.' );
	}

	return $data;
}

/**
 * Postcode.eu, Nederlandse adressen. Exacte opzoeking, dus geen naslag nodig.
 */
function sokkies_adres_postcode_eu( $postcode, $huisnummer ) {
	$data = sokkies_postcode_eu_call( sprintf(
		'https://api.postcode.eu/nl/v1/addresses/postcode/%s/%s',
		rawurlencode( $postcode ),
		rawurlencode( $huisnummer )
	) );

	if ( is_wp_error( $data ) ) {
		return $data;
	}
	if ( empty( $data['street'] ) ) {
		return new WP_Error( 'niet_gevonden', 'We konden dit adres niet vinden. Controleer postcode en huisnummer.' );
	}

	return array(
		'straat'    => (string) $data['street'],
		'plaats'    => (string) ( $data['city'] ?? '' ),
		'provincie' => (string) ( $data['province'] ?? '' ),
		'land'      => 'NL',
	);
}

/**
 * Google Address Validation — de opzoeking buiten Nederland.
 *
 * WAAROM DEZE DIENST EN NIET DE GEOCODING API: die laatste is een geocoder en
 * geen adrescontrole. Kent hij een huisnummer niet, dan geeft hij een
 * geïnterpoleerd of bij benadering gevonden punt terug in plaats van een fout
 * — precies het gedrag waardoor PDOK ooit "Maijweg" opleverde voor een
 * postcode die in het echte register niet bestaat. Address Validation zegt
 * wél of het adres tot op het pand klopt.
 *
 * WAT DEZE DIENST NIET KAN, en dat bepaalt de hele opzet hieronder: hij somt
 * geen straten op. Je geeft hem een adres en hij keurt het; je kunt hem niet
 * vragen welke straten er in postcode 55246 liggen. Postcode.eu kon dat wel,
 * en dáár kwam het keuzelijstje met straatnamen vandaan. Gevolg per land:
 *
 *   - Nederland en het Verenigd Koninkrijk: een postcode wijst daar één
 *     straat of straatdeel aan, dus postcode + huisnummer is genoeg en Google
 *     leidt de straat zelf af.
 *   - België, Duitsland, Frankrijk, Spanje en de rest: een postcode beslaat
 *     daar een hele gemeente. We vragen de bezoeker om de straat en laten het
 *     adres pas daarna keuren — maar ZONDER de suggesties die Postcode.eu gaf.
 *     Wie dat lijstje terug wil, heeft Places Autocomplete nodig: een andere
 *     dienst, een ander tarief en een andere manier van invullen.
 *
 * Nederland loopt bewust NIET langs Google maar blijft bij Postcode.eu. Dat
 * bevraagt het officiële register en geeft een hard "bestaat niet"; op de
 * grootste groep bezoekers houden we zo de scherpste controle.
 */
function sokkies_google_gereed() {
	return defined( 'SOKKIES_GOOGLE_ADRES_KEY' ) && SOKKIES_GOOGLE_ADRES_KEY;
}

/**
 * Eén adres laten keuren door Google.
 *
 * @param string $regiocode  Landcode volgens ISO 3166-1 alfa-2, bijv. 'DE'.
 * @param string $land       De landnaam zoals Gravity Forms hem opslaat.
 * @param string $postcode   Zonder spaties, in hoofdletters.
 * @param string $huisnummer
 * @param string $straat     Leeg bij de eerste poging.
 * @return array|WP_Error    Adres, of array met straat_nodig, of WP_Error.
 */
function sokkies_google_adres( $regiocode, $land, $postcode, $huisnummer, $straat = '' ) {
	$straat = trim( (string) $straat );

	/* De volgorde van straat en huisnummer verschilt per land. Google is daar
	   tolerant in, maar een adresregel in de gangbare volgorde van het land
	   levert merkbaar vaker een treffer op pandniveau op. */
	$regel = in_array( $regiocode, array( 'GB', 'IE' ), true )
		? trim( $huisnummer . ' ' . $straat )
		: trim( $straat . ' ' . $huisnummer );

	$antwoord = wp_remote_post(
		'https://addressvalidation.googleapis.com/v1:validateAddress?key=' . rawurlencode( SOKKIES_GOOGLE_ADRES_KEY ),
		array(
			'timeout' => 8,
			'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
			'body'    => wp_json_encode(
				array(
					'address' => array(
						'regionCode'   => $regiocode,
						'postalCode'   => $postcode,
						'addressLines' => array( $regel ),
					),
				)
			),
		)
	);

	if ( is_wp_error( $antwoord ) ) {
		error_log( 'Sokkies: Google Address Validation onbereikbaar — ' . $antwoord->get_error_message() );
		return new WP_Error( 'onbereikbaar', 'De adresservice is even niet bereikbaar. Vul de gegevens zelf in.' );
	}

	$status = (int) wp_remote_retrieve_response_code( $antwoord );
	if ( 200 !== $status ) {
		/* Sleutel, facturering of de API zelf staat niet goed. Google zet de
		   reden in de body; die hoort in het log en niet op het scherm, maar
		   hij MOET ergens staan — anders valt de opzoeking stil zonder dat
		   iemand het merkt. */
		error_log( sprintf( 'Sokkies: Google Address Validation gaf status %d — %s', $status, wp_remote_retrieve_body( $antwoord ) ) );
		return new WP_Error( 'onbereikbaar', 'De adresservice is even niet bereikbaar. Vul de gegevens zelf in.' );
	}

	$data      = json_decode( wp_remote_retrieve_body( $antwoord ), true );
	$resultaat = isset( $data['result'] ) && is_array( $data['result'] ) ? $data['result'] : array();
	$oordeel   = isset( $resultaat['verdict'] ) ? $resultaat['verdict'] : array();
	$niveau    = isset( $oordeel['validationGranularity'] ) ? $oordeel['validationGranularity'] : '';

	$onderdelen = isset( $resultaat['address']['addressComponents'] ) ? $resultaat['address']['addressComponents'] : array();
	$zoek       = function ( $soorten ) use ( $onderdelen ) {
		foreach ( $onderdelen as $onderdeel ) {
			$soort = isset( $onderdeel['componentType'] ) ? $onderdeel['componentType'] : '';
			if ( in_array( $soort, $soorten, true ) ) {
				return isset( $onderdeel['componentName']['text'] ) ? (string) $onderdeel['componentName']['text'] : '';
			}
		}
		return '';
	};
	$bevestiging = function ( $soort ) use ( $onderdelen ) {
		foreach ( $onderdelen as $onderdeel ) {
			if ( $soort === ( isset( $onderdeel['componentType'] ) ? $onderdeel['componentType'] : '' ) ) {
				return isset( $onderdeel['confirmationLevel'] ) ? $onderdeel['confirmationLevel'] : '';
			}
		}
		return '';
	};

	$straatnaam       = $zoek( array( 'route' ) );
	$plaats           = $zoek( array( 'locality', 'postal_town' ) );
	$provincie        = $zoek( array( 'administrative_area_level_1' ) );

	/* WANNEER NEMEN WE HET ANTWOORD OVER? Bedenk waarvoor we het gebruiken: we
	   vullen STRAAT, PLAATS en PROVINCIE in. Het huisnummer staat al in zijn
	   eigen veld, getypt door de bezoeker; dat claimen we niet te hebben
	   gecontroleerd. Zeker zijn over de STRAAT is dus genoeg, en dat kan op
	   twee manieren:
	     - PREMISE of SUB_PREMISE: Google plaatst het hele adres op een pand;
	     - of de straat zelf staat op CONFIRMED, ook als het huisnummer niet
	       te bevestigen was.
	   Dat tweede geval is geen theorie: Chemin du Lavoir 4443 in 13116 bestaat
	   (Postcode.eu vond hem), maar Google kent daar het huisnummer niet en
	   geeft ROUTE met de straat CONFIRMED en het nummer
	   UNCONFIRMED_BUT_PLAUSIBLE. Alleen PREMISE accepteren wees zulke ECHTE
	   adressen af, en dat is erger dan een straat invullen die zeker klopt.
	   Wat hiermee NIET binnenglipt: een antwoord zonder straat. PREMISE_PROXIMITY
	   ("in de buurt van") levert er geen, en OTHER evenmin — dan blijft het bij
	   de vraag om een straatnaam. */
	$op_pandniveau = in_array( $niveau, array( 'PREMISE', 'SUB_PREMISE' ), true )
		|| 'CONFIRMED' === $bevestiging( 'route' );

	/* DE POSTCODE MOET BEVESTIGD ZIJN, en let op HOE je dat vaststelt. Ik ging
	   er eerst van uit dat Google een postcode zou CORRIGEREN als hij niet bij
	   het adres hoort, en vergeleek daarom de teruggegeven waarde met wat de
	   bezoeker typte. Dat is fout: hij ECHOOT je postcode gewoon terug en zet
	   er een oordeel bij. Die vergelijking slaagde dus altijd.
	   Wat er dan doorheen glipte, alle drie met een CONFIRMED straat:
	     FR 13116 + Rue de Rivoli  -> Nîmes        (postcode SUSPICIOUS)
	     BE 1000  + Grotestraat    -> Maasmechelen (postcode PLAUSIBLE)
	     GB SW1A2AA + Abbey Road   -> Londen, maar de verkeerde wijk
	   Stuk voor stuk een bestaande straat in een plaats die niets met de
	   ingevulde postcode te maken heeft — precies het soort aannemelijke
	   onzin waarvoor we van PDOK af wilden. De Belgische kwam zelfs terug als
	   PREMISE met een bevestigd huisnummer, dus ook de strengere regel van
	   hiervoor hield hem niet tegen.
	   Alleen de BEVESTIGING van de postcode scheidt de goede van de slechte:
	   bij elk adres dat wél klopt staat hij op CONFIRMED. */
	$postcode_bevestigd = 'CONFIRMED' === $bevestiging( 'postal_code' );

	if ( $op_pandniveau && '' !== $straatnaam && $postcode_bevestigd ) {
		/* Een provincie bestaat lang niet overal (het Verenigd Koninkrijk kent
		   hem niet), dus die mag leeg blijven — het veld is niet verplicht. */
		return array(
			'straat'    => $straatnaam,
			'plaats'    => $plaats,
			'provincie' => $provincie,
			'land'      => $land,
		);
	}

	/* Geen treffer én de bezoeker heeft nog geen straat ingevuld: dan is dat
	   het ontbrekende stuk. Het lijstje suggesties blijft leeg, want deze
	   dienst kan geen straten opsommen — zie de uitleg hierboven. */
	if ( '' === $straat ) {
		return array(
			'straat_nodig' => true,
			'suggesties'   => array(),
			'land'         => $land,
		);
	}

	return new WP_Error( 'niet_gevonden', 'We konden dit adres niet vinden. Controleer postcode en huisnummer.' );
}

/**
 * PDOK Locatieserver — de Nederlandse terugval zonder sleutel.
 */
function sokkies_adres_pdok( $postcode, $huisnummer ) {
	$url = add_query_arg(
		array(
			'q'    => rawurlencode( $postcode . ' ' . $huisnummer ),
			'fq'   => rawurlencode( 'type:adres' ),
			'rows' => 1,
			'fl'   => rawurlencode( 'straatnaam,woonplaatsnaam,provincienaam,postcode,huis_nlt' ),
		),
		'https://api.pdok.nl/bzk/locatieserver/search/v3_1/free'
	);

	$antwoord = wp_remote_get( $url, array( 'timeout' => 6 ) );
	if ( is_wp_error( $antwoord ) ) {
		return new WP_Error( 'onbereikbaar', 'De adresservice is even niet bereikbaar. Vul de gegevens zelf in.' );
	}
	$data = json_decode( wp_remote_retrieve_body( $antwoord ), true );
	$doc  = $data['response']['docs'][0] ?? null;
	if ( ! $doc ) {
		return new WP_Error( 'niet_gevonden', 'We konden dit adres niet vinden. Controleer postcode en huisnummer.' );
	}

	/* De vrije zoekopdracht van PDOK doet FUZZY matching: een niet-bestaande
	   postcode als 9999ZZ levert gewoon het dichtstbijzijnde resultaat op
	   (getest: dat gaf "1 juli-weg, Maastricht"). Zonder deze controle zou
	   het formulier dus stilletjes een verkeerd adres invullen. Daarom eisen
	   we dat de gevonden postcode exact de gevraagde is. Postcode.eu heeft
	   dit probleem niet: die zoekt exact op. */
	$gevonden = strtoupper( preg_replace( '/\s+/', '', (string) ( $doc['postcode'] ?? '' ) ) );
	if ( $gevonden !== $postcode ) {
		return new WP_Error( 'niet_gevonden', 'We konden dit adres niet vinden. Controleer postcode en huisnummer.' );
	}

	return array(
		'straat'    => (string) ( $doc['straatnaam'] ?? '' ),
		'plaats'    => (string) ( $doc['woonplaatsnaam'] ?? '' ),
		'provincie' => (string) ( $doc['provincienaam'] ?? '' ),
		'land'      => 'NL',
	);
}

/* -------------------------------------------------------------------------
 * Stappenbalk
 * -------------------------------------------------------------------------
 * htmlv heeft een <ol class="stepper"> met per stap een bolletje, een titel
 * én een ondertitel, met een groen vinkje zodra een stap af is. Gravity Forms
 * rendert een eigen .gf_page_steps zonder ondertitels. Via gform_progress_steps
 * vervangen we die markup door precies de opzet uit het ontwerp, zodat de CSS
 * die al in style.css staat (.stepper, .stepper-dot, .stepper-label,
 * .is-active, .is-done) het werk doet.
 * ------------------------------------------------------------------------- */
function sokkies_offerte_stappen() {
	return array(
		array(
			'titel' => 'Wat wil je laten bedrukken?',
			// Volgt de werking: sinds 2026-09-17 staat dit formulier nog maar
			// één soort toe, net als htmlv al zei.
			'onder' => 'Type sok (kies er één)',
		),
		array(
			'titel' => 'Aanvullende opties',
			'onder' => 'Maak je sokkengeschenk compleet',
		),
		array(
			'titel' => 'Jouw gegevens',
			'onder' => 'Vul het formulier in en verstuur',
		),
	);
}

add_filter( 'gform_progress_steps', function ( $markup, $form, $huidige ) {
	if ( ! sokkies_is_offerte( $form ) ) {
		return $markup;
	}
	$stappen = sokkies_offerte_stappen();
	$uit     = '<ol class="stepper" data-current="' . (int) $huidige . '">';
	foreach ( $stappen as $i => $stap ) {
		$nr      = $i + 1;
		$klassen = 'stepper-item';
		if ( $nr === (int) $huidige ) {
			$klassen .= ' is-active';
		} elseif ( $nr < (int) $huidige ) {
			$klassen .= ' is-done';
		}
		$uit .= '<li class="' . $klassen . '" data-step="' . $nr . '">'
			. '<span class="stepper-dot">' . $nr . '.</span>'
			. '<div class="stepper-label"><span>' . esc_html( $stap['titel'] ) . '</span>'
			. '<small>' . esc_html( $stap['onder'] ) . '</small></div>'
			. '</li>';
	}
	$uit .= '</ol>';
	return $uit;
}, 10, 3 );

/**
 * "(optioneel)" achter het label, zoals in htmlv/offerte.html.
 *
 * Gravity Forms markeert alleen VERPLICHTE velden (met een *) en heeft geen
 * tegenhanger voor optioneel. Het ontwerp zet die aanduiding bij twee velden,
 * dus die staan hier met naam genoemd in plaats van "alles wat niet verplicht
 * is" — anders krijgt ook Toevoeging in stap 3 het label, en daar lost het
 * ontwerp het met een placeholder op.
 */
function sokkies_offerte_optioneel_labels() {
	// 'Opmerkingen' hoort bij het sampleformulier; htmlv zet daar
	// "(optioneel)" achter, net als bij het uploadveld.
	return array( 'Upload je ontwerp', 'Jouw wensen', 'Opmerkingen' );
}

/**
 * Het bijschrift onder Land weg (verzoek 2026-09-22).
 *
 * "Wordt automatisch ingevuld" klopte toen het veld alleen verscheen met
 * een adres er al in. Sinds Land altijd in beeld staat is het juist het
 * ENE veld dat de bezoeker soms zelf moet kiezen — een Belgische, Duitse
 * of Franse postcode is enkel cijfers, dus daar valt het land niet uit af
 * te leiden. De regel beloofde dus iets dat niet altijd waar is.
 *
 * WAAROM HIER EN NIET IN CSS: display:none haalt de tekst alleen van het
 * scherm. Gravity Forms hangt het bijschrift ook via aria-describedby aan
 * het keuzemenu, dus een schermlezer zou "wordt automatisch ingevuld"
 * blijven voorlezen bij precies het veld waar dat niet opgaat. Leeg maken
 * bij het renderen haalt allebei weg.
 *
 * WAAROM NIET IN GRAVITY FORMS ZELF: de veldinstelling staat in de
 * database en die deployt niet mee; dan moest het op dev en live opnieuw.
 * Het veld wordt gezocht op zijn cssClass, niet op het label: dat laatste
 * is redactionele tekst die kan veranderen.
 *
 * LET OP: straat, plaats en provincie dragen dezelfde regel en houden
 * hem bewust — die verschijnen alleen achter "Handmatig invullen" en daar
 * legt de zin nog wel uit waarom ze leeg zijn.
 */
add_filter( 'gform_pre_render', function ( $form ) {
	if ( ! is_array( $form ) || empty( $form['fields'] ) || ! sokkies_form_eigen_opmaak( $form['id'] ) ) {
		return $form;
	}
	foreach ( $form['fields'] as $veld ) {
		if ( false !== strpos( (string) $veld->cssClass, 'of-land' ) ) {
			$veld->description = '';
		}
	}
	return $form;
} );

/**
 * Is dit het landveld? (los van de rest van het adresblok)
 *
 * Herkenning op de cssClass en niet op het label: het label is redactionele
 * tekst die de klant mag hernoemen.
 */
function sokkies_offerte_landveld( $veld ) {
	return false !== strpos( ' ' . trim( preg_replace( '/\s+/', ' ', (string) $veld->cssClass ) ) . ' ', ' of-land ' );
}

/**
 * HET ADRESBLOK STAAT NIET MEER OP HET OFFERTEFORMULIER (stap 3).
 *
 * Een offerteaanvraag heeft geen bezorgadres nodig, dus postcode,
 * huisnummer, toevoeging, land, het vak "Gevonden adres" met de link
 * "Klopt niet? Handmatig invullen" en de verborgen velden straat,
 * plaats en provincie verdwijnen daar. Onder "Jouw gegevens" blijven
 * alleen Bedrijfsnaam, Contactpersoon, E-mail en Telefoon staan.
 *
 * DE VELDEN ZELF BLIJVEN BESTAAN in Gravity Forms — ze zijn hier alleen
 * uit het formulier gefilterd. Dat is bewust: het SAMPLEformulier deelt
 * dezelfde opzet en heeft het adres wel nodig, en weggooien in de
 * formulierbouwer zou bovendien een DATABASE-wijziging zijn — die
 * deployt niet mee, dus op dev en live had het opnieuw gemoeten.
 * Daarom staat het hier in code, net als de veldvolgorde en het
 * bijschrift hierboven.
 *
 * OOK DE TWEE LEGE "Rijovergang"-velden gaan mee: die bestonden puur om
 * de adresrij af te dwingen (zie de notitie over flex-wrap). Zonder
 * adresblok dwingen ze een rij af die er niet meer is.
 *
 * DRIE HAKEN, want alleen verbergen bij het RENDEREN is niet genoeg:
 * postcode, huisnummer en land staan in Gravity Forms op verplicht, dus
 * zonder gform_pre_validation zou de bezoeker niet langs een controle
 * komen op velden die hij niet ziet. gform_pre_submission_filter zorgt
 * dat er ook niets leegs in de inzending belandt.
 *
 * NIET in de beheeromgeving (is_admin): de formulierbouwer en het
 * inzendingenscherm moeten de velden gewoon blijven tonen.
 */
function sokkies_offerte_adresveld( $veld ) {
	$klassen = array(
		'of-postcode', 'of-huisnummer', 'of-toevoeging', 'of-land',
		'of-straat', 'of-plaats', 'of-provincie', 'of-rij-break',
		/* het vak "Gevonden adres" draagt zijn class op het veld zelf */
		'of-adres-paneel',
	);
	$css = ' ' . trim( preg_replace( '/\s+/', ' ', (string) $veld->cssClass ) ) . ' ';
	foreach ( $klassen as $klasse ) {
		if ( false !== strpos( $css, ' ' . $klasse . ' ' ) ) {
			return true;
		}
	}

	/* Het vak "Gevonden adres" is een HTML-veld zonder eigen cssClass. Het
	   is te herkennen aan de markup die offerte.js aanspreekt; dat anker
	   is steviger dan de zichtbare tekst, want die is redactioneel. */
	return 'html' === $veld->type
		&& false !== strpos( (string) $veld->content, 'of-adres-paneel' );
}

function sokkies_offerte_adresblok_weg( $form ) {
	if ( is_admin() || ! is_array( $form ) || empty( $form['fields'] ) ) {
		return $form;
	}
	$offerte = sokkies_offerte_form_id();
	if ( ! $offerte || (int) $form['id'] !== (int) $offerte ) {
		return $form;
	}
	/* Het LANDVELD blijft staan (verzoek 2026-10-01): een offerte heeft geen
	   bezorgadres nodig, maar het land bepaalt wel de levering en de btw. Het
	   staat in de DOM boven Bedrijfsnaam omdat het bij het adresblok hoort;
	   hier verhuist het naar achter Telefoon, zodat het onderaan "Jouw
	   gegevens" staat. In code en niet in de formulierbouwer, want de
	   veldvolgorde is database en die deployt niet mee. */
	$land = null;
	foreach ( $form['fields'] as $i => $veld ) {
		if ( ! sokkies_offerte_adresveld( $veld ) ) {
			continue;
		}
		if ( sokkies_offerte_landveld( $veld ) ) {
			$land = $veld;
		}
		unset( $form['fields'][ $i ] );
	}
	$form['fields'] = array_values( $form['fields'] );

	if ( $land ) {
		/* Eigen class voor de breedte: .of-land is op het sampleformulier de
		   rest van de postcoderij (flex:1 1 175px) en zou hier dus de hele
		   regel vullen. Hier is het een halve kolom, als elk ander veld. */
		$land->cssClass = trim( $land->cssClass . ' of-land-solo' );
		$na = null;
		foreach ( $form['fields'] as $i => $veld ) {
			if ( false !== strpos( ' ' . trim( (string) $veld->cssClass ) . ' ', ' of-telefoon ' ) ) {
				$na = $i;
			}
		}
		if ( null === $na ) {
			$form['fields'][] = $land;
		} else {
			array_splice( $form['fields'], $na + 1, 0, array( $land ) );
		}
	}
	return $form;
}
add_filter( 'gform_pre_render', 'sokkies_offerte_adresblok_weg' );
add_filter( 'gform_pre_validation', 'sokkies_offerte_adresblok_weg' );
add_filter( 'gform_pre_submission_filter', 'sokkies_offerte_adresblok_weg' );

/**
 * Het veld "Aantal paar" volgt de minimale afname uit Website-instellingen.
 *
 * WAAROM IN CODE EN NIET IN DE FORMULIERBOUWER: het minimum van een getalveld
 * is een instelling van Gravity Forms en staat dus in de DATABASE — die
 * deployt niet mee. Zou het daar blijven staan, dan moest iemand het op dev en
 * op live nog een keer aanpassen, en liep het getal alsnog uiteen met de rest
 * van de site. Nu is er één knop in het CMS.
 *
 * DRIE HAKEN, dezelfde reden als bij het adresblok hierboven: zonder
 * gform_pre_validation controleert de SERVER nog op het oude minimum uit de
 * database, en dan komt een aanvraag onder het minimum er gewoon doorheen.
 *
 * De foutmelding hoeft niet mee: die komt van Gravity Forms zelf met het
 * minimum erin ("Vul een aantal in van minimaal %s.", zie de vertaalkaart in
 * functions.php), dus die volgt automatisch.
 */
function sokkies_min_afname_in_formulier( $form ) {
	if ( is_admin() || ! is_array( $form ) || empty( $form['fields'] ) ) {
		return $form;
	}
	if ( ! sokkies_form_eigen_opmaak( $form['id'] ) ) {
		return $form;
	}
	$minimum = sokkies_minimale_afname();

	foreach ( $form['fields'] as $veld ) {
		/* Herkenning op de cssClass en niet op het label: het label is
		   redactionele tekst die de klant mag hernoemen. */
		if ( false === strpos( ' ' . (string) ( $veld->cssClass ?? '' ) . ' ', ' of-aantal ' ) ) {
			continue;
		}
		$veld->rangeMin = $minimum;

		/* Een standaardwaarde ONDER het minimum zou het formulier openen in een
		   staat die meteen wordt afgekeurd. Een hogere eigen keuze (bijv. 100)
		   blijft staan. */
		if ( '' !== (string) $veld->defaultValue && (int) $veld->defaultValue < $minimum ) {
			$veld->defaultValue = $minimum;
		}

		/* Alleen de standaardzin meeschrijven. Heeft de klant er een eigen
		   toelichting van gemaakt, dan blijft die met rust. */
		if ( preg_match( '/^\s*minimaal\s+\d+\s+paar\.?\s*$/i', (string) $veld->description ) ) {
			$veld->description = 'Minimaal ' . $minimum . ' paar.';
		}
	}
	return $form;
}
add_filter( 'gform_pre_render', 'sokkies_min_afname_in_formulier' );
add_filter( 'gform_pre_validation', 'sokkies_min_afname_in_formulier' );
add_filter( 'gform_pre_submission_filter', 'sokkies_min_afname_in_formulier' );



add_filter( 'gform_field_content', function ( $content, $field ) {
	if ( ! is_object( $field ) || ! sokkies_form_eigen_opmaak( $field->formId ) ) {
		return $content;
	}

	/* De hint onder de soktypekaarten hoort bij het MAXIMUM, en dat staat in
	   code. De tekst zelf staat in de veldinstelling van Gravity Forms, dus
	   in de DATABASE — en die deployt niet mee. Stond hij daar nog op "Kies
	   één of twee soorten sokken.", dan zou live iets anders beloven dan de
	   validatie toestaat. Daarom schrijft de code hem hier — en in de taal
	   van de pagina, want als vaste tekst bleef hij overal Nederlands. */
	if ( 'Wat wil je laten bedrukken?' === $field->label && 1 === sokkies_max_soktypes( $field->formId ) ) {
		$content = preg_replace(
			'#(<div[^>]*class=["\'][^"\']*gfield_description[^"\']*["\'][^>]*>).*?(</div>)#s',
			'$1' . esc_html( sokkies_form_zin( 'Kies één soort sok.' ) ) . '$2',
			$content,
			1
		);
	}

	/* De regel met toegestane bestandstypen hoort in het ontwerp BINNEN het
	   gestippelde vlak, gecentreerd onder de instructie. GF zet hem er als
	   zusje ONDER, links uitgelijnd. Puur met CSS is hij niet te verplaatsen
	   (het is geen kind van het vlak), dus hier verhuist hij in de markup. */
	if ( 'fileupload' === $field->type ) {
		/* De regeltekst zelf opbouwen in plaats van die van GF vertalen. GF
		   plakt er drie losse stukken aan elkaar ("Accepted file types: …,
		   Max. file size: …, Max. files: …"); het ontwerp toont één regel:
		   "PDF, PNG, JPG, AI, EPS · max. 20 MB per bestand". De waarden komen
		   uit de veldinstellingen, dus als die wijzigen klopt de tekst mee. */
		$exts = array_filter( array_map( 'trim', explode( ',', (string) $field->allowedExtensions ) ) );
		$exts = array_map( 'strtoupper', $exts );
		// JPG en JPEG zijn voor de bezoeker hetzelfde; het ontwerp noemt er één.
		if ( in_array( 'JPG', $exts, true ) ) {
			$exts = array_diff( $exts, array( 'JPEG' ) );
		}
		$regeltekst = implode( ', ', $exts );
		if ( $field->maxFileSize ) {
			$regeltekst .= ' · max. ' . (int) $field->maxFileSize . ' MB per bestand';
		}

		/* Let op: GF rendert deze regel als <span>, niet als <div>. Het
		   drop-vlak zelf bevat alleen een span en een button, dus de
		   niet-gulzige match stopt bij zijn eigen sluitende </div>. */
		if ( preg_match( '#<span[^>]*gform_fileupload_rules[^>]*>.*?</span>#s', $content, $regels ) ) {
			$vervangen = preg_replace(
				'#(<span[^>]*gform_fileupload_rules[^>]*>).*?(</span>)#s',
				'$1' . str_replace( '$', '\\$', esc_html( $regeltekst ) ) . '$2',
				$regels[0],
				1
			);
			$zonder = str_replace( $regels[0], '', $content );
			$nieuw  = preg_replace(
				'#(<div[^>]*gform_drop_area[^>]*>.*?)(</div>)#s',
				'$1' . str_replace( '$', '\\$', $vervangen ) . '$2',
				$zonder,
				1
			);
			if ( $nieuw && $nieuw !== $zonder ) {
				$content = $nieuw;
			}
		}

		/* In het ontwerp is alleen het WOORD "klik" onderstreept en loopt de
		   zin daarna door: "…, of klik om te uploaden." De knop van GF is dat
		   klikbare woord; de staart van de zin zetten we er direct achter. */
		$content = preg_replace(
			'#(<button[^>]*gform_button_select_files[^>]*>.*?</button>)#s',
			'$1<span class="dz-staart"> om te uploaden.</span>',
			$content,
			1
		);
	}

	if ( ! in_array( $field->label, sokkies_offerte_optioneel_labels(), true ) ) {
		return $content;
	}
	/* Achter de labeltekst plakken, binnen de span die GF er zelf omheen zet,
	   zodat de opmaak van het label blijft kloppen. */
	$merk = ' <span class="opt" data-no-translation>' . esc_html( sokkies_form_zin( '(optioneel)' ) ) . '</span>';
	$nieuw = preg_replace(
		'#(<span class=[\'"]gform-field-label__text[\'"][^>]*>' . preg_quote( $field->label, '#' ) . ')(</span>)#',
		'$1' . $merk . '$2',
		$content,
		1
	);
	if ( $nieuw && $nieuw !== $content ) {
		return $nieuw;
	}
	// Zonder die span (andere GF-opmaak): dan direct in het label zelf.
	$nieuw = preg_replace(
		'#(<label[^>]*class=[\'"][^\'"]*gfield_label[^>]*>' . preg_quote( $field->label, '#' ) . ')#',
		'$1' . $merk,
		$content,
		1
	);
	return $nieuw ? $nieuw : $content;
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Keuzevakjes als beeldkaarten
 * -------------------------------------------------------------------------
 * htmlv toont de soktypes en de extra opties als kaartjes MET FOTO
 * (.pick-card / .extra-card). Gravity Forms rendert een kaal vakje met een
 * label. Hieronder wordt de binnenkant van dat label vervangen door exact de
 * structuur uit het ontwerp, inclusief dezelfde classnamen — zo doet de
 * bestaande CSS uit htmlv het werk en hoeft er nauwelijks nieuwe opmaak bij.
 *
 * De koppeling gaat op de LABELTEKST van de keuze, niet op een index: als er
 * ooit een soktype bij komt of de volgorde verandert, blijft de rest kloppen
 * en mist alleen de nieuwe optie een foto.
 * ------------------------------------------------------------------------- */
/**
 * DE FOTO VAN EEN SOKTYPEKAART KOMT VAN HET SOKTYPE ZELF.
 *
 * Hiervoor stond hier een vaste lijst van keuzetekst naar bestandsnaam in het
 * thema. Die brak zodra iemand de keuzes hernoemde: stap 1 stond vol lege
 * kaarten omdat de lijst nog "Reguliere sokken" verwachtte terwijl het
 * formulier inmiddels "Regulier" zegt. Bovendien moest dezelfde foto op twee
 * plekken worden bijgehouden.
 *
 * Nu leest de kaart de UITGELICHTE AFBEELDING van het bijbehorende soktype
 * (Soktypes > [type] > Uitgelichte afbeelding). Dat is dezelfde bron als de
 * collectiepagina, de productpagina en het uitklapmenu gebruiken, dus de klant
 * onderhoudt de foto op EEN plek en overal staat hetzelfde beeld.
 *
 * KOPPELEN OP WOORDEN, niet op de hele tekst: de keuze heet "Regulier" en het
 * soktype "Reguliere sokken", en "Kids & baby" hoort bij "Baby sokken". Een
 * woord telt als treffer bij gelijkheid of als het ene met het andere begint
 * (vanaf vier letters, korter matcht te veel). Het woord "sokken" telt niet
 * mee, want dat staat in bijna elke titel.
 *
 * PASSEN ER TWEE SOKTYPES, DAN WINT DE MEEST SPECIFIEKE. Het type waarvan de
 * naam helemaal op gaat in de treffer gaat voor op een type met losse woorden
 * eromheen. "Kerst" koos daardoor niet meer tussen "Kerstsokken" en
 * "Kerstsokken - actie 2026": de eerste gebruikt al zijn woorden, de tweede
 * houdt "actie" en "2026" over, dus de gewone Kerstsokken wint. Zonder die
 * regel bleef de kaart leeg zodra iemand een actie- of variantsoktype aanmaakt,
 * en dat gebeurt elk jaar opnieuw.
 *
 * BLIJFT HET GELIJKSPEL, DAN NOG EEN LAATSTE CONTROLE: wijzen alle overgebleven
 * kandidaten naar DEZELFDE afbeelding, dan valt er niets te kiezen en gebruiken
 * we die. Pas als er echt twee verschillende foto's even goed passen blijft het
 * vak leeg - liever het lege vak uit het ontwerp dan de foto van een ander
 * soktype.
 */
function sokkies_soktype_woorden( $tekst ) {
	$t   = html_entity_decode( (string) $tekst, ENT_QUOTES, 'UTF-8' );
	$t   = preg_replace( '/[^a-z0-9]+/', ' ', mb_strtolower( $t, 'UTF-8' ) );
	$uit = array();
	foreach ( preg_split( '/\s+/', trim( $t ) ) as $woord ) {
		if ( '' === $woord || in_array( $woord, array( 'sokken', 'sok', 'socks', 'en' ), true ) ) {
			continue;
		}
		$uit[] = $woord;
	}
	return $uit;
}

function sokkies_soktype_kaartfotos() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = array();
	$types = get_posts( array(
		'post_type'      => 'sokkies_soktype',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
	) );
	foreach ( $types as $type ) {
		$url = get_the_post_thumbnail_url( $type->ID, 'medium_large' );
		if ( ! $url ) {
			$url = get_the_post_thumbnail_url( $type->ID, 'full' );
		}
		if ( ! $url ) {
			continue; // geen uitgelichte afbeelding: dit type kan geen kaart vullen
		}
		$kort    = function_exists( 'get_field' ) ? get_field( 'korte_naam', $type->ID ) : '';
		$woorden = array_unique( array_merge(
			sokkies_soktype_woorden( $type->post_title ),
			sokkies_soktype_woorden( $kort )
		) );
		if ( $woorden ) {
			$cache[] = array( 'woorden' => $woorden, 'url' => $url );
		}
	}
	return $cache;
}

/**
 * Dezelfde woordvergelijking wordt door twee soorten kaarten gebruikt, dus
 * staat hij los: geef er een lijst van array('woorden'=>…, 'url'=>…) aan mee.
 */
function sokkies_kaartfoto_kies( $keuzetekst, $lijst ) {
	$zoek = sokkies_soktype_woorden( $keuzetekst );
	if ( ! $zoek || ! $lijst ) {
		return '';
	}

	/* Per kandidaat tellen we hoeveel gezochte woorden raak zijn, en hoeveel
	   woorden van de kandidaat daarna ONGEBRUIKT blijven. Dat tweede getal is
	   de maat voor specificiteit: "Kerstsokken" houdt niets over, "Kerstsokken
	   - actie 2026" houdt er twee over. */
	$kandidaten = array();
	foreach ( $lijst as $type ) {
		$score = 0;
		foreach ( $zoek as $woord ) {
			foreach ( $type['woorden'] as $ander ) {
				$kort = strlen( $woord ) < strlen( $ander ) ? $woord : $ander;
				$lang = strlen( $woord ) < strlen( $ander ) ? $ander : $woord;
				if ( $woord === $ander || ( strlen( $kort ) >= 4 && 0 === strpos( $lang, $kort ) ) ) {
					$score++;
					break;
				}
			}
		}
		if ( $score > 0 ) {
			$kandidaten[] = array(
				'score'      => $score,
				'ongebruikt' => max( 0, count( $type['woorden'] ) - $score ),
				'url'        => $type['url'],
			);
		}
	}

	if ( ! $kandidaten ) {
		return '';
	}

	/* Beste = de meeste treffers; bij gelijke treffers de minste overgebleven
	   woorden. */
	$beste = $kandidaten[0];
	foreach ( $kandidaten as $k ) {
		if ( $k['score'] > $beste['score']
			|| ( $k['score'] === $beste['score'] && $k['ongebruikt'] < $beste['ongebruikt'] ) ) {
			$beste = $k;
		}
	}

	/* Deelt iets anders exact die uitkomst, dan is de keuze niet eenduidig -
	   tenzij het om dezelfde afbeelding gaat, want dan maakt het niet uit. */
	foreach ( $kandidaten as $k ) {
		if ( $k['score'] === $beste['score']
			&& $k['ongebruikt'] === $beste['ongebruikt']
			&& $k['url'] !== $beste['url'] ) {
			return '';
		}
	}

	return $beste['url'];
}

/**
 * DE VASTE KOPPELING TUSSEN EEN FORMULIERKEUZE EN EEN SOKTYPE.
 *
 * Het uitzoeken op naam hieronder werkt, maar het blijft raden: het hangt aan
 * de WOORDEN in de keuze en in de soktypetitel. Hernoemt iemand een keuze, of
 * komt er een variant bij zoals "Kerstsokken - actie 2026", dan valt de foto
 * stil weg en is aan niets te zien waarom. Dat is twee keer gebeurd.
 *
 * Daarom kan het soktype nu zelf zeggen bij welke keuze het hoort:
 * Soktypes > [type] > "Keuze in de formulieren". Staat dat ingevuld, dan is er
 * niets meer te raden.
 *
 * DE KOPPELING GAAT OP DE WAARDE VAN DE KEUZE, niet op het zichtbare label.
 * Die waarde is wat er wordt verzonden en in Pipedrive belandt, en ligt dus
 * bewust vast; het label mag vrij veranderen. Hernoemen van "Baby sokken" naar
 * "Baby" breekt de koppeling daarmee niet. Het is ook dezelfde waarde op beide
 * formulieren, dus één keuze volstaat voor allebei.
 */
function sokkies_soktype_bij_keuze( $keuzewaarde ) {
	static $kaart = null;

	if ( null === $kaart ) {
		$kaart = array();
		if ( function_exists( 'get_field' ) ) {
			$types = get_posts( array(
				'post_type'      => 'sokkies_soktype',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'no_found_rows'  => true,
			) );
			foreach ( $types as $type ) {
				$keuze = sokkies_offerte_keuzetekst( get_field( 'formulier_keuze', $type->ID ) );
				if ( '' === trim( (string) $keuze ) ) {
					continue;
				}
				/* Eerst ingevuld wint; zo levert een dubbele koppeling geen
				   wisselend resultaat op per paginalading. */
				if ( ! isset( $kaart[ $keuze ] ) ) {
					$kaart[ $keuze ] = (int) $type->ID;
				}
			}
		}
	}

	$zoek = sokkies_offerte_keuzetekst( $keuzewaarde );

	return isset( $kaart[ $zoek ] ) ? $kaart[ $zoek ] : 0;
}

/**
 * De foto voor een soktypekaart: eerst de vaste koppeling, anders op naam.
 *
 * $keuzewaarde is de waarde van de keuze uit Gravity Forms. Wordt die niet
 * meegegeven, dan valt alles terug op het oude gedrag - zo blijft een
 * bestaande aanroep werken.
 */
function sokkies_soktype_kaartfoto( $keuzetekst, $keuzewaarde = '' ) {
	$id = $keuzewaarde ? sokkies_soktype_bij_keuze( $keuzewaarde ) : 0;
	if ( $id ) {
		$url = get_the_post_thumbnail_url( $id, 'medium_large' );
		if ( ! $url ) {
			$url = get_the_post_thumbnail_url( $id, 'full' );
		}
		if ( $url ) {
			return $url;
		}
		/* Gekoppeld maar zonder uitgelichte afbeelding: dan is het antwoord
		   "dit type heeft geen foto" en niet "pak die van een ander type". */
		return '';
	}

	return sokkies_kaartfoto_kies( $keuzetekst, sokkies_soktype_kaartfotos() );
}

/**
 * De keuzelijst voor het veld "Keuze in de formulieren" op het soktype.
 *
 * Komt rechtstreeks uit Gravity Forms, zodat de redacteur niets kan mistypen
 * en er vanzelf een regel bij komt als er een soktype aan het formulier wordt
 * toegevoegd. De SLEUTEL is de waarde van de keuze (die ligt vast, zie
 * sokkies_soktype_bij_keuze), het LABEL is de zichtbare tekst.
 *
 * Ontdubbelen gaat op de waarde en niet op de tekst: beide formulieren hebben
 * dezelfde waarden maar soms een ander label ("Baby sokken" tegenover "Baby").
 * Op de waarde vallen ze dus exact samen, zonder woordvergelijking.
 */
function sokkies_soktype_keuze_opties() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = array();
	if ( ! class_exists( 'GFAPI' ) ) {
		return $cache;
	}
	foreach ( array( 'sokkies_offerte_form_id', 'sokkies_sample_form_id' ) as $bron ) {
		if ( ! function_exists( $bron ) || ! $bron() ) {
			continue;
		}
		$form = GFAPI::get_form( $bron() );
		if ( ! $form || empty( $form['fields'] ) ) {
			continue;
		}
		foreach ( $form['fields'] as $veld ) {
			$css = ' ' . preg_replace( '/\s+/', ' ', trim( (string) $veld->cssClass ) ) . ' ';
			if ( false === strpos( $css, ' of-soktypes ' ) || empty( $veld->choices ) ) {
				continue;
			}
			foreach ( (array) $veld->choices as $keuze ) {
				$waarde = sokkies_offerte_keuzetekst( isset( $keuze['value'] ) ? $keuze['value'] : '' );
				$tekst  = sokkies_offerte_keuzetekst( isset( $keuze['text'] ) ? $keuze['text'] : '' );
				if ( '' === $waarde ) {
					continue;
				}
				/* Het eerste formulier bepaalt het label; staat er in het
				   tweede een andere schrijfwijze, dan noemen we die erbij
				   zodat de redacteur beide herkent. */
				if ( ! isset( $cache[ $waarde ] ) ) {
					$cache[ $waarde ] = '' !== $tekst ? $tekst : $waarde;
				} elseif ( '' !== $tekst && $cache[ $waarde ] !== $tekst && false === strpos( $cache[ $waarde ], $tekst ) ) {
					$cache[ $waarde ] .= ' / ' . $tekst;
				}
			}
		}
	}
	return $cache;
}

add_filter( 'acf/load_field/key=field_soktype_formulier_keuze', function ( $veld ) {
	$opties = sokkies_soktype_keuze_opties();
	if ( $opties ) {
		$veld['choices'] = $opties;
	} else {
		/* Zonder Gravity Forms is een lege keuzelijst onbruikbaar; dan maar
		   een gewoon tekstveld, net als bij de aanvullende opties. */
		$veld['type']         = 'text';
		$veld['instructions'] = 'Gravity Forms is niet beschikbaar, dus de keuzelijst kan niet worden geladen. Vul hier de waarde van de keuze met de hand in.';
	}
	return $veld;
} );

/**
 * In de lijst met soktypes laten zien waar de formulierkaart zijn foto vandaan
 * haalt.
 *
 * Dit is er omdat de fout anders onzichtbaar is: een kaart die leeg blijft valt
 * pas op als een klant het meldt. Nu staat in Soktypes meteen per rij of de
 * koppeling vastligt, of hij op naam is geraden, of dat er niets uitkomt.
 */
add_filter( 'manage_sokkies_soktype_posts_columns', function ( $kolommen ) {
	$kolommen['sokkies_formulierkaart'] = 'Formulierkaart';
	return $kolommen;
} );

add_action( 'manage_sokkies_soktype_posts_custom_column', function ( $kolom, $post_id ) {
	if ( 'sokkies_formulierkaart' !== $kolom ) {
		return;
	}

	$heeft_foto = (bool) get_post_thumbnail_id( $post_id );
	$keuze      = function_exists( 'get_field' ) ? sokkies_offerte_keuzetekst( get_field( 'formulier_keuze', $post_id ) ) : '';

	if ( '' !== trim( (string) $keuze ) ) {
		$opties = sokkies_soktype_keuze_opties();
		$label  = isset( $opties[ $keuze ] ) ? $opties[ $keuze ] : $keuze;
		if ( ! isset( $opties[ $keuze ] ) ) {
			echo '<span style="color:#b32d2e">Gekoppeld aan "' . esc_html( $keuze ) . '", maar die keuze staat niet meer in de formulieren</span>';
			return;
		}
		if ( ! $heeft_foto ) {
			echo '<span style="color:#b32d2e">' . esc_html( $label ) . ' — maar dit type heeft geen uitgelichte afbeelding</span>';
			return;
		}
		echo esc_html( $label );
		return;
	}

	/* Geen vaste koppeling: laten zien wat het raden oplevert. */
	$raak = array();
	foreach ( sokkies_soktype_keuze_opties() as $waarde => $label ) {
		$url = sokkies_kaartfoto_kies( $label, sokkies_soktype_kaartfotos() );
		if ( $url && $url === get_the_post_thumbnail_url( $post_id, 'medium_large' ) ) {
			$raak[] = $label;
		}
	}
	if ( $raak ) {
		echo '<span style="color:#996800">Op naam geraden: ' . esc_html( implode( ', ', $raak ) ) . '</span>';
	} else {
		echo '<span style="color:#b32d2e">Geen koppeling — op de formulierkaart blijft het vak leeg</span>';
	}
}, 10, 2 );
/**
 * DE VIER AANVULLENDE OPTIES ZIJN OOK IN HET CMS TE ZETTEN.
 *
 * Ze zijn geen soktype en hebben dus geen eigen post om een uitgelichte
 * afbeelding aan te hangen. Daarom staan ze op de opties-pagina:
 * Website-instellingen > Aanvullende opties, met per rij een naam en een
 * foto. Gekoppeld wordt op dezelfde woordvergelijking als bij de soktypes,
 * zodat "Inpak & verzending" ook matcht als de rij "Inpak en verzending"
 * heet.
 *
 * LEEG LATEN MAG: zonder rij (of zonder foto) valt de kaart terug op het
 * beeld uit het thema, precies zoals het stond. Zo blijft het formulier
 * werken op een omgeving waar dit tabblad nog niet is ingevuld — de
 * VELDDEFINITIE reist mee met de code, de INGEVULDE waarden niet.
 */
function sokkies_extra_kaartfotos() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = array();
	$rijen = function_exists( 'get_field' ) ? get_field( 'offerte_extras', 'option' ) : array();
	if ( ! is_array( $rijen ) ) {
		return $cache;
	}
	foreach ( $rijen as $rij ) {
		$naam = isset( $rij['naam'] ) ? trim( (string) $rij['naam'] ) : '';
		$foto = isset( $rij['foto'] ) ? (int) $rij['foto'] : 0;
		if ( '' === $naam || ! $foto ) {
			continue;
		}
		$url = wp_get_attachment_image_url( $foto, 'medium_large' );
		if ( ! $url ) {
			$url = wp_get_attachment_image_url( $foto, 'full' );
		}
		$woorden = sokkies_soktype_woorden( $naam );
		if ( $url && $woorden ) {
			$cache[] = array( 'woorden' => $woorden, 'url' => $url );
		}
	}
	return $cache;
}

/**
 * DE OPTIENAAM IS EEN KEUZELIJST UIT GRAVITY FORMS, GEEN TIKVELD.
 *
 * De opties zelf worden in Gravity Forms beheerd. Liet je de naam op de
 * opties-pagina intypen, dan staat dezelfde tekst op twee plekken en loopt
 * hij vroeg of laat uiteen: hernoemt iemand een keuze in het formulier, dan
 * wijst de rij hier stilletjes nergens meer naar en valt de foto weg zonder
 * dat iemand het merkt. Precies zo stonden de soktypekaarten eerder leeg.
 * Daarom kiest de redacteur uit de keuzes die ECHT in het formulier staan.
 *
 * ZONDER GRAVITY FORMS (of zonder formulier) blijft het een gewoon
 * tekstveld: dan is er niets om uit te kiezen, en een lege keuzelijst zou
 * het tabblad onbruikbaar maken.
 */
function sokkies_offerte_extra_keuzes() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = array();
	if ( ! class_exists( 'GFAPI' ) ) {
		return $cache;
	}
	foreach ( array( 'sokkies_offerte_form_id', 'sokkies_sample_form_id' ) as $bron ) {
		if ( ! function_exists( $bron ) ) {
			continue;
		}
		$id = $bron();
		if ( ! $id ) {
			continue;
		}
		$form = GFAPI::get_form( $id );
		if ( ! $form || empty( $form['fields'] ) ) {
			continue;
		}
		foreach ( $form['fields'] as $veld ) {
			$css = ' ' . preg_replace( '/\s+/', ' ', trim( (string) $veld->cssClass ) ) . ' ';
			if ( false === strpos( $css, ' of-extras ' ) || empty( $veld->choices ) ) {
				continue;
			}
			foreach ( (array) $veld->choices as $keuze ) {
				$tekst = sokkies_offerte_keuzetekst( isset( $keuze['text'] ) ? $keuze['text'] : '' );
				if ( '' !== $tekst ) {
					$cache[ $tekst ] = $tekst;
				}
			}
		}
	}
	return $cache;
}

add_filter( 'acf/load_field/key=field_si_extra_naam', function ( $veld ) {
	$keuzes = sokkies_offerte_extra_keuzes();
	if ( ! $keuzes ) {
		return $veld; // geen formulier gevonden: gewoon een tekstveld laten
	}
	$veld['type']       = 'select';
	$veld['choices']    = $keuzes;
	$veld['allow_null'] = 1;
	$veld['ui']         = 0;
	/* Van een TEKSTveld een select maken betekent ook de select-instellingen
	   meegeven. Zonder deze drie logde ACF bij elke paginalading "Undefined
	   array key multiple/return_format" (class-acf-field-select.php 517, 712
	   en 714) - de waarschuwingen die hier maandenlang als "bestaand" zijn
	   afgedaan, maar gewoon uit dit filter kwamen. */
	$veld['multiple']      = 0;
	$veld['ajax']          = 0;
	$veld['return_format'] = 'value';
	/* En deze twee voor ACF EXTENDED, dat ze zonder isset() uitleest
	   (field-select.php 196/201) - zelfde soort melding, andere plugin. */
	$veld['search_placeholder'] = '';
	$veld['allow_custom']       = 0;
	return $veld;
} );

/**
 * EXTRA'S DIE MAAR BIJ BEPAALDE SOKTYPES HOREN.
 *
 * Twee opties bestaan alleen voor twee soorten sok. Gravity Forms kan dat
 * NIET met zijn eigen voorwaardelijke logica: die werkt per VELD, niet per
 * losse keuze binnen een checkboxveld. Vandaar hier.
 *
 * De koppeling staat in het CMS (Website-instellingen > Aanvullende opties >
 * "Alleen bij deze soktypes") en niet in code: welke extra bij welk soktype
 * hoort is redactie, en zo hoeft er niets aangepast te worden als de matrix
 * groeit of als een keuze anders gaat heten.
 */
/**
 * Bedoelen twee keuzeteksten hetzelfde soktype? ("Antislip" / "Antislipsokken")
 *
 * Zelfde woordregel als sokkies_kaartfoto_kies: een woord telt als treffer bij
 * gelijkheid of als het ene met het andere begint (vanaf vier letters), en
 * "sokken" telt niet mee. Alle woorden van de kortste tekst moeten raak zijn,
 * zodat "Kids & baby" en "Kerst" niet per ongeluk samenvallen.
 */
function sokkies_soktype_zelfde( $a, $b ) {
	$wa = sokkies_soktype_woorden( $a );
	$wb = sokkies_soktype_woorden( $b );
	if ( ! $wa || ! $wb ) {
		return false;
	}
	$kortste = count( $wa ) <= count( $wb ) ? $wa : $wb;
	$andere  = count( $wa ) <= count( $wb ) ? $wb : $wa;

	foreach ( $kortste as $woord ) {
		$raak = false;
		foreach ( $andere as $ander ) {
			$kort = strlen( $woord ) < strlen( $ander ) ? $woord : $ander;
			$lang = strlen( $woord ) < strlen( $ander ) ? $ander : $woord;
			if ( $woord === $ander || ( strlen( $kort ) >= 4 && 0 === strpos( $lang, $kort ) ) ) {
				$raak = true;
				break;
			}
		}
		if ( ! $raak ) {
			return false;
		}
	}

	return true;
}

/**
 * Alle schrijfwijzen van één soktype, over BEIDE formulieren heen.
 *
 * De redacteur vinkt in het CMS één regel aan ("Antislip"), maar op het
 * sampleformulier heet dezelfde sok "Antislipsokken" - en de vergelijking op
 * de voorkant gaat op de WAARDE van het aangevinkte vakje. Zonder deze
 * vertaalslag zou een voorwaarde dus alleen op het offerteformulier werken.
 * Geeft altijd minstens de meegegeven naam terug.
 */
function sokkies_soktype_varianten( $naam ) {
	static $cache = array();
	$naam = trim( (string) $naam );
	if ( '' === $naam ) {
		return array();
	}
	if ( isset( $cache[ $naam ] ) ) {
		return $cache[ $naam ];
	}

	$uit = array( $naam );
	foreach ( sokkies_offerte_soktype_teksten() as $tekst ) {
		if ( $tekst !== $naam && sokkies_soktype_zelfde( $naam, $tekst ) ) {
			$uit[] = $tekst;
		}
	}

	$cache[ $naam ] = array_values( array_unique( $uit ) );
	return $cache[ $naam ];
}

/**
 * ALLE keuzeteksten van beide formulieren, ongefilterd - de ruwe bron waar
 * zowel de (ontdubbelde) keuzelijst als sokkies_soktype_varianten op leunen.
 */
function sokkies_offerte_soktype_teksten() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = array();
	if ( ! class_exists( 'GFAPI' ) ) {
		return $cache;
	}
	foreach ( array( 'sokkies_offerte_form_id', 'sokkies_sample_form_id' ) as $bron ) {
		if ( ! function_exists( $bron ) || ! $bron() ) {
			continue;
		}
		$form = GFAPI::get_form( $bron() );
		if ( ! $form || empty( $form['fields'] ) ) {
			continue;
		}
		foreach ( $form['fields'] as $veld ) {
			$css = ' ' . preg_replace( '/\s+/', ' ', trim( (string) $veld->cssClass ) ) . ' ';
			if ( false === strpos( $css, ' of-soktypes ' ) || empty( $veld->choices ) ) {
				continue;
			}
			foreach ( (array) $veld->choices as $keuze ) {
				$tekst = sokkies_offerte_keuzetekst( isset( $keuze['text'] ) ? $keuze['text'] : '' );
				if ( '' !== $tekst ) {
					$cache[ $tekst ] = $tekst;
				}
			}
		}
	}
	$cache = array_values( $cache );
	return $cache;
}

function sokkies_offerte_soktype_keuzes() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = array();
	if ( ! class_exists( 'GFAPI' ) ) {
		return $cache;
	}
	foreach ( array( 'sokkies_offerte_form_id', 'sokkies_sample_form_id' ) as $bron ) {
		if ( ! function_exists( $bron ) || ! $bron() ) {
			continue;
		}
		$form = GFAPI::get_form( $bron() );
		if ( ! $form || empty( $form['fields'] ) ) {
			continue;
		}
		foreach ( $form['fields'] as $veld ) {
			$css = ' ' . preg_replace( '/\s+/', ' ', trim( (string) $veld->cssClass ) ) . ' ';
			if ( false === strpos( $css, ' of-soktypes ' ) || empty( $veld->choices ) ) {
				continue;
			}
			foreach ( (array) $veld->choices as $keuze ) {
				$tekst = sokkies_offerte_keuzetekst( isset( $keuze['text'] ) ? $keuze['text'] : '' );
				if ( '' === $tekst ) {
					continue;
				}
				/* ÉÉN REGEL PER SOKTYPE, ook al heten ze in de twee
				   formulieren anders (2026-09-30, vraag Rick: "de lijst toont
				   elk soktype twee keer of vaker"). Het offerteformulier
				   noemt ze kort ("Antislip"), het sampleformulier voluit
				   ("Antislipsokken"); op de letterlijke tekst vallen die dus
				   niet samen en stonden er 20 regels in plaats van 10.
				   Hier telt of twee teksten HETZELFDE soktype bedoelen, met
				   dezelfde woordvergelijking die ook de kaartfoto's koppelt.
				   Het offerteformulier komt als eerste langs, dus dat is de
				   schrijfwijze die de redacteur ziet; de andere blijft
				   bruikbaar via sokkies_soktype_varianten(). */
				foreach ( array_keys( $cache ) as $bestaand ) {
					if ( sokkies_soktype_zelfde( $bestaand, $tekst ) ) {
						continue 2;
					}
				}
				$cache[ $tekst ] = $tekst;
			}
		}
	}
	return $cache;
}

add_filter( 'acf/load_field/key=field_si_extra_types', function ( $veld ) {
	$keuzes = sokkies_offerte_soktype_keuzes();
	if ( $keuzes ) {
		$veld['choices'] = $keuzes;
	}
	return $veld;
} );

/** Per extra-optie de soktypes waarbij hij hoort; leeg = altijd tonen. */
function sokkies_offerte_extra_voorwaarden() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = array();
	$rijen = function_exists( 'get_field' ) ? get_field( 'offerte_extras', 'option' ) : array();
	if ( ! is_array( $rijen ) ) {
		return $cache;
	}
	foreach ( $rijen as $rij ) {
		$naam  = isset( $rij['naam'] ) ? trim( (string) $rij['naam'] ) : '';
		$types = isset( $rij['soktypes'] ) ? array_filter( (array) $rij['soktypes'] ) : array();
		if ( '' === $naam || ! $types ) {
			continue;
		}
		/* De keuzelijst toont nog één schrijfwijze per soktype, maar op het
		   sampleformulier heet dezelfde sok anders. Daarom wordt elke
		   aangevinkte naam hier uitgeklapt naar alle schrijfwijzen, zodat
		   één vinkje op BEIDE formulieren werkt. */
		$alle = array();
		foreach ( $types as $type ) {
			$alle = array_merge( $alle, sokkies_soktype_varianten( $type ) );
		}
		$cache[ $naam ] = array_values( array_unique( $alle ) );
	}
	return $cache;
}

/**
 * VANGNET OP DE SERVER: een kaart die verborgen is kan met een aangepaste
 * verzending alsnog worden meegestuurd. De waarde wordt er dan hier uit
 * gehaald, zodat een offerte nooit een extra bevat die niet bij het gekozen
 * soktype hoort. Het scherm doet hetzelfde, maar JS kan uitvallen.
 */
add_action( 'gform_pre_submission', function ( $form ) {
	if ( ! is_array( $form ) || ! sokkies_form_eigen_opmaak( $form['id'] ) ) {
		return;
	}
	$voorwaarden = sokkies_offerte_extra_voorwaarden();
	if ( ! $voorwaarden ) {
		return;
	}
	$gekozen = array();
	$extras  = array();
	foreach ( $form['fields'] as $veld ) {
		$css = ' ' . preg_replace( '/\s+/', ' ', trim( (string) $veld->cssClass ) ) . ' ';
		$soort = false !== strpos( $css, ' of-soktypes ' ) ? 'type'
			: ( false !== strpos( $css, ' of-extras ' ) ? 'extra' : '' );
		if ( ! $soort ) {
			continue;
		}
		foreach ( (array) $veld->inputs as $invoer ) {
			$sleutel = 'input_' . str_replace( '.', '_', $invoer['id'] );
			if ( empty( $_POST[ $sleutel ] ) ) {
				continue;
			}
			$tekst = sokkies_offerte_keuzetekst( wp_unslash( $_POST[ $sleutel ] ) );
			if ( 'type' === $soort ) {
				$gekozen[] = $tekst;
			} else {
				$extras[ $sleutel ] = $tekst;
			}
		}
	}
	foreach ( $extras as $sleutel => $tekst ) {
		if ( empty( $voorwaarden[ $tekst ] ) ) {
			continue;
		}
		if ( ! array_intersect( $voorwaarden[ $tekst ], $gekozen ) ) {
			unset( $_POST[ $sleutel ] );
		}
	}
} );

function sokkies_extra_kaartfoto( $keuzetekst ) {
	$url = sokkies_kaartfoto_kies( $keuzetekst, sokkies_extra_kaartfotos() );
	if ( $url ) {
		return $url;
	}
	/* Niets in het CMS: terugvallen op het beeld uit het thema. */
	$thema = sokkies_offerte_extra_fotos();
	return empty( $thema[ $keuzetekst ] )
		? ''
		: get_template_directory_uri() . '/assets/media/' . $thema[ $keuzetekst ];
}

/**
 * De aanvullende opties zijn GEEN soktypes en hebben dus geen eigen post om
 * een foto aan te hangen; die vier houden hun beeld uit het thema. "Geen
 * extra's" heeft in het ontwerp bewust geen foto.
 */
function sokkies_offerte_extra_fotos() {
	return array(
		'Labels'             => 'gift1.png',
		'Geschenkdoosjes'    => 'gift2.png',
		'Kaartjes'           => 'gift3.png',
		'Inpak & verzending' => 'gift4.png',
	);
}

add_filter( 'gform_field_choice_markup_pre_render', function ( $markup, $choice, $field, $value ) {
	if ( ! is_object( $field ) || ! sokkies_form_eigen_opmaak( $field->formId ) ) {
		return $markup;
	}
	/* WELK VELD dit is, bepalen we op de cssClass en NIET op het label.
	   Het label is redactionele tekst: toen de keuzes hernoemd werden van
	   "Reguliere sokken" naar "Regulier" stond stap 1 vol lege kaarten. */
	$css   = ' ' . preg_replace( '/\s+/', ' ', trim( (string) $field->cssClass ) ) . ' ';
	$soort = false !== strpos( $css, ' of-soktypes ' ) ? 'pick'
		: ( false !== strpos( $css, ' of-extras ' ) ? 'extra' : '' );
	if ( ! $soort ) {
		return $markup;
	}
	// Gedecodeerd vergelijken EN tonen: zo valt de foto niet weg als de
	// keuzetekst gecodeerd is opgeslagen, en codeert esc_html() hieronder
	// precies één keer (anders zou "&amp;" op de kaart komen te staan).
	$tekst = sokkies_offerte_keuzetekst( isset( $choice['text'] ) ? $choice['text'] : '' );

	if ( 'pick' === $soort ) {
		$url = sokkies_soktype_kaartfoto( $tekst, isset( $choice['value'] ) ? $choice['value'] : '' );
	} else {
		$url = sokkies_extra_kaartfoto( $tekst );
	}

	if ( $url ) {
		$beeld = '<span class="' . $soort . '-img"><img src="' . esc_url( $url ) . '" alt="" loading="lazy"></span>';
	} else {
		/* Zonder foto krijgt de kaart het grijze vlak met het doorstreepte
		   rondje uit het ontwerp — dat is de weergave van "Geen extra's". */
		$beeld = '<span class="' . $soort . '-img ' . $soort . '-img-none">'
			. '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#8a7f70" stroke-width="1.4">'
			. '<circle cx="12" cy="12" r="9"/><path d="M5 5l14 14"/></svg></span>';
	}

	/* Een DIV, niet een span: .type-pick-outer heeft in het ontwerp padding,
	   een rand en position:relative — als inline-element klopt die opmaak niet
	   en zweven de vinkjes los van de kaart. Een <div> in een <label> is
	   geldige HTML. */
	$binnen = '<div class="type-pick-outer">' . $beeld . '<span class="pick-check"></span></div>'
		. '<span class="' . $soort . '-name">' . esc_html( $tekst ) . '</span>';

	/* Hoort deze optie maar bij bepaalde soktypes, dan gaat die lijst als
	   data-attribuut mee; offerte.js toont of verbergt de kaart daarop. */
	if ( 'extra' === $soort ) {
		$voorwaarden = sokkies_offerte_extra_voorwaarden();
		if ( ! empty( $voorwaarden[ $tekst ] ) ) {
			$markup = preg_replace(
				'#^(\s*<[a-z]+)#i',
				'$1 data-alleen-bij="' . esc_attr( implode( '|', $voorwaarden[ $tekst ] ) ) . '"',
				$markup,
				1
			);
		}
	}

	/* Alleen de INHOUD van het label vervangen; de attributen (for/id) blijven
	   staan, anders werkt het aanklikken van de kaart niet meer. */
	$nieuw = preg_replace(
		'#(<label[^>]*>).*?(</label>)#s',
		'$1' . str_replace( '$', '\\$', $binnen ) . '$2',
		$markup,
		1
	);
	if ( ! $nieuw ) {
		return $markup;
	}

	/* De ontwerpklasse op het label zetten (.pick-card / .extra-card). Dan
	   pakt de CSS die al uit htmlv in style.css staat de opmaak op en hoeft
	   er hier bijna niets nieuws bij. */
	$nieuw = preg_replace(
		'#(<label[^>]*\bclass=[\'"])#',
		'$1' . $soort . '-card ',
		$nieuw,
		1
	);

	return $nieuw ? $nieuw : $markup;
}, 10, 4 );

/** Maximum aantal soktypes per formulier-id, voor offerte.js. */
function sokkies_soktype_maxima() {
	$uit = array();
	$ids = array( sokkies_offerte_form_id() );
	if ( function_exists( 'sokkies_sample_form_id' ) ) {
		$ids[] = sokkies_sample_form_id();
	}
	foreach ( array_filter( $ids ) as $fid ) {
		$uit[ (string) $fid ] = sokkies_max_soktypes( $fid );
	}

	return $uit;
}

/**
 * Script laden zodra het offerte- of sampleformulier op de pagina staat.
 *
 * Beide gebruiken hetzelfde offerte.js: de soktypekaarten, de adresopzoeking
 * en het onthouden van ingevulde velden zijn identiek. Het script kijkt zelf
 * of de betreffende velden er staan, dus wat er niet is doet niets.
 *
 * De REST-url komt via wp_localize_script mee: op live staat de site in een
 * andere submap, dus een pad in de JavaScript hardcoderen gaat daar mis.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! sokkies_offerte_form_id() && ! ( function_exists( 'sokkies_sample_form_id' ) && sokkies_sample_form_id() ) ) {
		return;
	}
	wp_register_script(
		'sokkies-offerte',
		get_template_directory_uri() . '/assets/js/offerte.js',
		// jQuery als afhankelijkheid: het script haakt op GF's
		// gform_post_render, en zonder deze volgorde kan het script eerder
		// draaien dan jQuery en bindt die haak nooit.
		array( 'jquery' ),
		filemtime( get_template_directory() . '/assets/js/offerte.js' ),
		true
	);
	wp_localize_script(
		'sokkies-offerte',
		'sokkiesOfferte',
		array(
			'adresUrl' => esc_url_raw( rest_url( 'sokkies/v1/adres' ) ),
			/* Het maximum per FORMULIER-ID. Niet één getal voor het hele
			   script: offerte en sample delen offerte.js maar hebben een
			   ander maximum. De id's worden op titel opgezocht, dus er
			   staat ook hier geen nummer hardgecodeerd. */
			'maxSoktypes' => sokkies_soktype_maxima(),
			/* De taal van DEZE pagina, plus de twee meldingen die het script
			   zelf toont als het eindpunt niets teruggeeft. Bij het renderen
			   staat de taal vast; in de losse fetch erna niet meer. */
			'taal'        => sokkies_form_taal(),
			'meldingen'   => array(
				'nietGevonden' => sokkies_form_zin( 'We konden dit adres niet vinden.' ),
				'onbereikbaar' => sokkies_form_zin( 'De adresservice is even niet bereikbaar. Vul de gegevens zelf in.' ),
			),
		)
	);
}, 20 );

/** Pas inschakelen als een van beide formulieren daadwerkelijk gerenderd wordt. */
add_filter( 'gform_form_args', function ( $args ) {
	if ( ! empty( $args['form_id'] ) && sokkies_form_eigen_opmaak( (int) $args['form_id'] ) ) {
		wp_enqueue_script( 'sokkies-offerte' );
	}
	return $args;
} );

add_action( 'rest_api_init', function () {
	register_rest_route(
		'sokkies/v1',
		'/adres',
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'args'                => array(
				'postcode'   => array( 'required' => true ),
				'huisnummer' => array( 'required' => true ),
				/* Het gekozen land, als Engelse naam — dat is de WAARDE van de
				   optie in Gravity Forms; de zichtbare tekst is vertaald. Leeg
				   = nog niets gekozen, dan gokken we op Nederland zolang de
				   postcode Nederlands oogt. */
				'land'       => array( 'required' => false ),
				/* Kwam het land van de bezoeker ('keuze') of vulden wij het zelf
				   in na een eerdere opzoeking ('auto')? Dat verschil bepaalt de
				   melding; zie de provider. */
				'land_bron'  => array( 'required' => false ),
				/* De straat die de bezoeker koos toen postcode + huisnummer niet
				   genoeg bleken (Belgie, Duitsland, Frankrijk: daar hoort een
				   postcode bij een hele gemeente). Leeg bij de eerste poging. */
				'straat'     => array( 'required' => false ),
				/* De taal komt van de PAGINA mee. Dit eindpunt heeft zelf geen
				   taalvoorvoegsel in de url, dus het kan de taal niet afleiden —
				   en de meldingen hieronder belanden wel degelijk in beeld. */
				'taal'       => array( 'required' => false ),
			),
			'callback'            => function ( WP_REST_Request $request ) {
				$postcode   = (string) $request->get_param( 'postcode' );
				$huisnummer = (string) $request->get_param( 'huisnummer' );
				$land       = (string) $request->get_param( 'land' );
				$taal       = (string) $request->get_param( 'taal' );
				if ( ! in_array( $taal, array( 'nl', 'en', 'de', 'fr' ), true ) ) {
					$taal = 'nl';
				}

				/* De HERKOMST van het land bepaalt mede de uitkomst: een land dat
				   wij zelf invulden na een vorige opzoeking wijkt voor de postcode,
				   een zelfgekozen land niet. Daarom hier al, want het hoort in de
				   cachesleutel hieronder. */
				$land_bron = 'auto' === $request->get_param( 'land_bron' ) ? 'auto' : 'keuze';
				$straat    = trim( (string) $request->get_param( 'straat' ) );

				/* Antwoorden een dag bewaren: dezelfde postcode levert altijd
				   hetzelfde adres, en het scheelt de provider verkeer (en geld,
				   want de internationale opzoeking kost per aanroep). Het LAND
				   hoort in de sleutel: "1000" is in België iets anders dan in
				   Nederland. Het sessie-id juist NIET — dat verschilt per
				   bezoeker en zou de cache nutteloos maken. */
				$sleutel = 'sokkies_adres_' . md5( $land . '|' . $land_bron . '|' . $postcode . '|' . $huisnummer . '|' . $straat );
				$cache   = get_transient( $sleutel );
				if ( is_array( $cache ) ) {
					/* De melding hangt aan de TAAL van deze bezoeker en niet aan het
					   adres, dus die zetten we er NA het lezen bij. Stond hij in de
					   bewaarde waarde, dan kreeg een Engelse bezoeker de Nederlandse
					   zin van degene die deze postcode als eerste opzocht. */
					if ( ! empty( $cache['straat_nodig'] ) ) {
						$cache['melding'] = sokkies_form_zin( 'Vul ook de straatnaam in, dan vullen we de rest aan.', $taal );
					}
					return rest_ensure_response( $cache );
				}

				$adres = sokkies_offerte_adres_provider( $postcode, $huisnummer, $land, $land_bron, $straat );
				if ( is_wp_error( $adres ) ) {
					$code = $adres->get_error_code();
					/* Niet elk "nee" is een fout. Een Belgische postcode, een
					   land buiten de dekking of een adres dat niet eenduidig is:
					   daar heeft de bezoeker niets verkeerd gedaan, dus geen
					   rode regel maar een mededeling en de velden open. */
					$mededelingen    = array( 'buiten_dekking', 'niet_eenduidig', 'kies_land' );
					$is_mededeling   = in_array( $code, $mededelingen, true );
					$sleutel_bericht = $is_mededeling ? 'melding' : 'fout';
					$status          = 404;
					if ( 'onbereikbaar' === $code ) {
						$status = 503;
					} elseif ( $is_mededeling ) {
						$status = 200;
					}
					return new WP_REST_Response(
						array( $sleutel_bericht => sokkies_form_zin( $adres->get_error_message(), $taal ) ),
						$status
					);
				}
				/* Bewaren ZONDER de melding: die hoort bij de taal van deze bezoeker
				   en niet bij het adres. Zie de leeskant hierboven. */
				set_transient( $sleutel, $adres, DAY_IN_SECONDS );

				/* Nog geen adres maar een tussenstap: de bezoeker moet zijn straat
				   kiezen. De melding hoort in zijn taal, en dat kan alleen hier —
				   de provider geeft een array terug en geen WP_Error. */
				if ( ! empty( $adres['straat_nodig'] ) ) {
					$adres['melding'] = sokkies_form_zin( 'Vul ook de straatnaam in, dan vullen we de rest aan.', $taal );
				}
				return rest_ensure_response( $adres );
			},
		)
	);
} );

/* -------------------------------------------------------------------------
 * Navigatieknoppen
 * -------------------------------------------------------------------------
 * Twee dingen die het ontwerp wél heeft en Gravity Forms niet:
 *  1. de terugknop is in htmlv een KALE knop met een pijltje ervoor
 *     (.btn-back, regel 479/536 in offerte.html), geen omrande pil;
 *  2. stap 2 heeft naast "Volgende" ook "Overslaan" (regel 484) — die stap
 *     is volledig optioneel en dat mag de bezoeker zien.
 * ------------------------------------------------------------------------- */

/**
 * Het pijltje uit htmlv/offerte.html (regel 480). Letterlijk overgenomen,
 * inclusief de maten, zodat het icoon exact hetzelfde oogt.
 */
function sokkies_offerte_terugpijl() {
	return '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="12" viewBox="0 0 15 13"'
		. ' fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"'
		. ' stroke-linejoin="round" aria-hidden="true" focusable="false">'
		. '<path d="M13 6H2"/><path d="m6 2-4 4 4 4"/></svg>';
}

add_filter( 'gform_previous_button', function ( $knop, $form ) {
	if ( ! sokkies_is_offerte( $form ) ) {
		return $knop;
	}
	// Het pijltje vóór de tekst zetten, binnen de knop zelf.
	return preg_replace(
		'#(<button[^>]*gform_previous_button[^>]*>)#',
		'$1' . sokkies_offerte_terugpijl(),
		$knop,
		1
	);
}, 10, 2 );

/**
 * Het paginaveld dat een bepaalde pagina begint.
 *
 * De volgende-knop ONDER stap 2 wordt gebouwd uit het paginaveld dat stap 3
 * begint (form_display.php:4471); via het ID van dat veld herkennen we dus de
 * juiste knop. Bewust opzoeken in plaats van het ID hardcoderen: bij een
 * import op live liggen de veld-ID's anders.
 */
function sokkies_offerte_paginaveld( $form, $paginanummer ) {
	foreach ( (array) rgar( $form, 'fields' ) as $veld ) {
		if ( 'page' === $veld->type && (int) $veld->pageNumber === (int) $paginanummer ) {
			return $veld;
		}
	}
	return null;
}

add_filter( 'gform_next_button', function ( $knop, $form ) {
	if ( ! sokkies_is_offerte( $form ) ) {
		return $knop;
	}
	$veld = sokkies_offerte_paginaveld( $form, 3 );
	if ( ! $veld ) {
		return $knop;
	}
	// Alleen de knop onder stap 2; de andere pagina's blijven zoals ze zijn.
	$eigen_id = 'gform_next_button_' . $form['id'] . '_' . $veld->id;
	if ( false === strpos( $knop, $eigen_id ) ) {
		return $knop;
	}

	/* BEWUST een gewone knop die de echte "Volgende" aanklikt, en geen tweede
	   verzendknop. GF leidt de doelpagina af uit zijn eigen knop-ID; een
	   kopie met een ander ID zou daar naast kunnen grijpen. Zo is "Overslaan"
	   gegarandeerd exact hetzelfde als "Volgende". */
	$overslaan = '<button type="button" class="of-overslaan">Overslaan</button>';

	return $overslaan . $knop;
}, 10, 2 );

/**
 * Het URL-trackingveld de ECHTE pagina-URL geven.
 *
 * Dat veld staat in Gravity Forms op {embed_url}, en die merge tag bouwt de
 * URL uit $_SERVER['REQUEST_URI'] (forms_model.php, get_current_page_url).
 * TranslatePress heeft die op dat moment al herschreven naar het NEDERLANDSE
 * pad, want anders vindt WordPress de pagina niet. Gevolg: in de
 * beheerdersmail stond het taalvoorvoegsel met de Nederlandse slug erachter.
 * Gemeten op dev en lokaal, op allebei de formulieren:
 *   bezoeker op /en/sample-request/  ->  /en/aanvraag-voor-een-monster/
 *   bezoeker op /de/anforderung-...  ->  /de/aanvraag-voor-een-monster/
 *   bezoeker op /en/quote/           ->  /en/offerte/
 * Gemeld door Kulwant met een schermafbeelding van de mail.
 *
 * cur_page_url( true ) van TranslatePress geeft de URL MET vertaalde slugs;
 * dat is precies wat hier nodig is. get_permalink() op het opgevraagde
 * object is de terugval, en daarna pas REQUEST_URI.
 *
 * HET VELD WORDT HERKEND AAN ZIJN defaultValue en niet aan het label: een
 * label is redactionele tekst die kan veranderen, {embed_url} is de afspraak.
 */
function sokkies_form_pagina_url() {
	if ( class_exists( 'TRP_Translate_Press' ) ) {
		$trp = TRP_Translate_Press::get_trp_instance();
		$omzetter = $trp ? $trp->get_component( 'url_converter' ) : null;

		if ( $omzetter && method_exists( $omzetter, 'cur_page_url' ) ) {
			$url = $omzetter->cur_page_url( true );
			if ( ! empty( $url ) ) {
				return $url;
			}
		}
	}

	$id = get_queried_object_id();
	if ( $id ) {
		$url = get_permalink( $id );
		if ( ! empty( $url ) ) {
			return $url;
		}
	}

	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- direct door esc_url_raw.
	return isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( home_url( wp_unslash( $_SERVER['REQUEST_URI'] ) ) ) : home_url();
}

function sokkies_form_url_veld( $form ) {
	if ( ! sokkies_form_eigen_opmaak( $form ) ) {
		return $form;
	}

	$url = sokkies_form_pagina_url();
	if ( empty( $url ) ) {
		return $form;
	}

	foreach ( $form['fields'] as $veld ) {
		if ( isset( $veld->defaultValue ) && '{embed_url}' === trim( (string) $veld->defaultValue ) ) {
			$veld->defaultValue = $url;
		}
	}

	return $form;
}
add_filter( 'gform_pre_render', 'sokkies_form_url_veld' );

/**
 * Een landwaarde omzetten naar de landcode (ISO 3166-1 alfa-2).
 *
 * Slikt zowel de code zelf ("NL") als de Engelse naam ("Netherlands"). Dat
 * tweede is nodig zolang er inzendingen van voor deze wijziging rondgaan: die
 * hebben de Engelse naam als waarde. Onbekend = lege string.
 */
function sokkies_land_code( $waarde ) {
	$waarde = trim( (string) $waarde );
	if ( '' === $waarde ) {
		return '';
	}

	$alle = sokkies_landen_namen( 'en' );
	$code = strtoupper( $waarde );
	if ( isset( $alle[ $code ] ) ) {
		return $code;
	}

	$op_naam = array_flip( $alle );
	return isset( $op_naam[ $waarde ] ) ? $op_naam[ $waarde ] : '';
}

/**
 * Sorteersleutel zonder accenten.
 *
 * Anders belandt "Österreich" achter Zimbabwe en "Égypte" achter Zambia: PHP
 * sorteert op bytes, en een letter met accent staat daarin na de z.
 */
function sokkies_land_sorteersleutel( $naam ) {
	static $kaart = array(
		'á'=>'a','à'=>'a','â'=>'a','ä'=>'a','ã'=>'a','å'=>'a','ā'=>'a',
		'é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','ē'=>'e',
		'í'=>'i','ì'=>'i','î'=>'i','ï'=>'i','ī'=>'i',
		'ó'=>'o','ò'=>'o','ô'=>'o','ö'=>'o','õ'=>'o','ø'=>'o','ō'=>'o',
		'ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u','ū'=>'u',
		'ç'=>'c','č'=>'c','ć'=>'c','ñ'=>'n','ń'=>'n','š'=>'s','ś'=>'s',
		'ž'=>'z','ź'=>'z','ż'=>'z','ý'=>'y','ÿ'=>'y','đ'=>'d','ł'=>'l','ğ'=>'g',
		'æ'=>'ae','œ'=>'oe','ß'=>'ss','’'=>'', '\''=>'', '-'=>' ',
	);

	return strtr( mb_strtolower( $naam, 'UTF-8' ), $kaart );
}

/**
 * De keuzes voor het landveld, in de taal van de pagina.
 *
 * WAT DE BEZOEKER ZIET is de landnaam in zijn eigen taal; WAT HET FORMULIER
 * VERSTUURT is de landcode. Die code is in elke taal dezelfde, zodat het
 * vervolgsysteem één waarde krijgt ongeacht de taal waarin de aanvraag binnenkwam.
 *
 * Nederland, Belgie en Duitsland staan bovenaan omdat daar het leeuwendeel van
 * de aanvragen vandaan komt; de rest volgt alfabetisch IN DIE TAAL, dus
 * Oostenrijk onder de O op /nl/ en Autriche onder de A op /fr/.
 */
function sokkies_landveld_keuzes( $taal = null ) {
	$taal  = $taal ? $taal : sokkies_huidige_taal();
	$namen = sokkies_landen_namen( $taal );
	if ( ! $namen ) {
		return array();
	}

	$boven = array( 'NL', 'BE', 'DE' );
	$rest  = array_diff_key( $namen, array_flip( $boven ) );

	uasort(
		$rest,
		function ( $a, $b ) {
			return strcmp( sokkies_land_sorteersleutel( $a ), sokkies_land_sorteersleutel( $b ) );
		}
	);

	$keuzes = array();
	foreach ( $boven as $code ) {
		if ( isset( $namen[ $code ] ) ) {
			$keuzes[] = array( 'text' => $namen[ $code ], 'value' => $code );
		}
	}
	foreach ( $rest as $code => $naam ) {
		$keuzes[] = array( 'text' => $naam, 'value' => $code );
	}

	return $keuzes;
}

/**
 * Het landveld vullen met onze eigen lijst.
 *
 * De ingebouwde lijst van Gravity Forms is Engels en wordt door TranslatePress
 * maar half vertaald (op /fr/ bleven 77 van de 249 namen Engels, op /nl/ alle
 * 249). Daarom zetten we de keuzes zelf, uit een lijst die uit de CLDR-gegevens
 * is gegenereerd - zie inc/landen.php.
 *
 * Drie haken, net als bij de rest van het adresblok: zonder pre_validation
 * keurt de SERVER de ingestuurde code af omdat hij niet in de opgeslagen keuzes
 * staat, en zonder pre_submission_filter belandt de waarde niet in de inzending.
 *
 * NIET in de beheeromgeving: daar hoort de formulierbouwer te tonen wat er
 * echt in het formulier staat.
 */
function sokkies_landveld_vullen( $form ) {
	if ( is_admin() || ! sokkies_form_eigen_opmaak( $form ) ) {
		return $form;
	}

	$keuzes = sokkies_landveld_keuzes();
	if ( ! $keuzes ) {
		return $form;
	}

	foreach ( $form['fields'] as $veld ) {
		if ( sokkies_offerte_landveld( $veld ) ) {
			$veld->choices = $keuzes;
		}
	}

	return $form;
}
add_filter( 'gform_pre_render', 'sokkies_landveld_vullen' );
add_filter( 'gform_pre_validation', 'sokkies_landveld_vullen' );
add_filter( 'gform_pre_submission_filter', 'sokkies_landveld_vullen' );

/**
 * EEN LANDCODE IS GEEN LAND OM NAAR TE KIJKEN.
 *
 * De landenlijst wordt bij het renderen vervangen door ISO-codes als waarde en
 * landnamen in de taal van het formulier als label (sokkies_landveld_vullen).
 * De inzending bewaart dus "NL", en dat is precies de bedoeling: het is één
 * vaste waarde voor Pipedrive, ongeacht de taal waarin iemand het formulier
 * invulde.
 *
 * Maar het BEHEER kijkt naar de keuzes zoals ze in de formulierbouwer staan, en
 * daar staan nog de oude keuzes met de landnaam als waarde. Gravity Forms vindt
 * bij "NL" dus geen label en toont de kale code - in het inzendingenscherm én in
 * de notificatiemail. Wie de aanvraag moet afhandelen leest daardoor "NL" in
 * plaats van "Nederland" (melding met schermafbeelding).
 *
 * De twee filters hieronder zetten de code om naar de landnaam op de plekken
 * waar een MENS meekijkt. De opgeslagen waarde blijft onaangeroerd, dus wat er
 * naar Pipedrive gaat verandert niet.
 *
 * WAAROM DE CODE ERACHTER BLIJFT STAAN ("Nederland (NL)"): dat is exact wat er
 * is ingezonden, en het is de waarde waarop het vervolgsysteem matcht. Zonder
 * die code zou het beheerscherm iets anders tonen dan wat er is doorgegeven, en
 * dat is bij navragen precies het soort verschil waar je op stukloopt.
 *
 * ALLEEN ONZE EIGEN FORMULIEREN, en alleen op het veld met cssClass of-land.
 */
function sokkies_land_leesbaar( $waarde, $veld ) {
	if ( ! is_object( $veld ) || ! sokkies_offerte_landveld( $veld ) ) {
		return $waarde;
	}
	$code = strtoupper( trim( (string) $waarde ) );
	if ( ! preg_match( '/^[A-Z]{2}$/', $code ) ) {
		return $waarde; // leeg, of al een naam
	}
	if ( ! function_exists( 'sokkies_landen_namen' ) ) {
		return $waarde;
	}
	$namen = sokkies_landen_namen( 'nl' );

	return isset( $namen[ $code ] ) ? $namen[ $code ] . ' (' . $code . ')' : $waarde;
}

/* Het inzendingenscherm en de inzendingenlijst in het beheer. */
add_filter( 'gform_entry_field_value', function ( $waarde, $veld, $entry, $form ) {
	if ( ! sokkies_form_eigen_opmaak( $form ) ) {
		return $waarde;
	}
	return sokkies_land_leesbaar( $waarde, $veld );
}, 10, 4 );

/* En {all_fields} in de notificatiemail. */
add_filter( 'gform_merge_tag_filter', function ( $waarde, $merge_tag, $opties, $veld, $ruwe_waarde, $format ) {
	if ( 0 !== strpos( (string) $merge_tag, 'all_fields' ) || ! is_object( $veld ) ) {
		return $waarde;
	}
	if ( ! sokkies_form_eigen_opmaak( (int) rgobj( $veld, 'formId' ) ) ) {
		return $waarde;
	}
	if ( ! sokkies_offerte_landveld( $veld ) ) {
		return $waarde;
	}
	/* $waarde is hier de opgemaakte celinhoud; de kale code staat in
	   $ruwe_waarde. Alleen vervangen als de code er daadwerkelijk in staat. */
	$leesbaar = sokkies_land_leesbaar( $ruwe_waarde, $veld );
	if ( $leesbaar === $ruwe_waarde ) {
		return $waarde;
	}
	return str_replace( (string) $ruwe_waarde, $leesbaar, (string) $waarde );
}, 10, 6 );

/**
 * HET VELD "PAGINA URL" VULLEN MET DE PAGINA WAAR HET FORMULIER STOND.
 *
 * In de inzending staan twee URL-velden. "URL" wordt gevuld door de
 * campagne-tracker en bevat de LANDINGSPAGINA met alle utm-parameters - dus de
 * pagina waar de bezoeker binnenkwam, niet waar hij het formulier invulde.
 * Daardoor staat er bij een sample-aanvraag bijvoorbeeld /options/, en lijkt
 * het alsof het formulier daar stond (melding met schermafbeelding).
 *
 * "Pagina URL" was daar duidelijk voor bedoeld maar werd door niemand gevuld:
 * op alle bestaande inzendingen is het leeg. Dat gebeurt nu serverzijdig, bij
 * het verzenden, zodat geen enkel script het nog kan overschrijven.
 *
 * DE TWEE VELDEN BLIJVEN DUS NAAST ELKAAR BESTAAN en beantwoorden elk hun eigen
 * vraag: waar kwam deze bezoeker binnen, en waar heeft hij het formulier
 * ingevuld. Aan "URL" is bewust niets veranderd - daar hangt de
 * campagne-attributie aan.
 */
add_filter( 'gform_pre_submission_filter', function ( $form ) {
	if ( is_admin() || ! sokkies_form_eigen_opmaak( $form ) ) {
		return $form;
	}
	foreach ( $form['fields'] as $veld ) {
		if ( 'hidden' !== $veld->type || 'Pagina URL' !== trim( (string) $veld->label ) ) {
			continue;
		}
		if ( '' !== trim( (string) rgpost( 'input_' . $veld->id ) ) ) {
			continue; // iemand heeft hem al gevuld; die laten we staan
		}
		$_POST[ 'input_' . $veld->id ] = sokkies_form_pagina_url();
	}

	return $form;
}, 20 );
