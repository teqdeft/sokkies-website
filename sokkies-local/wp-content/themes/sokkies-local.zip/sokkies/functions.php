<?php
/**
 * Sokkies theme — chunk 1: assets + chrome.
 * Enqueue-volgorde is HEILIG: style.css → responsive.css (zie CLAUDE.md).
 * Cache-busting via filemtime — geen handmatige ?v= meer nodig.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function sokkies_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	// Bijschriften als <figure>/<figcaption> in plaats van de oude
	// div.wp-caption — nodig sinds afbeeldingen in de blogtekst kunnen.
	add_theme_support( 'html5', array( 'caption', 'gallery' ) );
}
add_action( 'after_setup_theme', 'sokkies_setup' );

/**
 * Ververst de permalink-regels één keer per omgeving na een slugwijziging.
 *
 * WAAROM DIT NODIG IS: WordPress bewaart de rewrite-regels in de OPTIE
 * rewrite_rules, en de database deployt niet mee. Verandert er in de code een
 * rewrite-slug, dan draait dev/live daarna nog op de oude regels en geeft de
 * nieuwe URL een 404 tot iemand Instellingen > Permalinks opent. Dat is niet
 * te zien aan de code, dus makkelijk om over het hoofd te zien.
 *
 * Verhoog SOKKIES_REWRITE_VERSIE bij elke volgende slugwijziging; de flush
 * draait dan precies één keer per omgeving. Bewust NIET elke pageload:
 * flush_rewrite_rules() herschrijft de hele optie en is traag.
 */
define( 'SOKKIES_REWRITE_VERSIE', '2026-09-30-cases' );

/**
 * Stuurt de oude case-URL's door naar de nieuwe: /cases/... -> /reviews-en-cases/...
 *
 * De rewrite-slug van sokkies_case ging op 2026-09-30 van 'cases' naar
 * 'reviews-en-cases'. WordPress vangt zoiets NIET zelf op: wp_old_slug_redirect
 * kent alleen een gewijzigde POSTslug, niet een gewijzigde rewrite-BASE. Zonder
 * deze functie geeft elke gedeelde of geïndexeerde oude link dus een 404.
 *
 * WERKT OP SEGMENTNIVEAU, niet op een tekstvervanging: alleen een paddeel dat
 * exact 'cases' is wordt vervangen. Zo blijft /reviews-en-cases/ zelf met rust
 * (daar staat 'cases' alleen als deel van een langer woord) en kan er geen lus
 * ontstaan, want na de vervanging is dat kale segment weg.
 *
 * ALLE TALEN IN ÉÉN REGEL: het taalvoorvoegsel blijft staan, dus /de/cases/x/
 * wordt /de/reviews-en-cases/x/ en TranslatePress maakt daar zelf de Duitse
 * slug van. TP VERTAALT DE SLUG NAMELIJK WEL - dat is hier eerst verkeerd
 * geconcludeerd omdat `curl -L` de EINDcode toont en de tussenliggende 301 dus
 * onzichtbaar bleef. De echte basis per taal (met hex nagemeten, want de
 * tooloutput vertaalt deze strings):
 *     nl  reviews-en-cases          de  rezensionen-und-fallbeispiele
 *     en  reviews-and-cases         fr  avis-et-temoignages
 * Daarom hoeft die lijst hier NIET in de code te staan: TP houdt hem bij en
 * een hardgecodeerde kopie zou stil verouderen zodra iemand een vertaling
 * bijwerkt.
 * KOSTEN: de ketting wordt daardoor langer - nl 1 hop, en 2, de/fr 3. Alle
 * vier eindigen op 200. Drie hops is netjes binnen wat zoekmachines volgen,
 * maar wie het korter wil moet hier de vertaalde slug opvragen bij TP.
 *
 * ALLEEN OP EEN 404: bestaat er ooit een echte pagina op /cases/, dan resolvet
 * die gewoon en grijpt deze functie niet in.
 */
function sokkies_cases_oude_url() {
	if ( ! is_404() || empty( $_SERVER['REQUEST_URI'] ) ) {
		return;
	}

	$verzoek = (string) wp_unslash( $_SERVER['REQUEST_URI'] );
	$stukken = explode( '?', $verzoek, 2 );
	$index   = array_search( 'cases', explode( '/', $stukken[0] ), true );

	if ( false === $index ) {
		return;
	}

	$segmenten            = explode( '/', $stukken[0] );
	$segmenten[ $index ]  = 'reviews-en-cases';
	$doel                 = implode( '/', $segmenten );

	if ( isset( $stukken[1] ) && '' !== $stukken[1] ) {
		$doel .= '?' . $stukken[1];
	}

	wp_safe_redirect( $doel, 301 );
	exit;
}
add_action( 'template_redirect', 'sokkies_cases_oude_url' );

/**
 * WordPress niet laten RADEN welke pagina bij een onbekende URL hoort.
 *
 * redirect_guess_404_permalink() zoekt bij een 404 een bericht waarvan de slug
 * BEGINT met het opgevraagde pad, en stuurt daar met een 301 naartoe. Op deze
 * site levert dat onzin op, want korte paden raken altijd wel iets:
 *
 *   /be   en /bed  ->  /contact/bedankt-contact/   (de bedankpagina!)
 *   /col            ->  /collectie/
 *   /off            ->  /offerte/
 *   /juri           ->  /juridisch/
 *
 * Een bezoeker die /be intypt - bijvoorbeeld op zoek naar een Belgische
 * versie - belandde zo op een bedankpagina voor een formulier dat hij nooit
 * heeft ingevuld. Dat is voor de bezoeker verwarrend en het levert zoekmachines
 * 301's op naar pagina's die niets met de URL te maken hebben.
 *
 * Nu geeft zo'n URL een gewone 404. LET OP, dat is de keerzijde: een echte
 * typefout wordt ook niet meer stilzwijgend rechtgezet. Dat is hier de betere
 * ruil, want het raden kiest simpelweg het eerste bericht dat toevallig zo
 * begint en dat is zelden wat de bezoeker bedoelde.
 */
add_filter( 'do_redirect_guess_404_permalink', '__return_false' );

/* ==========================================================================
   TIJDELIJK — /be stuurt door naar de Nederlandse site
   --------------------------------------------------------------------------
   WEGHALEN: verwijder dit hele blok, van de regel "TIJDELIJK" hierboven tot
   en met de add_action() onderaan, inclusief de functie
   sokkies_be_tijdelijke_redirect(). Er hangt verder niets aan vast: geen
   andere functie roept hem aan en er staat geen instelling in de database.
   Daarna geeft /be weer een gewone 404.

   WAAROM DIT ER STAAT: bezoekers typen /be in de verwachting een Belgische
   versie te vinden. Sinds nl_BE in TranslatePress staat bestaat die ook, maar
   op /nl_be/ - en dat typt niemand. Deze omleiding brengt ze daarheen.

   EERDER GING /be NAAR /nl/, omdat er toen nog geen Belgische versie was.
   Dat is nu achterhaald.

   LET OP, DIT GAAT UIT VAN VLAANDEREN. Belgie is tweetalig; een Waalse
   bezoeker komt zo op een Nederlandstalige pagina. Dat was met /nl/ ook al
   zo, dus het wordt er niet slechter op, maar het blijft een aanname. Wie
   het netter wil: een keuzescherm op /be/, of de taaldetectie het laten
   bepalen.

   BETER DAN DEZE OMLEIDING zou zijn om de slug van nl_BE in TranslatePress
   van "nl_be" naar "be" te zetten. Dan is /be/ gewoon de echte URL van de
   Belgische site, kan dit hele blok weg, en staat er geen liggend streepje
   in een adres waar bezoekers er geen verwachten.

   BEWUST EEN 302 EN GEEN 301: een 301 wordt door browsers en zoekmachines
   onthouden. Dan blijft /be doorsturen ook nadat dit blok weg is, en dat is
   bij de bezoeker niet meer recht te zetten. Een 302 vervalt vanzelf.

   Draait op template_redirect, dus alleen op de voorkant en pas nadat
   WordPress heeft bepaald dat er niets op deze URL staat (is_404). Komt er
   ooit een echte pagina met de slug "be", dan wint die vanzelf en doet dit
   blok niets meer.
   ========================================================================== */
function sokkies_be_tijdelijke_redirect() {
	if ( is_admin() || ! is_404() ) {
		return;
	}

	$pad = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : '';
	if ( ! $pad ) {
		return;
	}

	/* De site staat in een submap; die hoort niet bij het pad dat we toetsen. */
	$basis = (string) wp_parse_url( get_option( 'home' ), PHP_URL_PATH );
	if ( '' !== $basis && 0 === strpos( $pad, $basis ) ) {
		$pad = substr( $pad, strlen( $basis ) );
	}

	$delen = array_values( array_filter( explode( '/', strtolower( trim( $pad, '/' ) ) ) ) );

	/* TranslatePress zet er een taalvoorvoegsel voor (/be wordt /en/be), dus
	   dat eerst eraf halen - anders herkennen we het pad alleen zonder taal. */
	/* De taalvoorvoegsels komen uit TranslatePress, zodat een nieuwe taal
	   (zoals nl_BE) hier niet vergeten kan worden. */
	$voorvoegsels = array( 'nl', 'en', 'de', 'fr' );
	$tp           = get_option( 'trp_settings' );
	if ( ! empty( $tp['url-slugs'] ) ) {
		$voorvoegsels = array_map( 'strtolower', array_values( (array) $tp['url-slugs'] ) );
	}
	if ( $delen && in_array( $delen[0], $voorvoegsels, true ) ) {
		array_shift( $delen );
	}

	if ( array( 'be' ) !== $delen ) {
		return;
	}

	/* De slug komt uit TranslatePress en staat hier niet hardgecodeerd:
	   wijzigt iemand hem van "nl_be" naar "be", dan volgt deze omleiding
	   vanzelf (en wordt hij overbodig, zie hierboven). Bestaat nl_BE niet
	   meer, dan vallen we terug op de Nederlandse site zoals voorheen. */
	$slug        = 'nl';
	$instellingen = get_option( 'trp_settings' );
	if ( ! empty( $instellingen['url-slugs']['nl_BE'] ) && ! empty( $instellingen['publish-languages'] )
		&& in_array( 'nl_BE', (array) $instellingen['publish-languages'], true ) ) {
		$slug = $instellingen['url-slugs']['nl_BE'];
	}

	/* get_option('home') en niet home_url(): die laatste loopt door
	   TranslatePress en geeft de HUIDIGE taal terug, dus op /en/be zouden we
	   naar de Engelse homepage sturen. */
	wp_safe_redirect( untrailingslashit( get_option( 'home' ) ) . '/' . $slug . '/', 302 );
	exit;
}
add_action( 'template_redirect', 'sokkies_be_tijdelijke_redirect' );

/**
 * De automatische taaldetectie van TranslatePress uitzetten.
 *
 * De add-on "Automatic Language Detection" laadt op ELKE pagina het bestand
 * trp-language-cookie.js. Dat script kijkt naar de trp_language-cookie, en is
 * die er niet dan naar de browsertaal, en doet vervolgens een
 * window.location.replace() naar die taal. Dat geeft twee problemen:
 *
 * 1. De kale root stuurt serverzijdig netjes naar /en/, maar daar nam het
 *    script het over en bracht de bezoeker naar ZIJN browsertaal. Vandaar de
 *    melding dat www.sokkies.com in het Duits opende: de server deed het goed,
 *    de JavaScript erna niet.
 * 2. Typte iemand bewust /nl/, /de/ of /fr/, dan werd hij alsnog naar de taal
 *    van zijn cookie of browser gestuurd. Een expliciete keuze in de adresbalk
 *    hield dus geen stand - precies wat niet de bedoeling is.
 *
 * De filter hieronder zit in de add-on zelf en voorkomt dat het script wordt
 * ingeladen. Serverzijdig verandert er niets: de root gaat nog steeds naar
 * Engels (zie sokkies_root_taal hieronder) en een taal in de URL wordt gewoon
 * gerespecteerd.
 *
 * WAAROM IN CODE EN NIET IN DE INSTELLINGEN: de ALD-instellingen staan in de
 * DATABASE en die deployt niet mee, dus het had op elke omgeving opnieuw
 * gemoeten. Bovendien kent de keuzelijst voor de detectiemethode geen "uit" -
 * uitzetten betekent de hele add-on deactiveren, en dat is ook database.
 *
 * VEILIG: de trp_language-cookie wordt nergens serverzijdig gelezen (gecheckt
 * in zowel translatepress-multilingual als -business), het thema gebruikt hem
 * niet, en de taalwisselaar in de header bestaat uit gewone <a href>-links naar
 * de taal-URL's. Handmatig van taal wisselen werkt dus onveranderd. De popup
 * van de add-on stond al uit (popup_option: no_popup), dus er verdwijnt niets
 * zichtbaars.
 */
add_filter( 'trp_ald_enqueue_redirecting_script', '__return_false' );

/**
 * Een URL zonder taal (de kale root) is Engels.
 *
 * TranslatePress leidt de taal voor een URL zonder voorvoegsel niet af uit de
 * ingestelde standaardtaal maar uit publish-languages[0]
 * (class-language-switcher.php, determine_needed_language). De standaardtaal is
 * hier nl_NL, maar Engels staat toevallig vooraan in die lijst - en daarom komt
 * de root vandaag op /en/ uit. Sleept iemand de talen in de TP-instellingen in
 * een andere volgorde, dan verhuist de root stilletjes mee naar het Nederlands.
 *
 * Deze filter legt vast wat de bedoeling is: geen taal in de URL betekent
 * Engels. Dat is vandaag hetzelfde resultaat, dus er verandert niets aan de
 * site; het is nu alleen een keuze in plaats van een bijproduct van een
 * sorteervolgorde, en hij reist mee met een deploy.
 *
 * ALLEEN BIJ EEN URL ZONDER TAAL: staat er wel een taal in ($taal_uit_url is
 * dan gevuld), dan geven we die onaangeroerd terug. Zonder die controle zou
 * /nl/, /de/ en /fr/ naar het Engels worden omgebogen.
 */
function sokkies_root_taal( $taal, $taal_uit_url, $instellingen ) {
	if ( null !== $taal_uit_url ) {
		return $taal;
	}

	/* Mocht Engels ooit niet meer gepubliceerd zijn, dan laten we TP zijn eigen
	   keuze houden - anders zou de root naar een taal wijzen die niet bestaat. */
	$gepubliceerd = isset( $instellingen['publish-languages'] ) ? (array) $instellingen['publish-languages'] : array();
	if ( ! in_array( 'en_GB', $gepubliceerd, true ) ) {
		return $taal;
	}

	return 'en_GB';
}
add_filter( 'trp_needed_language', 'sokkies_root_taal', 10, 3 );

function sokkies_rewrite_versie() {
	if ( get_option( 'sokkies_rewrite_versie' ) === SOKKIES_REWRITE_VERSIE ) {
		return;
	}

	flush_rewrite_rules();
	update_option( 'sokkies_rewrite_versie', SOKKIES_REWRITE_VERSIE );
}
add_action( 'init', 'sokkies_rewrite_versie', 99 );

function sokkies_asset_versie( $pad ) {
	$bestand = get_template_directory() . $pad;
	return file_exists( $bestand ) ? (string) filemtime( $bestand ) : '0.1.0';
}

function sokkies_assets() {
	// Fonts (Typekit) + Swiper 11 zoals in de statische build
	wp_enqueue_style( 'sokkies-typekit', 'https://use.typekit.net/eru5btu.css', array(), null );
	wp_enqueue_style( 'swiper', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11' );

	// Volgorde: basis → responsive (banden). swiper-css laadt vóór style.css
	// zodat .brands .brands-swiper-tie blijft winnen zoals in de statische build.
	wp_enqueue_style( 'sokkies-style', get_template_directory_uri() . '/assets/css/style.css', array( 'swiper' ), sokkies_asset_versie( '/assets/css/style.css' ) );
	wp_enqueue_style( 'sokkies-responsive', get_template_directory_uri() . '/assets/css/responsive.css', array( 'sokkies-style' ), sokkies_asset_versie( '/assets/css/responsive.css' ) );

	/* AOS (Animate On Scroll) — zelfde aanpak als op sokkies.com: elementen
	   komen bij het scrollen rustig omhoog invaden. Van dezelfde CDN als
	   Swiper, zodat er maar één externe bron bijkomt. */
	wp_enqueue_style( 'aos', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css', array(), '2.3.4' );

	wp_enqueue_script( 'swiper', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11', true );
	wp_enqueue_script( 'aos', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js', array(), '2.3.4', true );

	/* VANGNET. AOS verbergt elk element met data-aos op opacity:0 en onthult
	   het pas zelf. Draait die init niet - een JS-fout eerder in custom.js is
	   in dit project al eens voorgekomen en sloopte toen alle blokken erna -
	   dan blijven koppen en kaarten PERMANENT ONZICHTBAAR. Dat is een veel
	   ergere uitkomst dan een pagina zonder animatie.

	   Daarom: lukt de init niet binnen 2,5 seconde, dan zet dit script de
	   class aos-uit op <html> en maakt de CSS alles gewoon zichtbaar. Staat
	   bewust op de aos-handle en niet in custom.js, zodat het ook werkt als
	   custom.js zelf stukloopt. */
	wp_add_inline_script(
		'aos',
		"setTimeout(function(){var h=document.documentElement;if(!h.classList.contains('aos-draait')){h.classList.add('aos-uit');}},2500);"
	);
	wp_enqueue_script( 'sokkies-custom', get_template_directory_uri() . '/assets/js/custom.js', array( 'swiper', 'aos' ), sokkies_asset_versie( '/assets/js/custom.js' ), true );
}
add_action( 'wp_enqueue_scripts', 'sokkies_assets' );

/**
 * Expivi (3D-configurator) — viewer + optiepaneel van hun CDN.
 *
 * ALLEEN op een soktype waar het veld Expivi-product-ID is ingevuld: dat is
 * de enige plek waar single-sokkies_soktype.php de #expivi-viewer-markup
 * rendert. Site-breed laden zou elke pagina een 3D-viewer laten ophalen die
 * daar niets doet.
 *
 * Geen versie meegegeven (null): de URL's wijzen zelf naar /latest/, dus een
 * ?ver= erachter zou alleen de cache breken zonder iets te pinnen. LET OP dat
 * /latest/ betekent dat Expivi hun kant kan wijzigen zonder dat wij iets
 * doen; willen we dat niet, dan moet er een vaste versie in de URL.
 *
 * app.js hangt aan viewer.js (het optiepaneel praat met de viewer), dus die
 * volgorde staat vast via de dependency.
 */
/**
 * Het Expivi-token voor de viewer.
 *
 * LET OP: dit token is GEEN geheim en kan dat ook niet zijn — de viewer
 * draait in de browser, dus het staat altijd leesbaar in de paginabron. Het
 * is Expivi's publieke catalogustoken; behandel het als een sleutel die bij
 * de site hoort, niet als een wachtwoord.
 *
 * Volgorde (zelfde patroon als sokkies_contactformulier_id): de constante
 * SOKKIES_EXPIVI_TOKEN in wp-config wint, dan de optie sokkies_expivi_token,
 * anders de waarde hieronder. Zo is het token te vervangen zonder deploy
 * wanneer Expivi hem intrekt of vernieuwt.
 */
function sokkies_expivi_token() {
	if ( defined( 'SOKKIES_EXPIVI_TOKEN' ) && SOKKIES_EXPIVI_TOKEN ) {
		return (string) SOKKIES_EXPIVI_TOKEN;
	}
	$optie = get_option( 'sokkies_expivi_token' );
	if ( $optie ) {
		return (string) $optie;
	}
	return 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNWNmYzQyZGY5ODNlZjY4MzI1YmM5ZjZmYmY2NWRlNTJjNjM3MjU0Njg3MzMxOGZiMjA4ZGU5MDVhM2QyYzg1ZDAxMmU4NWE4ZjM0MTkzOWQiLCJpYXQiOjE3ODg4NTM0NDkuMDQ5NzQzLCJuYmYiOjE3ODg4NTM0NDkuMDQ5NzQ1LCJleHAiOjIxMDQ0NzI2NDguODA5MzYxLCJzdWIiOiI2NTA4Iiwic2NvcGVzIjpbXX0.prk3_HqEiVe1ajVJztA3IRGiyVH9iF0A_q-noONRAxpYJWI1UpHVkpTuGVnJv5xR1DhdQQU9_lGvQBjoAunwv5yYSCjcwyZYOUo5xHTIX91WF70S43_g8XTyRj6NCu39zkKDKjmTQRfu-iqyiDnXo1IpazPGPwbzNufNURcxhQkISNp84dVHLBbM4B1Qd1s6OVKCK84WzFb7BQBNxI6m3TpgjxdR5TXGu4qRbu-q6IbALM32ZB4ueovZyRYTfzAhKJUCxpIhDxTOZHOPXLBptUglaH-ECkw6qWJbWYngEofMFqTTyb3IjHT5U0XBOv0kuM7Nj-msXpBzOHP0bakO_G1PTNsGLlvxCpcgqG6ZobSw7u3b3MZ9FKMoIbR0c7mPKh5l26J3VC8PiWU6moy3B5YyNkOTgjSBZmRKwJlPowqkLZTkstPWCuqJKdCeXtNbvXXzt_d_At7ZOKXBnwUeKN3zjUnUFkK69MlKzF-q3aQxPaWr-zs5kCa5cLj-NJQ9VXzm3nXLrBhhQ5zks9xMbGApDqpvfqLJRCpgYrrWDxrDKjwti2H_RjQx2qCFqGozi1pQMkNeFcQYRN87a6RQy8qSE4mzsblRyuIdmHZRbGAZnfKyfz0PU1WtDlbWVHfD5C1jDZcXJNBYtfPijqfj-t40mKa_UE0J_qudJWnSXyE';
}

function sokkies_expivi_assets() {
	if ( ! is_singular( 'sokkies_soktype' ) ) {
		return;
	}
	if ( ! function_exists( 'get_field' ) ) {
		return;
	}
	$catalogus = (int) get_field( 'expivi_product_id' );
	if ( ! $catalogus ) {
		return;
	}

	wp_enqueue_style( 'expivi-options', 'https://assets.expivi.net/options/latest/css/app.css', array(), null );
	wp_enqueue_script( 'expivi-viewer', 'https://assets.expivi.net/viewer/latest/viewer.js', array(), null, true );
	wp_enqueue_script( 'expivi-options', 'https://assets.expivi.net/options/latest/js/app.js', array( 'expivi-viewer' ), null, true );

	/* Init hangt aan app.js, dus die staat gegarandeerd al in de pagina; de
	   load-listener wacht daarnaast tot de viewer klaar is met initialiseren.
	   De guard op ExpiviComponent vangt een CDN die niet laadt: zonder guard
	   gooit dat een ReferenceError en sterft alles wat erna komt. */
	$config = array(
		'catalogueId'     => $catalogus,
		'viewerContainer' => '#expivi-viewer',
		'optionContainer' => '#expivi-options',
		'priceSelectors'  => '#expivi-price',
		'currency'        => 'EUR',
		'locale'          => 'nl',
		'token'           => sokkies_expivi_token(),
	);

	wp_add_inline_script(
		'expivi-options',
		'window.addEventListener("load", function () {' .
		'  if (typeof ExpiviComponent === "undefined") { return; }' .
		'  window.SOKKIES_EXPIVI = new ExpiviComponent.default(' . wp_json_encode( $config ) . ');' .
		'});'
	);
}
add_action( 'wp_enqueue_scripts', 'sokkies_expivi_assets' );

// Favicon uit het thema (tot er een site-icon is ingesteld)
function sokkies_favicon() {
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" type="image/png" href="' . esc_url( get_template_directory_uri() . '/assets/media/favicon.png' ) . '">' . "\n";
	}
}
add_action( 'wp_head', 'sokkies_favicon' );

/**
 * Chunk 2: active-state voor het vaste menu (statische conventie:
 * li.menu-link krijgt 'active' op de huidige pagina; Inspiratie dekt
 * toepassingen/reviews/downloads — zelfde mapping als de htmlv-build).
 */
function sokkies_actief( $slugs ) {
	if ( in_array( 'home', (array) $slugs, true ) && is_front_page() ) {
		return ' active';
	}
	return is_page( $slugs ) ? ' active' : '';
}

/**
 * Chunk 3: pagina's bewerken als pure sectie-builder — Gutenberg uit voor
 * pages (het ACF-veld 'Secties' ís de editor; design blijft in code).
 */
add_filter( 'use_block_editor_for_post_type', function ( $gebruik, $post_type ) {
	return ( 'page' === $post_type ) ? false : $gebruik;
}, 10, 2 );
add_filter( 'use_block_editor_for_post', function ( $gebruik, $post ) {
	return ( $post && 'page' === $post->post_type ) ? false : $gebruik;
}, 10, 2 );
// Sterkste hefboom: pages hebben geen contenteditor — de klassieke
// bewerkpagina toont dan alleen titel + het Secties-veld (de builder).
add_action( 'init', function () {
	remove_post_type_support( 'page', 'editor' );
}, 100 );

// Custom post types
require_once get_template_directory() . '/inc/cpt.php';

// ACF-veldgroepen (PHP-registratie — zie inc/acf-fields.php)
require_once get_template_directory() . '/inc/acf-fields.php';

// Landnamen per taal met de ISO-landcode als sleutel. Moet VOOR het
// offerteformulier geladen zijn: dat gebruikt de lijst voor het landveld.
require_once get_template_directory() . '/inc/landen.php';

// Logica van het offerteformulier (max. 2 soktypes, 'Geen extra's'-uitsluiting,
// en de adresopzoeking). Apart bestand omdat het meer is dan een paar regels.
require_once get_template_directory() . '/inc/offerte-formulier.php';

// Eenmalige aanmaak van de juridische pagina's waar ze ontbreken (de
// inhoud staat in inc/juridisch-inhoud.php) — zie de toelichting daar.
require_once get_template_directory() . '/inc/juridisch-seed.php';

// Logica van het sampleformulier. Deelt de opmaakfilters met het
// offerteformulier hierboven; hier staat alleen wat sample-eigen is.
require_once get_template_directory() . '/inc/sample-formulier.php';

/* Formulieren volgen de taal van de bezoeker: mailonderwerp, veldlabels in
   de beheerdersmail, de bevestigingsmail en de meldingen in het formulier. */
require_once get_template_directory() . '/inc/formulier-talen.php';

/**
 * Site-instelling uit de ACF-opties-pagina, met hardcoded fallback zolang
 * de opties nog niet zijn opgeslagen (of ACF uit staat).
 */
function sokkies_optie( $naam, $standaard = '' ) {
	$waarde = function_exists( 'get_field' ) ? get_field( $naam, 'option' ) : null;
	return ( null === $waarde || '' === $waarde ) ? $standaard : $waarde;
}

/**
 * De minimale afname in paren — ÉÉN bron voor het hele project.
 *
 * Het getal staat in Website-instellingen > Cijfers & reviews > "Minimale
 * afname (paar)" en wordt gebruikt op élke plek waar het op de site komt: de
 * topbalk, de kaarten op de collectiepagina, de pluspunten-blokken, de
 * prijscalculator (waar de slider begint) en het minimum van het offerte- en
 * het sampleformulier. Eén keer wijzigen in het CMS is dus genoeg.
 *
 * DE TERUGVAL IS 50 EN DAT IS GEEN DETAIL: de optiewaarde staat in de
 * DATABASE en die deployt niet mee. Op een omgeving waar niemand de
 * opties-pagina ooit heeft opgeslagen draait de site dus op dit getal. Stond
 * hier 30, dan bleef daar de oude afname staan terwijl het CMS 50 zei.
 */
function sokkies_minimale_afname() {
	$aantal = (int) sokkies_optie( 'minimale_afname', 50 );
	return $aantal > 0 ? $aantal : 50;
}
/**
 * MAG HET TELEFOONNUMMER OP DEZE PAGINA STAAN?
 *
 * Op de Duitse en Franse site niet (verzoek klant): er bellen Duitse en Franse
 * klanten die geen Nederlands spreken, en Sokkies spreekt geen Frans. Die
 * gesprekken kosten meer dan ze opleveren. Op het Nederlands, Engels en
 * Belgisch Nederlands blijft het nummer gewoon staan.
 *
 * DE TAAL EN NIET DE LOCALE: nl_BE hoort hier bij het Nederlands, dus Belgie
 * houdt het nummer. Zou dat ooit anders moeten, dan is sokkies_huidige_locale()
 * de functie om op te vergelijken.
 *
 * Dit verbergt alleen de WEERGAVE. Het nummer blijft in Website-instellingen
 * staan en de mails en de offertes gebruiken het gewoon.
 */
function sokkies_telefoon_tonen() {
	$zonder = apply_filters( 'sokkies_talen_zonder_telefoon', array( 'de', 'fr' ) );

	return ! in_array( sokkies_huidige_taal(), (array) $zonder, true );
}

/**
 * MAG WHATSAPP GETOOND WORDEN?
 *
 * Nee, overal uit (verzoek klant): de aanvragen die via dat kanaal binnenkomen
 * zijn van matige kwaliteit en kosten meer tijd dan ze opbrengen.
 *
 * BEWUST EEN SCHAKELAAR EN GEEN SLOOPWERK. De knoppen, iconen en opmaak staan
 * er nog; ze worden alleen niet meer uitgevoerd. Wil de klant het ooit terug,
 * dan is dat deze ene functie op true zetten in plaats van zeven sjablonen
 * opnieuw opbouwen. Het nummer zelf blijft ook gewoon in Website-instellingen
 * staan.
 */
function sokkies_whatsapp_tonen() {
	return (bool) apply_filters( 'sokkies_whatsapp_tonen', false );
}
function sokkies_tel_href() {
	return 'tel:' . preg_replace( '/[^0-9+]/', '', (string) sokkies_optie( 'telefoon_internationaal', '+31413410411' ) );
}

function sokkies_wa_href() {
	return 'https://wa.me/' . preg_replace( '/[^0-9]/', '', (string) sokkies_optie( 'telefoon_internationaal', '+31413410411' ) );
}

/**
 * Platte tekst uit een textarea als nette regels.
 *
 * Het patroon nl2br( esc_html( $veld ) ) stond op een stuk of twaalf plekken in
 * het thema (subteksten van de paginakoppen, de CTA-sub, de impact-tekst, de
 * case-teksten). Dat escapet terecht alle HTML, maar daardoor komt een <br> die
 * een redacteur zelf typt LETTERLIJK op de site te staan - precies wat er in de
 * footer met het adres gebeurde.
 *
 * Redacteuren typen dat nu eenmaal: in het CMS is een veld een tekstvak en de
 * gewoonte om er HTML in te zetten is hardnekkig. Daarom wordt een KALE <br>
 * hier eerst een gewoon regeleinde, en pas daarna wordt er geescaped.
 *
 * Alleen een kale <br> telt mee. Alles met attributen (<br onmouseover=...>) en
 * elke andere tag blijft gewoon geescapeerd, dus dit maakt het veld geen
 * HTML-veld en er kan niets ingespoten worden.
 *
 * Typt iemand <br> EN drukt hij op enter, dan staan er twee regeleindes; die
 * worden samengetrokken zodat de tekst niet dubbel gespatieerd raakt.
 */
/**
 * {minimum} in een tekstveld wordt de minimale afname.
 *
 * Nodig omdat het getal niet alleen in de chrome staat maar ook MIDDEN IN
 * redactionele tekst: de pluspunten onder de hero ("Vanaf 50 paar"), een rij
 * in de vergelijkingstabel, FAQ-antwoorden. Die teksten staan in de database
 * en kunnen dus geen PHP bevatten; zonder zo'n teken blijft daar een los
 * getal achter dat bij de volgende wijziging stil verkeerd komt te staan —
 * precies hoe "vanaf 30 paar" op de site bleef staan nadat het 50 werd.
 *
 * Tekst zonder het teken verandert niet, dus bestaande inhoud is veilig.
 */
function sokkies_minimum_in_tekst( $tekst ) {
	$tekst = (string) $tekst;
	if ( false === strpos( $tekst, '{' ) ) {
		return $tekst;
	}
	return preg_replace( '/\{\s*minimum\s*\}/i', (string) sokkies_minimale_afname(), $tekst );
}

function sokkies_tekst_regels( $tekst ) {
	$tekst = sokkies_minimum_in_tekst( $tekst );
	$tekst = preg_replace( '#<\s*br\s*/?\s*>#i', "\n", $tekst );
	$tekst = preg_replace( '/[ \t]+$/m', '', $tekst );
	$tekst = preg_replace( '/\R{2,}/', "\n", $tekst );

	return nl2br( esc_html( trim( $tekst ) ) );
}

/**
 * Het adres uit Website-instellingen als nette regels.
 *
 * Hier begon het: in het adresveld stond een getypte <br>, die door esc_html
 * LETTERLIJK op de site kwam ("De Morgenstond 45<br>"). De afhandeling daarvan
 * zit in sokkies_tekst_regels(), zodat het adres en alle andere tekstvakken
 * zich hetzelfde gedragen.
 *
 * Werkt ongeacht wat er in de database staat, dus ook op een omgeving waar
 * niemand het veld opnieuw opslaat.
 */
function sokkies_adres( $standaard = '' ) {
	return sokkies_tekst_regels( sokkies_optie( 'adres', $standaard ) );
}

/**
 * Kop-tekst veilig renderen: [woord] wordt de gele highlight
 * (<span class="text-yellow">) en <br> blijft werken; overige HTML wordt
 * geneutraliseerd.
 */
function sokkies_kop( $tekst, $klasse = 'text-yellow' ) {
	$veilig = esc_html( sokkies_minimum_in_tekst( $tekst ) );
	$veilig = str_ireplace( array( '&lt;br&gt;', '&lt;br /&gt;', '&lt;br/&gt;' ), '<br>', $veilig );
	// Markeren kan op twee manieren: [woord] of <span>woord</span>
	// (de htmlv-notatie); beide krijgen de meegegeven kleur-class.
	$veilig = preg_replace( '/&lt;span.*?&gt;/i', '<span class="' . esc_attr( $klasse ) . '">', $veilig );
	$veilig = str_ireplace( '&lt;/span&gt;', '</span>', $veilig );
	return preg_replace( '/\[([^\]\[]+)\]/', '<span class="' . esc_attr( $klasse ) . '">$1</span>', $veilig );
}

/**
 * De taal waarin de bezoeker de pagina bekijkt, als nl/en/de/fr.
 *
 * TranslatePress zet de gekozen taal in $GLOBALS['TRP_LANGUAGE'] (nl_NL,
 * en_GB, de_DE, fr_FR) en stuurt daar ook get_locale() mee. We kijken naar
 * allebei, zodat het ook klopt als het thema buiten een TranslatePress-
 * verzoek draait, bijvoorbeeld bij het versturen van een mail.
 */
function sokkies_taal() {
	$locale = isset( $GLOBALS['TRP_LANGUAGE'] ) ? (string) $GLOBALS['TRP_LANGUAGE'] : get_locale();
	return strtolower( substr( $locale, 0, 2 ) );
}

/**
 * Het downloadbestand van een kaart in de juiste taal.
 *
 * TranslatePress vertaalt tekst, maar verwisselt GEEN PDF: een Engelse
 * bezoeker kreeg dus de Nederlandse brochure. Daarom heeft elke kaart een
 * eigen veld per taal, met de terugvalketen uit sokkies_taalbijlage().
 *
 * $taal is optioneel, zodat een mail die LATER wordt verstuurd het bestand
 * kan opvragen voor de taal waarin de bezoeker het formulier invulde, en
 * niet voor de taal van het verzoek waarin de mail toevallig vertrekt.
 */
function sokkies_download_bestand( $kaart, $taal = null ) {
	return sokkies_taalbijlage( $kaart, 'bestand', $taal );
}

/**
 * De afbeelding van een download-kaart in de juiste taal.
 *
 * Zelfde verhaal als het bestand hierboven: op de cover van een brochure
 * staat tekst, dus een Engelse bezoeker hoort de Engelse cover te zien bij
 * de Engelse PDF. Velden Afbeelding (NL/EN/DE/FR), met dezelfde keten.
 *
 * BEELD EN BESTAND STAAN LOS VAN ELKAAR. Wie alleen een Duitse PDF uploadt
 * en geen Duitse cover, krijgt de Nederlandse cover bij de Duitse PDF — dat
 * is met opzet beter dan de kaart leeg laten, en het scheelt de redacteur
 * werk zolang de cover taalneutraal is.
 */
function sokkies_download_foto( $kaart, $taal = null ) {
	return sokkies_taalbijlage( $kaart, 'foto', $taal );
}

/**
 * De bijlage (bestand of afbeelding) van een kaart in de juiste taal.
 *
 * Eén plek voor de terugvalregel, zodat het beeld nooit anders kan gaan
 * werken dan de PDF eronder: $basis is het veld van de standaardtaal
 * (bestand/foto) en {$basis}_{taal} is de vertaling ervan.
 *
 * DE KETEN IS: gevraagde taal -> Engels -> Nederlands (2026-09-29, besluit
 * van de klant). Engels stond eerst niet in die rij en alles viel meteen
 * terug op Nederlands. De terugval raakt per definitie alleen bezoekers die
 * GEEN Nederlands lezen — een Nederlandse bezoeker krijgt immers gewoon het
 * Nederlandse veld — en voor die groep is Engels een stuk begrijpelijker.
 * Nederlands blijft wel de laatste stap: is er ook geen Engelse versie, dan
 * is een Nederlandse PDF nog altijd beter dan een knop die nergens heen gaat.
 *
 * LET OP: de keten kan geen bestand verzinnen dat er niet is. Zolang er
 * alleen een Nederlandse versie bestaat, verandert er voor de bezoeker
 * niets — dat is precies de bedoeling, niet een fout.
 */
function sokkies_taalbijlage( $kaart, $basis, $taal = null ) {
	$taal  = $taal ? strtolower( substr( (string) $taal, 0, 2 ) ) : sokkies_taal();
	$talen = array( 'en', 'de', 'fr' );

	/* LET OP DE VOLGORDE VOOR NEDERLANDS. Voor een Nederlandse bezoeker IS
	   het kale veld de gevraagde taal, dus dat moet als eerste — anders
	   krijgt juist de Nederlandse site de Engelse PDF zodra die bestaat.
	   Engels blijft er als vangnet achter staan voor het geval het
	   Nederlandse veld leeg is. Een onbekende taal volgt dezelfde weg. */
	if ( in_array( $taal, $talen, true ) ) {
		$volgorde = array( $basis . '_' . $taal, $basis . '_en', $basis );
	} else {
		$volgorde = array( $basis, $basis . '_en' );
	}

	foreach ( array_unique( $volgorde ) as $veld ) {
		if ( ! empty( $kaart[ $veld ]['url'] ) ) {
			return $kaart[ $veld ];
		}
	}

	return null;
}

/**
 * Datum in het Nederlands, bijvoorbeeld "28 augustus 2026, 14:32".
 *
 * BEWUST NIET wp_date()/date_i18n(): de site draait op locale en_US zonder
 * Nederlands taalbestand, dus die geven "August". De hele voorkant is
 * Nederlands, en een bezoeker die net iets heeft aangevraagd hoort geen
 * Engelse maandnaam te zien. De sitetaal omzetten zou de héle beheeromgeving
 * en alle plugin-teksten meenemen — te grof voor dit ene zinnetje.
 */
function sokkies_datum_nl( $tijd, $met_tijd = true ) {
	$tijd = (int) $tijd;
	if ( ! $tijd ) {
		return '';
	}
	/* De maandnamen volgen de taal van de pagina. Zonder dit zou een Franse
	   bedankpagina "17 september" tonen naast Franstalige tekst. wp_date()
	   kan dit niet: de site draait op en_US zonder taalbestanden, en de
	   sitetaal omzetten raakt de hele beheeromgeving. */
	$per_taal = array(
		'nl' => array( 'januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december' ),
		'en' => array( 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ),
		'de' => array( 'Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember' ),
		'fr' => array( 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre' ),
	);
	$taal    = function_exists( 'sokkies_form_taal' ) ? sokkies_form_taal() : 'nl';
	$maanden = array_combine( range( 1, 12 ), isset( $per_taal[ $taal ] ) ? $per_taal[ $taal ] : $per_taal['nl'] );
	$dag   = (int) wp_date( 'j', $tijd );
	$maand = $maanden[ (int) wp_date( 'n', $tijd ) ];
	$jaar  = wp_date( 'Y', $tijd );
	return $met_tijd
		? sprintf( '%d %s %s, %s', $dag, $maand, $jaar, wp_date( 'H:i', $tijd ) )
		: sprintf( '%d %s %s', $dag, $maand, $jaar );
}

/**
 * Page-scope class op <main> — de pagina-slug, met uitzonderingen waar de
 * CSS-class uit htmlv anders heet dan de slug.
 */
function sokkies_main_class() {
	$slug = (string) get_post_field( 'post_name' );
	$map  = array(
		'veelgestelde-vragen' => 'faq-page',
	);
	$klasse = isset( $map[ $slug ] ) ? $map[ $slug ] : $slug;

	// De juridische opmaak (beige kop, donkere tekst) hangt in htmlv aan
	// .juridisch. Die scope volgt hier de SECTIE, niet de slug — zo werkt
	// elke nieuwe juridische pagina (privacy, cookies, …) meteen goed,
	// zonder dat de uitzonderingsmap hierboven moet meegroeien.
	$layouts = get_post_meta( get_the_ID(), 'secties', true );
	if ( is_array( $layouts ) && in_array( 'juridisch', $layouts, true ) && 'juridisch' !== $klasse ) {
		$klasse .= ' juridisch';
	}

	// Het optieoverzicht én de optiepagina's eronder (Labels, Kaartjes,
	// Geschenkdoosjes, Inpakservice) delen één scope-class, zodat opmaak
	// voor die hele familie in één regel te schrijven is in plaats van per
	// slug. Net als bij 'juridisch' hierboven volgt die scope de STRUCTUUR:
	// /opties/ zelf en alles wat eronder hangt krijgt hem, dus een nieuwe
	// optiepagina hoeft alleen de juiste bovenliggende pagina te krijgen en
	// is meteen goed.
	$ouder      = (int) get_post_field( 'post_parent' );
	$ouder_slug = $ouder ? (string) get_post_field( 'post_name', $ouder ) : '';
	if ( 'opties' === $slug || 'opties' === $ouder_slug ) {
		$klasse .= ' optie-pagina';
	}

	return $klasse;
}

/**
 * Staffelmatrix uit de opties-pagina "Prijzen & staffels", in de vorm die
 * custom.js verwacht: { sleutel: { label, rows: [[aantal, prijs], …] } }.
 */
function sokkies_staffel_matrix() {
	$rijen = function_exists( 'get_field' ) ? get_field( 'staffel', 'option' ) : null;
	if ( ! $rijen ) {
		return array();
	}
	$matrix = array();
	foreach ( $rijen as $rij ) {
		$sleutel = sanitize_title( $rij['naam'] );
		$prijzen = array();
		foreach ( (array) ( $rij['prijzen'] ?: array() ) as $p ) {
			$prijzen[] = array( (int) $p['vanaf'], (float) $p['prijs'] );
		}
		if ( $sleutel && $prijzen ) {
			$matrix[ $sleutel ] = array( 'label' => mb_strtolower( $rij['naam'] ), 'rows' => $prijzen );
		}
	}
	return $matrix;
}

// Prijsmatrix vóór custom.js zetten zodat de calculator de CMS-prijzen leest.
add_action( 'wp_enqueue_scripts', function () {
	$staffel = sokkies_staffel_matrix();
	if ( $staffel ) {
		wp_add_inline_script( 'sokkies-custom', 'window.SOKKIES_TIERS = ' . wp_json_encode( $staffel ) . ';', 'before' );
	}

}, 20 );

/**
 * Logorijen in de footer (keurmerken, goede doelen, betalen, verzenden).
 *
 * Geeft de rijen uit Website-instellingen terug, of - als er niets is
 * ingevuld - de set uit het ontwerp. Dat is dezelfde afspraak als bij de
 * secties en de menu's: LEEG = de statische inhoud, zodat de footer er zonder
 * ingevulde velden exact uitziet als voorheen.
 *
 * $standaard is een lijst van array( 'bestand' => …, 'alt' => … ); die
 * bestanden staan in assets/media van het thema.
 */
function sokkies_footer_logos( $naam, $standaard ) {
	$rijen = sokkies_optie( $naam, array() );
	$uit   = array();

	if ( is_array( $rijen ) ) {
		foreach ( $rijen as $rij ) {
			$logo = isset( $rij['logo'] ) ? $rij['logo'] : null;
			if ( ! is_array( $logo ) || empty( $logo['url'] ) ) {
				continue; // lege repeaterrij overslaan
			}
			$uit[] = array(
				'url'  => $logo['url'],
				'alt'  => isset( $logo['alt'] ) ? $logo['alt'] : '',
				'link' => isset( $rij['link'] ) ? $rij['link'] : '',
			);
		}
	}

	if ( $uit ) {
		return $uit;
	}

	$basis = get_template_directory_uri() . '/assets/media/';
	foreach ( $standaard as $s ) {
		$uit[] = array( 'url' => $basis . $s['bestand'], 'alt' => $s['alt'], 'link' => '' );
	}

	return $uit;
}

/**
 * Trapsgewijze vertraging voor de scroll-animatie van een rij items.
 *
 * Loopt rond over 100/200/300/400 ms, dezelfde opbouw als op sokkies.com: de
 * kaarten in een rij komen kort na elkaar in beeld in plaats van allemaal
 * tegelijk. Na vier items begint de reeks opnieuw, zodat een lange rij niet
 * eindigt met items die seconden later pas verschijnen.
 */
function sokkies_aos_stap( $i ) {
	$stappen = array( 100, 200, 300, 400 );

	return $stappen[ (int) $i % 4 ];
}

/**
 * De gepubliceerde talen als keuzelijst voor ACF: code => nette naam.
 *
 * Leest dezelfde bron als sokkies_talen() (de TranslatePress-instellingen),
 * zodat er automatisch een taal bijkomt zodra die gepubliceerd wordt en er
 * niets hardgecodeerd hoeft te worden.
 *
 * Zonder TranslatePress - of in het beheer voordat de plugin geladen is -
 * valt hij terug op de vier talen die de site nu heeft, zodat het
 * bewerkscherm nooit een leeg keuzeveld toont.
 */
function sokkies_taal_keuzes() {
	$namen = array(
		'nl' => 'Nederlands',
		'en' => 'Engels',
		'de' => 'Duits',
		'fr' => 'Frans',
	);

	$instellingen = get_option( 'trp_settings', array() );
	$gepubliceerd = isset( $instellingen['publish-languages'] ) ? (array) $instellingen['publish-languages'] : array();

	if ( ! $gepubliceerd ) {
		return $namen;
	}

	/* Op de SLUG en niet op de taalcode, anders vallen nl_NL en nl_BE samen
	   en is Belgie niet apart te kiezen. */
	$slugs = isset( $instellingen['url-slugs'] ) ? (array) $instellingen['url-slugs'] : array();
	$uit   = array();
	foreach ( $gepubliceerd as $code ) {
		$deel  = explode( '_', $code );
		$taal  = strtolower( $deel[0] );
		$sleutel = isset( $slugs[ $code ] ) ? strtolower( $slugs[ $code ] ) : $taal;
		$naam  = isset( $namen[ $taal ] ) ? $namen[ $taal ] : strtoupper( $taal );
		/* Een regiovariant krijgt het land erbij, zodat "Nederlands" en
		   "Nederlands (Belgie)" uit elkaar te houden zijn in het beheer. */
		if ( isset( $deel[1] ) && $sleutel !== $taal ) {
			$naam .= ' (' . strtoupper( $deel[1] ) . ')';
		}
		$uit[ $sleutel ] = $naam;
	}

	return $uit;
}

/**
 * Filtert een lijst logo-ID's op de taal die de bezoeker nu bekijkt.
 *
 * Een logo zonder taalkeuze verschijnt in ALLE talen - dat is de bestaande
 * situatie, dus wie niets instelt merkt niets. Pas zodra er talen zijn
 * aangevinkt, verschijnt het logo alleen daar.
 *
 * Zo kan de Franse site een andere merkenrij tonen dan de Nederlandse,
 * inclusief een ander AANTAL logo's - iets wat met het vertalen van losse
 * afbeeldingen niet zou kunnen.
 */
function sokkies_logos_voor_taal( $logo_ids ) {
	if ( ! $logo_ids ) {
		return $logo_ids;
	}

	$taal = sokkies_huidige_taal();
	$uit  = array();

	foreach ( (array) $logo_ids as $logo_id ) {
		$talen = function_exists( 'get_field' ) ? get_field( 'talen', $logo_id ) : null;

		// Niets aangevinkt = overal tonen.
		if ( ! is_array( $talen ) || ! $talen ) {
			$uit[] = $logo_id;
			continue;
		}

		if ( sokkies_taal_past( $talen ) ) {
			$uit[] = $logo_id;
		}
	}

	return $uit;
}

/**
 * De publieke reviewpagina waar de reviewregels naartoe linken.
 *
 * Stond op vier plekken los in de templates. Nu op één plek, zodat een
 * verhuizing naar een andere reviewpartij één regel is in plaats van zoeken.
 *
 * De reviewBLOKKEN in de footer gebruiken deze niet: die hebben per blok een
 * eigen linkveld in Website-instellingen, omdat daar ook naar Google gelinkt
 * wordt.
 */
function sokkies_reviews_url() {
	return 'https://www.feedbackcompany.com/nl-nl/reviews/sokkies/';
}

/**
 * De juridische links van de footer, als kant-en-klare <a>'s.
 *
 * ÉÉN BRON VOOR TWEE FOOTERS: de volledige footer zet ze in zijn slotregel
 * (met KVK en BTW erachter), de mini-footer van de funnel- en contactpagina's
 * toont dezelfde links achter het copyright. Door ze hier op te halen kunnen
 * die twee niet uit elkaar lopen — wie een link toevoegt in
 * Website-instellingen > Footer-inhoud ziet hem meteen op allebei.
 *
 * De taalvoorwaarde per rij werkt hetzelfde als in het footermenu: geen taal
 * aangevinkt = overal, anders alleen in de aangevinkte talen. Zo staat het
 * Impressum (Duitse wettelijke plicht) alleen in de Duitse footer, terwijl de
 * pagina zelf in elke taal bereikbaar blijft.
 *
 * Leeg = de twee links uit het ontwerp, net als overal in dit thema.
 */
function sokkies_footer_legal_links() {
	$links   = array();
	$taal_nu = sokkies_huidige_taal();
	$rijen   = sokkies_optie( 'footer_legal', array() );

	if ( is_array( $rijen ) ) {
		foreach ( $rijen as $rij ) {
			$talen = isset( $rij['talen'] ) ? (array) $rij['talen'] : array();
			if ( ! sokkies_taal_past( $talen ) ) {
				continue;
			}
			$link  = isset( $rij['link'] ) ? $rij['link'] : null;
			$url   = is_array( $link ) ? ( isset( $link['url'] ) ? $link['url'] : '' ) : (string) $link;
			$label = isset( $rij['label'] ) && '' !== trim( (string) $rij['label'] )
				? $rij['label']
				: ( is_array( $link ) && ! empty( $link['title'] ) ? $link['title'] : '' );
			if ( '' === $url || '' === $label ) {
				continue;
			}
			$links[] = '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
		}
	}

	if ( ! $links ) {
		$links = array(
			'<a href="' . esc_url( home_url( '/juridisch/' ) ) . '">Algemene voorwaarden</a>',
			'<a href="' . esc_url( home_url( '/cookieverklaring/' ) ) . '">Cookieverklaring</a>',
		);
	}

	return $links;
}

/**
 * De slotregel van de footer: copyright, juridische links, KVK en BTW.
 *
 * DE DRIE SPANS ZIJN GEEN OPMAAK-TOEVAL. Op mobiel worden ze blokken en gaan
 * de .fl-sep-scheidingstekens uit, zodat de regel over drie regels valt zoals
 * in het ontwerp (zie de ≤520-band in responsive.css). Daarom wordt de inhoud
 * hier over precies die drie spans verdeeld en niet als één lange string
 * uitgeschreven.
 *
 * De verdeling volgt het ontwerp: copyright + eerste link | tweede link +
 * KVK | BTW. Zijn er meer of minder juridische links, dan schuiven ze mee in
 * de eerste twee spans.
 */
function sokkies_footer_slotregel() {
	$copyright = sokkies_optie( 'footer_copyright', '© 2026 Sokkies' );
	$kvk       = sokkies_optie( 'footer_kvk', '89538226' );
	$btw       = sokkies_optie( 'footer_btw', 'NL865014218B01' );

	// Juridische links: gedeeld met de mini-footer, inclusief taalvoorwaarde.
	$links = sokkies_footer_legal_links();

	$punt = ' &nbsp;•&nbsp; ';

	// Span 1: copyright + de eerste link. Span 2: de rest van de links + KVK.
	$eerste = array_shift( $links );
	$span1  = esc_html( $copyright ) . ( $eerste ? $punt . $eerste : '' );

	$span2 = $links ? implode( $punt, $links ) : '';
	if ( '' !== trim( (string) $kvk ) ) {
		$span2 .= ( $span2 ? $punt : '' ) . 'KVK: ' . esc_html( $kvk );
	}

	$span3 = '' !== trim( (string) $btw ) ? 'BTW: ' . esc_html( $btw ) : '';

	$uit = '<span>' . $span1 . '</span>';
	if ( $span2 ) {
		$uit .= '<span class="fl-sep">' . $punt . '</span><span>' . $span2 . '</span>';
	}
	if ( $span3 ) {
		$uit .= '<span class="fl-sep">' . $punt . '</span><span>' . $span3 . '</span>';
	}

	echo $uit; // phpcs:ignore WordPress.Security.EscapeOutput -- onderdelen zijn hierboven los ge-escaped
}

/**
 * De reviewblokken onderin de footer (logo, cijfer, sterren, link).
 *
 * De sterrenrij zit als vaste SVG in de template: die is altijd vijf sterren
 * en hoort niet bij de redactionele inhoud.
 */
function sokkies_footer_reviews() {
	$rijen = sokkies_optie( 'footer_reviews', array() );
	$uit   = array();

	if ( is_array( $rijen ) ) {
		foreach ( $rijen as $rij ) {
			$logo = isset( $rij['logo'] ) ? $rij['logo'] : null;
			if ( ! is_array( $logo ) || empty( $logo['url'] ) ) {
				continue;
			}
			$uit[] = array(
				'logo'   => $logo['url'],
				'alt'    => isset( $logo['alt'] ) ? $logo['alt'] : '',
				'score'  => isset( $rij['score'] ) ? $rij['score'] : '',
				'aantal' => isset( $rij['aantal'] ) ? $rij['aantal'] : '',
				'link'   => isset( $rij['link'] ) ? $rij['link'] : '',
			);
		}
	}

	if ( $uit ) {
		return $uit;
	}

	$basis = get_template_directory_uri() . '/assets/media/';

	return array(
		array(
			'logo'   => $basis . 'feedbackcompany.svg',
			'alt'    => 'Feedback Company',
			'score'  => '9.5/10',
			'aantal' => '300+',
			'link'   => 'https://www.feedbackcompany.com/nl-nl/reviews/sokkies/',
		),
		array(
			'logo'   => $basis . 'google-logo.svg',
			'alt'    => 'Google',
			'score'  => '4.7/5.0',
			'aantal' => '120+',
			/* Letterlijk de URL zoals hij in de footer stond. Hij is lang en bevat
			   parameters die uit een adresbalk komen (rlz, sourceid, ie); inkorten
			   tot het lrd-fragment kan waarschijnlijk, maar dat is niet getest en
			   dit is een terugval - dus onveranderd overgenomen. */
			'link'   => 'https://www.google.com/search?q=sokkies&rlz=1C1GCEA_enIN1087IN1087&oq=sokk&gs_lcrp=EgZjaHJvbWUqCAgBEEUYJxg7MgYIABBFGDwyCAgBEEUYJxg7Mg8IAhAuGEMYsQMYgAQYigUyBggDEEUYPDIGCAQQRRg8MgYIBRBFGEEyBggGEEUYQTIGCAcQRRhB0gEIMTk3NGowajmoAgawAgHxBTB4DxjRhI-6&sourceid=chrome&source=chrome.ob&ie=UTF-8#lrd=0x47c6e36e5bf03a73:0xa7bdabd85a4c91fe,1,,,,',
		),
	);
}

/**
 * Het icoon bij een social in de footer.
 *
 * De iconen zitten als inline-SVG in het thema en niet in de mediabibliotheek:
 * ze zijn eenkleurig wit en moeten meeschalen met de knop. De redacteur kiest
 * dus het PLATFORM en vult alleen het adres in.
 *
 * Onbekend platform geeft een lege string; de link wordt dan niet gerenderd,
 * zodat er nooit een leeg vierkantje verschijnt.
 */
function sokkies_footer_social_icoon( $platform ) {
	$iconen = array(
		'linkedin'  => '<svg xmlns="http://www.w3.org/2000/svg" width="20.923" height="20" viewBox="0 0 20.923 20"><path d="M4.75,20V6.506H.265V20ZM2.508,4.663A2.339,2.339,0,1,0,2.537,0a2.338,2.338,0,1,0-.059,4.663h.029ZM7.232,20h4.485V12.464a3.074,3.074,0,0,1,.148-1.094,2.455,2.455,0,0,1,2.3-1.64c1.623,0,2.272,1.237,2.272,3.051V20h4.485V12.263c0-4.145-2.213-6.073-5.164-6.073a4.468,4.468,0,0,0-4.072,2.274h.03V6.506H7.232c.059,1.266,0,13.494,0,13.494Z" fill="#fff"/></svg>',
		'facebook'  => '<svg xmlns="http://www.w3.org/2000/svg" width="12.1" height="22" viewBox="0 0 12.1 22"><path d="M223.75,12688.016h-3.3a5.5,5.5,0,0,0-5.5,5.5v3.3h-3.3v4.4h3.3v8.8h4.4v-8.8h3.3l1.1-4.4h-4.4v-3.3a1.1,1.1,0,0,1,1.1-1.1h3.3Z" transform="translate(-211.65 -12688.016)" fill="#fff"/></svg>',
		'instagram' => '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"><path d="M169.908,12694.2a1.337,1.337,0,1,0-1.863-.027,1.336,1.336,0,0,0,1.863.027Zm-10.906.814a5.654,5.654,0,1,1,0,8,5.656,5.656,0,0,1,0-8Zm2.593,7.389a3.669,3.669,0,1,0-2.265-3.391,3.668,3.668,0,0,0,2.265,3.391Zm5.849-12.344c-1.159-.055-1.507-.064-4.445-.064s-3.285.01-4.445.064a6.042,6.042,0,0,0-2.043.379,3.622,3.622,0,0,0-2.087,2.086,6.108,6.108,0,0,0-.379,2.043c-.053,1.16-.064,1.508-.064,4.445s.011,3.285.064,4.445a6.108,6.108,0,0,0,.379,2.043,3.622,3.622,0,0,0,2.087,2.086,6.092,6.092,0,0,0,2.043.379c1.159.055,1.507.064,4.445.064s3.285-.01,4.445-.064a6.092,6.092,0,0,0,2.043-.379,3.622,3.622,0,0,0,2.087-2.086,6.108,6.108,0,0,0,.379-2.043c.053-1.16.064-1.508.064-4.445s-.011-3.285-.064-4.445a6.108,6.108,0,0,0-.379-2.043,3.622,3.622,0,0,0-2.087-2.086,6.042,6.042,0,0,0-2.043-.379Zm-8.98-1.98c1.173-.055,1.547-.066,4.535-.066s3.362.014,4.534.066a8.13,8.13,0,0,1,2.672.51,5.638,5.638,0,0,1,3.216,3.219,8.086,8.086,0,0,1,.512,2.67c.054,1.174.066,1.549.066,4.535s-.013,3.361-.066,4.535a8.051,8.051,0,0,1-.512,2.67,5.613,5.613,0,0,1-3.216,3.217,8.072,8.072,0,0,1-2.67.512c-1.174.055-1.548.066-4.536.066s-3.362-.014-4.535-.066a8.072,8.072,0,0,1-2.67-.512,5.619,5.619,0,0,1-3.218-3.217,8.123,8.123,0,0,1-.511-2.67c-.054-1.174-.066-1.549-.066-4.535s.013-3.361.066-4.533a8.091,8.091,0,0,1,.511-2.672,5.636,5.636,0,0,1,3.217-3.219,8.128,8.128,0,0,1,2.67-.51Z" transform="translate(-152 -12688.016)" fill="#fff"/></svg>',
		'tiktok'    => '<svg xmlns="http://www.w3.org/2000/svg" width="19.068" height="22" viewBox="0 0 19.068 22"><g transform="translate(-2.398 -0.8)"><path d="M19.091,5.505a5.008,5.008,0,0,1-.433-.252,6.09,6.09,0,0,1-1.112-.945,5.246,5.246,0,0,1-1.253-2.586h0A3.186,3.186,0,0,1,16.247.8H12.468V15.41c0,.2,0,.39-.008.582,0,.024,0,.046,0,.071a.158.158,0,0,1,0,.033V16.1A3.208,3.208,0,0,1,10.84,18.65a3.153,3.153,0,0,1-1.563.412,3.208,3.208,0,0,1,0-6.416,3.158,3.158,0,0,1,.981.155l0-3.847a7.019,7.019,0,0,0-5.408,1.582,7.415,7.415,0,0,0-1.618,2A6.913,6.913,0,0,0,2.4,15.705a7.49,7.49,0,0,0,.406,2.508v.009a7.384,7.384,0,0,0,1.026,1.871,7.678,7.678,0,0,0,1.637,1.544v-.009l.009.009A7.07,7.07,0,0,0,9.337,22.8a6.828,6.828,0,0,0,2.863-.633,7.184,7.184,0,0,0,2.325-1.747,7.262,7.262,0,0,0,1.267-2.105,7.885,7.885,0,0,0,.456-2.408V8.155c.046.027.656.431.656.431a8.739,8.739,0,0,0,2.252.931,12.967,12.967,0,0,0,2.311.316V6.083A4.9,4.9,0,0,1,19.091,5.505Z" fill="#fff"/></g></svg>',
	);

	return isset( $iconen[ $platform ] ) ? $iconen[ $platform ] : '';
}

/**
 * De nette schrijfwijze van een platformnaam, voor het aria-label.
 * ucfirst() zou er "Linkedin" en "Tiktok" van maken.
 */
function sokkies_footer_social_naam( $platform ) {
	$namen = array(
		'linkedin'  => 'LinkedIn',
		'facebook'  => 'Facebook',
		'instagram' => 'Instagram',
		'tiktok'    => 'TikTok',
	);

	return isset( $namen[ $platform ] ) ? $namen[ $platform ] : ucfirst( $platform );
}

/**
 * De socials in de footer: platform + adres, of de standaardset.
 */
function sokkies_footer_socials() {
	$rijen = sokkies_optie( 'footer_socials', array() );
	$uit   = array();

	if ( is_array( $rijen ) ) {
		foreach ( $rijen as $rij ) {
			$platform = isset( $rij['platform'] ) ? $rij['platform'] : '';
			$url      = isset( $rij['url'] ) ? trim( (string) $rij['url'] ) : '';
			if ( '' === $platform || '' === $url ) {
				continue;
			}
			$uit[] = array( 'platform' => $platform, 'url' => $url );
		}
	}

	if ( $uit ) {
		return $uit;
	}

	return array(
		array( 'platform' => 'linkedin', 'url' => 'https://www.linkedin.com/company/sokkies/' ),
		array( 'platform' => 'facebook', 'url' => 'https://www.facebook.com/Sokkies' ),
		array( 'platform' => 'instagram', 'url' => 'https://www.instagram.com/sokkiesnl/' ),
	);
}

/**
 * Meldingen van de nieuwsbriefformulieren.
 *
 * Deze zinnen worden in JAVASCRIPT opgebouwd en staan dus nergens als tekst in
 * de pagina, waardoor TranslatePress ze niet ziet - op de Engelse site bleef
 * "Vul je e-mailadres in." gewoon Nederlands staan.
 *
 * Zelfde oplossing als bij de calculator (sokkies_calc_teksten): de zinnen gaan
 * als VERBORGEN tekst mee. TranslatePress vertaalt server-side en kijkt daarbij
 * niet of iets zichtbaar is, dus ze belanden in het woordenboek; de JS leest ze
 * er weer uit. Werkt voor elke taal die erbij komt, zonder Engels in het thema.
 */
function sokkies_nieuwsbrief_teksten() {
	$teksten = array(
		'leeg'        => 'Vul je e-mailadres in.',
		'uit'         => 'Inschrijven lukt nu even niet. Probeer het later opnieuw.',
		'bezig'       => 'Bezig met inschrijven…',
		'gelukt'      => 'Gelukt! Check je mail om je inschrijving te bevestigen.',
		'foutAdres'   => 'Inschrijven lukte niet. Controleer je e-mailadres.',
		'foutAlgemeen' => 'Inschrijven lukte niet. Probeer het later opnieuw.',
	);

	echo '<div class="nieuwsbrief-teksten" hidden aria-hidden="true">';
	foreach ( $teksten as $sleutel => $tekst ) {
		printf( '<span data-k="%s">%s</span>', esc_attr( $sleutel ), esc_html( $tekst ) );
	}
	echo '</div>';
}

/**
 * Klaviyo-gegevens voor de nieuwsbriefformulieren.
 *
 * De sleutel en de lijst komen uit de KLAVIYO-PLUGIN (optie klaviyo_settings,
 * beheerscherm Klaviyo), niet uit Website-instellingen. Zo staat het op één
 * plek en hoeft er niets gedupliceerd te worden.
 *
 * ALLEEN DE PUBLIEKE SLEUTEL gaat naar de browser. Die hoort daar ook thuis -
 * Klaviyo's client-side endpoint is er expliciet voor gemaakt - en met alleen
 * die sleutel kan niemand gegevens UITLEZEN, alleen een inschrijving indienen.
 * De geheime API-sleutel blijft buiten het thema.
 *
 * Geeft een lege array zodra er geen sleutel of geen lijst is ingesteld. De
 * formulieren blijven dan gewoon staan maar melden netjes dat inschrijven even
 * niet kan, in plaats van in het niets te posten.
 */
function sokkies_klaviyo() {
	$instellingen = get_option( 'klaviyo_settings' );
	if ( ! is_array( $instellingen ) ) {
		return array();
	}

	$sleutel = isset( $instellingen['klaviyo_public_api_key'] ) ? trim( (string) $instellingen['klaviyo_public_api_key'] ) : '';
	$lijst   = isset( $instellingen['klaviyo_newsletter_list_id'] ) ? trim( (string) $instellingen['klaviyo_newsletter_list_id'] ) : '';

	if ( '' === $sleutel || '' === $lijst ) {
		return array();
	}

	return array( 'sleutel' => $sleutel, 'lijst' => $lijst );
}

// Klaviyo-gegevens vóór custom.js zetten, zelfde patroon als de staffelmatrix.
add_action( 'wp_enqueue_scripts', function () {
	$klaviyo = sokkies_klaviyo();
	if ( $klaviyo ) {
		wp_add_inline_script( 'sokkies-custom', 'window.SOKKIES_KLAVIYO = ' . wp_json_encode( $klaviyo ) . ';', 'before' );
	}
}, 20 );

/**
 * Teksten die de calculator in JAVASCRIPT opbouwt: de staffelregels, de badges
 * en het upsell-vak. Die staan nergens als tekst in de pagina, dus
 * TranslatePress kon ze niet oppikken - op de Engelse site bleven "Meest
 * gekozen", "Bespaar ... p.p." en "... per paar minder dan bij ..." daardoor
 * Nederlands.
 *
 * Ze worden nu als VERBORGEN tekst meegestuurd. TranslatePress vertaalt de
 * HTML server-side en kijkt daarbij niet of iets zichtbaar is, dus deze spans
 * gaan gewoon mee in het woordenboek; de JS leest ze er weer uit. Dat werkt
 * voor elke taal die erbij komt, zonder Engels in het thema te zetten.
 *
 * %s is het aantal of het bedrag - dat vult de JS in.
 */
function sokkies_calc_teksten() {
	$teksten = array(
		'paar'         => '%s paar',
		'paarPlus'     => '5.000+ paar',
		'meestGekozen' => 'Meest gekozen',
		'bespaar'      => 'Bespaar %s p.p.',
		'bijPaar'      => 'Bij %s paar betaal je',
		'perPaar'      => '%s per paar',
		'minderDan'    => '%1$s per paar minder dan bij %2$s paar',
		'klikOm'       => 'Klik om %s paar te kiezen',
		'laagste'      => 'Dit is de laagste prijs',
		'besteStaffel' => 'Vanaf %s paar is dit de beste staffel',
	);

	echo '<div class="calc-teksten" hidden aria-hidden="true">';
	foreach ( $teksten as $sleutel => $tekst ) {
		printf( '<span data-k="%s">%s</span>', esc_attr( $sleutel ), esc_html( $tekst ) );
	}
	echo '</div>';
}

/**
 * SVG-uploads toestaan voor beheerders (de ontwerp-iconen zijn svg's).
 * Twee filters nodig: de mime-lijst én WP's inhoudscontrole. Alleen voor
 * gebruikers met beheerrechten — krijgt de site ooit meer redacteuren,
 * overweeg dan de Safe SVG-plugin (die saneert bestanden ook).
 */
add_filter( 'upload_mimes', function ( $mimes ) {
	if ( current_user_can( 'manage_options' ) ) {
		$mimes['svg']  = 'image/svg+xml';
		$mimes['svgz'] = 'image/svg+xml';
	}
	return $mimes;
} );
add_filter( 'wp_check_filetype_and_ext', function ( $data, $file, $filename, $mimes ) {
	if ( preg_match( '/\.svgz?$/i', (string) $filename ) && current_user_can( 'manage_options' ) ) {
		$data['ext']  = 'svg';
		$data['type'] = 'image/svg+xml';
	}
	return $data;
}, 10, 4 );
// Svg-voorvertoningen zichtbaar maken in de mediabibliotheek.
add_action( 'admin_head', function () {
	echo '<style>.media-icon img[src$=".svg"], .attachment-preview img[src$=".svg"] { width: 100%; height: auto; }</style>' . "\n";
} );

/**
 * Hulpscript voor Website-instellingen (2026-09-30, verzoek Kulwant: een
 * optie die al gekozen is hoort niet meer in de keuzelijst van de andere
 * rijen te staan).
 *
 * ALLEEN OP DIE PAGINA geladen: het script hangt aan één veldsleutel en
 * heeft elders niets te zoeken. De schermcontrole gaat op de menu-slug,
 * want ACF maakt er per subpagina een eigen hook-naam van.
 *
 * Waarom dit niet in PHP kan: de keuzelijst wordt serverzijdig één keer
 * gezet voor het hele veld, terwijl WELKE rij wat gekozen heeft pas in het
 * scherm bekend is - en tijdens het bewerken verandert.
 */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( false === strpos( (string) $hook, 'sokkies-instellingen' ) ) {
		return;
	}
	$pad = get_template_directory() . '/assets/js/admin-opties.js';
	wp_enqueue_script(
		'sokkies-admin-opties',
		get_template_directory_uri() . '/assets/js/admin-opties.js',
		array(),
		file_exists( $pad ) ? filemtime( $pad ) : null,
		true
	);
} );

/**
 * FAQ-antwoord veilig renderen: alleen eenvoudige opmaak. Geplakte
 * layout-HTML (divs/classes, bijv. een gekopieerd accordeon-item uit de
 * statische site) wordt gestript — structuurtags in een antwoord braken
 * het accordeon-JS (teamfeedback 2026-08-20).
 */
function sokkies_rijke_tekst( $html ) {
	$html = sokkies_minimum_in_tekst( $html );
	// wp_kses verwijdert <script> en <style> wel, maar LAAT DE INHOUD STAAN:
	// een geplakt style-blok of een shortcode die inline JS uitspuugt komt dan
	// als zichtbare bodytekst op de pagina (een [gravityform] dumpt zo zijn hele
	// geminificeerde script als alineatekst). Niet uitvoerbaar, wel lelijk — dus
	// eerst de inhoud zelf eruit, daarna pas de witte lijst.
	$html = preg_replace( '#<(script|style)\b[^>]*>.*?</\1>#is', '', $html );
	$toegestaan = array(
		'p' => array(), 'br' => array(), 'strong' => array(), 'em' => array(),
		'b' => array(), 'i' => array(), 'u' => array(),
		'a' => array( 'href' => true, 'target' => true, 'rel' => true ),
		'ul' => array(), 'ol' => array(), 'li' => array(),
		// Tabellen (toegevoegd 2026-08-25, melding Kulwant): een in de wysiwyg
		// geplakte tabel werd hier weggestript, waardoor alleen de celtekst
		// overbleef en de prijstabel op de PDP als losse woorden verscheen.
		// BEWUST GEEN width/style/align: de opmaak hoort in de stylesheet, en
		// inline breedtes uit Word/Excel breken de responsive kolommen.
		'table' => array(), 'thead' => array(), 'tbody' => array(), 'tfoot' => array(),
		'tr' => array(), 'caption' => array(),
		'th' => array( 'colspan' => true, 'rowspan' => true, 'scope' => true ),
		'td' => array( 'colspan' => true, 'rowspan' => true ),
	);
	return wp_kses( $html, $toegestaan );
}

/**
 * Blogtekst renderen: als sokkies_rijke_tekst(), maar MET afbeeldingen.
 *
 * Bewust een aparte functie en geen vlag op de gedeelde helper: de
 * FAQ-antwoorden en certificaten-tabs horen afbeeldingen juist te blijven
 * strippen (daar breken ze de opmaak), en een boolean-parameter op een
 * gedeelde helper wordt vroeg of laat op de verkeerde plek aangezet.
 *
 * do_shortcode eerst: een afbeelding met bijschrift staat in de editor als
 * [caption]-shortcode en zou anders als letterlijke tekst verschijnen. Door
 * de html5-themasupport rendert die naar <figure>/<figcaption>.
 */
function sokkies_blog_tekst( $html ) {
	$html = do_shortcode( (string) $html );
	$html = preg_replace( "#<(script|style)\b[^>]*>.*?</\1>#is", "", $html );
	$toegestaan = array(
		"p" => array(), "br" => array(), "strong" => array(), "em" => array(),
		"b" => array(), "i" => array(), "u" => array(),
		"a" => array( "href" => true, "target" => true, "rel" => true ),
		"ul" => array(), "ol" => array(), "li" => array(),
		"h3" => array(), "h4" => array(),
		"img" => array(
			"src" => true, "alt" => true, "width" => true, "height" => true,
			"class" => true, "srcset" => true, "sizes" => true,
			"loading" => true, "decoding" => true,
		),
		"figure" => array( "class" => true ),
		"figcaption" => array( "class" => true ),
		"table" => array(), "thead" => array(), "tbody" => array(), "tfoot" => array(),
		"tr" => array(), "caption" => array(),
		"th" => array( "colspan" => true, "rowspan" => true, "scope" => true ),
		"td" => array( "colspan" => true, "rowspan" => true ),
	);
	return wp_kses( $html, $toegestaan );
}

/**
 * Mag deze FAQ-categorie op de algemene FAQ-pagina staan?
 *
 * De schakelaar staat op de categorie zelf: Veelgestelde vragen > Categorieen >
 * [categorie] > "Tonen op de FAQ-pagina". Daarmee kan Rick een hele categorie
 * van /veelgestelde-vragen/ halen zonder de vragen zelf aan te raken; ze
 * blijven gewoon staan waar ze gekozen zijn.
 *
 * NIETS OPGESLAGEN = TONEN, en dat is hier geen detail: een ACF-standaardwaarde
 * wordt pas weggeschreven als iemand het scherm één keer opslaat. Zou een lege
 * waarde als "nee" gelden, dan was de FAQ-pagina na deze wijziging in één klap
 * leeg geweest — op elke omgeving, tot iemand alle categorieen had opengeklikt.
 */
function sokkies_faq_cat_op_faq_pagina( $term ) {
	if ( ! function_exists( 'get_field' ) ) {
		return true;
	}
	$waarde = get_field( 'toon_op_faq_pagina', $term );
	if ( null === $waarde || '' === $waarde ) {
		return true;
	}
	return (bool) $waarde;
}

/**
 * De FAQ-vragen die aan een soktype hangen.
 *
 * ÉÉN VELD BEPAALT ALLES: koppelt Rick een vraag aan een soktype
 * (Soktypes > [type] > Productpagina > Veelgestelde vragen), dan staat hij op
 * die productpagina en verdwijnt hij van de algemene FAQ-pagina. Er is dus
 * geen tweede vinkje "algemeen ja/nee" dat uit de pas kan lopen met de eerste.
 *
 * ALLEEN GEPUBLICEERDE SOKTYPES TELLEN MEE, en dat is met opzet: zet iemand
 * een soktype op concept, dan is die productpagina weg en zouden die vragen
 * nergens meer staan. Nu vallen ze terug op de algemene FAQ-pagina.
 *
 * Rechtstreeks op postmeta omdat get_field() per soktype een eigen query doet;
 * dit is één query voor alle typen samen, en de uitkomst wordt per request
 * onthouden (de FAQ-pagina vraagt het per categorie opnieuw).
 */
function sokkies_faq_soktype_ids() {
	static $ids = null;
	if ( null !== $ids ) {
		return $ids;
	}
	global $wpdb;
	$ids   = array();
	$rijen = $wpdb->get_col( $wpdb->prepare(
		"SELECT pm.meta_value
		   FROM {$wpdb->postmeta} pm
		   INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
		  WHERE pm.meta_key = %s
		    AND p.post_type = %s
		    AND p.post_status = %s",
		'faq_vragen',
		'sokkies_soktype',
		'publish'
	) );
	foreach ( $rijen as $rij ) {
		$lijst = maybe_unserialize( $rij );
		if ( ! is_array( $lijst ) ) {
			continue;
		}
		foreach ( $lijst as $id ) {
			$id = (int) $id;
			if ( $id ) {
				$ids[ $id ] = true;
			}
		}
	}
	$ids = array_keys( $ids );
	return $ids;
}

function sokkies_faq_antwoord( $vraag_id ) {
	return sokkies_rijke_tekst( get_field( 'antwoord', $vraag_id ) );
}

/**
 * Compacte wysiwyg-toolbar mét linkknop voor de FAQ-antwoorden
 * (teamfeedback: woorden in een antwoord moeten linkbaar zijn; de
 * output-whitelist in sokkies_faq_antwoord() staat <a> al toe).
 */
add_filter( 'acf/fields/wysiwyg/toolbars', function ( $toolbars ) {
	$toolbars['Sokkies eenvoudig'] = array( 1 => array( 'bold', 'italic', 'link', 'unlink', 'bullist', 'numlist', 'undo', 'redo' ) );
	return $toolbars;
} );

/**
 * Hoofdmenu-items voor de header.
 *
 * Bron = de repeater 'hoofdmenu' op de opties-pagina Website-instellingen.
 * Zolang die leeg is (of ACF niet actief), valt het menu terug op de
 * statische opbouw uit htmlv — zelfde regel als bij de secties.
 *
 * Elke rij levert: label, url, mega (bool), alleen_mobiel (bool) en
 * actief (bool). "Actief" wordt zelf bepaald: de gekoppelde pagina, plus
 * de eventuele extra pagina's uit 'actief_bij' (zo blijft bijv. Inspiratie
 * oplichten op toepassingen/reviews-en-cases/downloads).
 */
function sokkies_hoofdmenu() {
	$rijen = function_exists( 'get_field' ) ? get_field( 'hoofdmenu', 'option' ) : null;

	if ( empty( $rijen ) || ! is_array( $rijen ) ) {
		// Fallback = de statische nav uit htmlv, 1:1.
		return array(
			array( 'label' => 'Home',            'url' => home_url( '/' ),               'mega' => false, 'alleen_mobiel' => true,  'actief' => is_front_page() ),
			array( 'label' => 'Sokkencollectie', 'url' => home_url( '/collectie/' ),     'mega' => true,  'alleen_mobiel' => false, 'actief' => is_page( 'collectie' ) || is_singular( 'sokkies_soktype' ) ),
			array( 'label' => 'Configurator',    'url' => home_url( '/configurator/' ),  'mega' => false, 'alleen_mobiel' => false, 'actief' => is_page( 'configurator' ) ),
			array( 'label' => 'Inspiratie',      'url' => '#',                           'mega' => false, 'alleen_mobiel' => false, 'actief' => is_page( array( 'toepassingen', 'reviews-en-cases', 'downloads', 'blogs' ) ) || is_singular( 'sokkies_blog' ) ),
			array( 'label' => 'Werkwijze',       'url' => home_url( '/werkwijze/' ),     'mega' => false, 'alleen_mobiel' => false, 'actief' => is_page( 'werkwijze' ) ),
			array( 'label' => 'Over ons',        'url' => home_url( '/over-ons/' ),      'mega' => false, 'alleen_mobiel' => false, 'actief' => is_page( 'over-ons' ) ),
			array( 'label' => 'Contact',         'url' => home_url( '/contact/' ),       'mega' => false, 'alleen_mobiel' => false, 'actief' => is_page( 'contact' ) ),
		);
	}

	$huidig = ( is_page() || is_singular() ) ? get_queried_object_id() : 0;

	// Een blogartikel hoort bij het blogoverzicht. Zonder dit licht er op een
	// artikel géén menu-item op, want 'actief_bij' wijst naar pagina's en elk
	// los artikel daarin opnemen is ondoenlijk.
	if ( is_singular( 'sokkies_blog' ) ) {
		$overzicht = get_page_by_path( 'blogs' );
		if ( $overzicht ) {
			$huidig = $overzicht->ID;
		}
	}

		// Zelfde verhaal voor een productpagina: die hoort bij Sokkencollectie.
		// Zonder dit licht er op /collectie/{soktype}/ geen enkel menu-item op,
		// terwijl het ontwerp daar juist het onderstreepte item toont.
		if ( is_singular( 'sokkies_soktype' ) ) {
			$overzicht = get_page_by_path( 'collectie' );
			if ( $overzicht ) {
				$huidig = $overzicht->ID;
			}
		}

	$items  = array();

	foreach ( $rijen as $rij ) {
		$link  = isset( $rij['link'] ) ? $rij['link'] : array();
		$url   = is_array( $link ) && ! empty( $link['url'] ) ? $link['url'] : '';
		$label = trim( (string) ( isset( $rij['label'] ) ? $rij['label'] : '' ) );
		if ( '' === $label && is_array( $link ) && ! empty( $link['title'] ) ) {
			$label = $link['title'];
		}
		if ( '' === $label ) {
			continue; // lege rij overslaan
		}

		// Actief: de pagina waar de link heen wijst, of een van de extra's.
		$actief = false;
		if ( $huidig ) {
			$doel = $url ? url_to_postid( $url ) : 0;
			if ( $doel && $doel === $huidig ) {
				$actief = true;
			}
			foreach ( (array) ( isset( $rij['actief_bij'] ) ? $rij['actief_bij'] : array() ) as $extra ) {
				$extra_id = is_object( $extra ) ? $extra->ID : (int) $extra;
				if ( $extra_id === $huidig ) {
					$actief = true;
				}
			}
		} elseif ( is_front_page() && $url && untrailingslashit( $url ) === untrailingslashit( home_url( '/' ) ) ) {
			$actief = true;
		}

		$items[] = array(
			'label'         => $label,
			'url'           => $url ? $url : '#',
			'target'        => is_array( $link ) && ! empty( $link['target'] ) ? $link['target'] : '',
			'mega'          => ! empty( $rij['mega'] ),
			'alleen_mobiel' => ! empty( $rij['alleen_mobiel'] ),
			'actief'        => $actief,
		);
	}

	return $items;
}

/**
 * Label van de primaire CTA — één bron voor de hele site.
 *
 * Verzoek Kulwant 2026-08-25: overal dezelfde tekst "Gratis ontwerp
 * aanvragen" naar /offerte/. Daarvoor stonden er drie varianten door elkaar
 * ("Gratis proefdesign", "Gratis ontwerp binnen 24 uur" en "Vraag gratis
 * proefdesign aan"). BEWUST ZONDER "binnen 24 uur": die belofte staat al in
 * de topbalk, in de USP-regel en in de subregel onder de voettekst-CTA. De
 * knop noemt de handeling, de tekst eromheen de belofte.
 *
 * Dit is de STANDAARD. Een link die in de CMS een eigen titel heeft gekregen
 * wint hier nog steeds van — die staat in de database en verhuist niet mee
 * met een deploy.
 */
function sokkies_cta_label() {
	return 'Gratis ontwerp aanvragen';
}

/**
 * Label voor een primaire CTA, met de oude varianten opgeruimd.
 *
 * De vijf plekken uit het verzoek (header, hero, procesblok, onder de
 * calculator, voettekst-CTA) hebben allemaal een eigen linktitel IN DE
 * DATABASE staan. Die wint van de standaard hierboven en verhuist niet mee
 * met een deploy, dus alleen de standaard aanpassen liet op live nog steeds
 * "Gratis proefdesign" en "Vraag gratis proefdesign aan" zien.
 *
 * Daarom worden de bekende OUDE teksten hier omgezet naar de nieuwe. Een
 * zelfgekozen, afwijkende titel blijft gewoon staan — er wordt alleen
 * opgeruimd wat we willen vervangen. En alleen op links die naar de
 * offertepagina wijzen, zodat een knop met dezelfde tekst naar een andere
 * bestemming ongemoeid blijft.
 *
 * Wie dit liever in het CMS zelf rechtzet: leeg het titelveld, dan pakt de
 * knop automatisch sokkies_cta_label().
 */
function sokkies_cta_tekst( $titel, $url = '', $terugval = null ) {
	$titel = trim( (string) $titel );
	if ( '' === $titel ) {
		// Geen titel ingevuld: de sectie-eigen terugval als die er is,
		// anders het CTA-label. Zo houdt 'Bekijk collectie' zijn eigen tekst.
		return null === $terugval ? sokkies_cta_label() : $terugval;
	}
	// Alleen normaliseren op de offertepagina.
	if ( '' !== $url && false === strpos( (string) $url, '/offerte' ) ) {
		return $titel;
	}
	$oud = array(
		'gratis proefdesign',
		'gratis ontwerp binnen 24 uur',
		'vraag gratis proefdesign aan',
		'proefdesign aanvragen',
		'gratis proefdesign aanvragen',
	);
	return in_array( strtolower( $titel ), $oud, true ) ? sokkies_cta_label() : $titel;
}

/**
 * De gele knop rechts in de headerbalk.
 *
 * In htmlv is dit op alle 21 pagina's een <button class="cta"> ZONDER
 * link — een stub, net als "Bekijk collectie" in de mega was. Elders in
 * dezelfde build staat dezelfde tekst wél als <a href="offerte.html">,
 * dus dat is de bedoelde bestemming en tevens de fallback hier.
 *
 * Geeft array(label, url, target) of null wanneer de knop uit staat.
 */
function sokkies_header_cta() {
	$tonen = function_exists( 'get_field' ) ? get_field( 'cta_tonen', 'option' ) : null;
	if ( false === $tonen ) {
		return null;
	}

	$link  = function_exists( 'get_field' ) ? get_field( 'cta_link', 'option' ) : null;
	$label = trim( (string) sokkies_optie( 'cta_label', '' ) );

	$url = is_array( $link ) && ! empty( $link['url'] ) ? $link['url'] : home_url( '/offerte/' );

	if ( '' === $label && is_array( $link ) && ! empty( $link['title'] ) ) {
		$label = $link['title'];
	}
	// Leeg -> de standaard; een oude variant -> ook de standaard; een eigen
	// tekst blijft staan. Zie sokkies_cta_tekst().
	$label = sokkies_cta_tekst( $label, $url );

	return array(
		'label'  => $label,
		'url'    => $url,
		'target' => is_array( $link ) && ! empty( $link['target'] ) ? $link['target'] : '',
	);
}

/**
 * Footermenu — de linklijst onder de kop "Sokkies", verdeeld over de twee
 * kolommen van .footer-links-cols.
 *
 * Bron = de repeater 'footermenu' op Website-instellingen; leeg = de
 * statische lijst uit htmlv, 1:1 (zelfde fallbackregel als de secties en
 * het hoofdmenu). Geeft array( 1 => [...], 2 => [...] ) terug; alleen
 * kolommen met items worden gerenderd.
 */
function sokkies_footermenu() {
	$rijen = function_exists( 'get_field' ) ? get_field( 'footermenu', 'option' ) : null;

	if ( empty( $rijen ) || ! is_array( $rijen ) ) {
		return array(
			1 => array(
				array( 'label' => 'Sokkencollectie', 'url' => home_url( '/collectie/' ),    'target' => '' ),
				array( 'label' => 'Configurator',    'url' => home_url( '/configurator/' ), 'target' => '' ),
				array( 'label' => 'Inspiratie',      'url' => '#',                          'target' => '' ),
				array( 'label' => 'Werkwijze',       'url' => home_url( '/werkwijze/' ),    'target' => '' ),
				array( 'label' => 'Over ons',        'url' => home_url( '/over-ons/' ),     'target' => '' ),
			),
			2 => array(
				array( 'label' => 'Contact',                'url' => home_url( '/contact/' ),              'target' => '' ),
				array( 'label' => 'Downloads & templates',  'url' => home_url( '/downloads/' ),            'target' => '' ),
				array( 'label' => 'Veelgestelde vragen',    'url' => home_url( '/veelgestelde-vragen/' ),  'target' => '' ),
				array( 'label' => 'Projecten',              'url' => '#',                                  'target' => '' ),
				array( 'label' => 'Blogs',                  'url' => home_url( '/blogs/' ),                'target' => '' ),
				array( 'label' => 'Sokkies geeft terug',    'url' => home_url( '/sokkies-geeft-terug/' ), 'target' => '' ),
			),
		);
	}

	$kolommen = array( 1 => array(), 2 => array() );
	$taal_nu  = sokkies_huidige_taal();

	foreach ( $rijen as $rij ) {
		$link  = isset( $rij['link'] ) ? $rij['link'] : array();
		$label = trim( (string) ( isset( $rij['label'] ) ? $rij['label'] : '' ) );
		if ( '' === $label && is_array( $link ) && ! empty( $link['title'] ) ) {
			$label = $link['title'];
		}
		if ( '' === $label ) {
			continue; // lege rij overslaan
		}

		/* TAALFILTER PER LINK (2026-09-30, verzoek via Rick: het Impressum is
		   een Duitse wettelijke plicht en hoort alleen in de Duitse footer).
		   Niets aangevinkt = in ALLE talen, dus bestaande rijen veranderen
		   niet; pas als er talen zijn aangevinkt verschijnt de link daar
		   alleen. Exact hetzelfde begrip als bij de merklogo's
		   (sokkies_logos_voor_taal), zodat er maar één regel te onthouden is.
		   DE PAGINA ZELF BLIJFT BEREIKBAAR in elke taal - dit verbergt alleen
		   de link, niet de URL. */
		$talen = isset( $rij['talen'] ) ? (array) $rij['talen'] : array();
		if ( ! sokkies_taal_past( $talen ) ) {
			continue;
		}
		$kolom = ( isset( $rij['kolom'] ) && '2' === (string) $rij['kolom'] ) ? 2 : 1;

		$kolommen[ $kolom ][] = array(
			'label'  => $label,
			'url'    => is_array( $link ) && ! empty( $link['url'] ) ? $link['url'] : '#',
			'target' => is_array( $link ) && ! empty( $link['target'] ) ? $link['target'] : '',
		);
	}

	return $kolommen;
}

/**
 * Contactformulier (Gravity Forms) in de opmaak van het ontwerp.
 *
 * BELANGRIJK — bewust GEEN hardgecodeerd formulier-ID meer. Gravity Forms
 * gooit bij een import het geëxporteerde ID weg en deelt een vers
 * auto-increment uit (GFAPI::add_form -> RGFormsModel::insert_form,
 * gravityforms/includes/api.php:487-493) en maakt de titel zo nodig uniek.
 * Het formulier heet lokaal 4, maar krijgt op live vrijwel zeker een ander
 * nummer. Met een hardgecodeerde 4 rendert GF dan een publiek zichtbare
 * "formulier niet gevonden"-melding — bij ajax=true zelfs een compleet
 * genest <!DOCTYPE html>-document midden op de pagina.
 *
 * Daarom zoeken we het formulier op titel. Vastzetten kan met de constante
 * SOKKIES_CONTACT_FORM_ID (wp-config.php) of de optie
 * 'sokkies_contact_form_id'; die winnen allebei van de titelzoektocht.
 */
function sokkies_contactformulier_titel() {
	return 'Contact — website';
}

/**
 * Het ID van het contactformulier, of 0 als het er niet is.
 */
function sokkies_contactformulier_id() {
	static $id = null;
	if ( null !== $id ) {
		return $id;
	}
	if ( defined( 'SOKKIES_CONTACT_FORM_ID' ) ) {
		$id = (int) SOKKIES_CONTACT_FORM_ID;
		return $id;
	}
	$vast = (int) get_option( 'sokkies_contact_form_id' );
	if ( $vast ) {
		$id = $vast;
		return $id;
	}
	$id = 0;
	if ( class_exists( 'GFAPI' ) ) {
		foreach ( (array) GFAPI::get_forms() as $formulier ) {
			if ( isset( $formulier['title'] ) && sokkies_contactformulier_titel() === $formulier['title'] ) {
				$id = (int) $formulier['id'];
				break;
			}
		}
	}
	return $id;
}

/**
 * Is dit formulier het contactformulier?
 */
function sokkies_is_contactformulier( $form ) {
	$id = sokkies_contactformulier_id();
	return $id && ! empty( $form['id'] ) && (int) $form['id'] === $id;
}

/**
 * De formuliervoet omgebouwd naar .ct-form-foot uit contact.html: de
 * juridische regel links, de knoppen rechts, op één rij.
 *
 * Twee dingen die GF anders doet dan het ontwerp:
 * 1. htmlv heeft naast de verzendknop een tweede, lichte knop ("Liever een
 *    aanvraag?") naar de offertepagina; GF rendert alleen zijn eigen knop.
 * 2. GF zet de juridische regel als HTML-veld bovenin het veldenraster,
 *    waardoor die over de volle breedte staat en de knoppen eronder komen.
 *    We halen de inhoud van dat veld hier op en zetten hem naast de knoppen;
 *    het veld zelf is in style.css verborgen. Zo blijft er één bron: het
 *    HTML-veld in Gravity Forms, dat de klant gewoon kan aanpassen.
 */
add_filter( 'gform_submit_button', function ( $button, $form ) {
	if ( ! sokkies_is_contactformulier( $form ) ) {
		return $button;
	}

	$alt = '<a href="' . esc_url( home_url( '/offerte/' ) ) . '" class="ct-alt-btn">'
	     . '<svg xmlns="http://www.w3.org/2000/svg" width="12.199" height="9.39" viewBox="0 0 12.199 9.39">'
	     . '<g transform="translate(0.5 0.683)">'
	     . '<path d="M1289.087,543v4h11" transform="translate(-1289.087 -542.997)" fill="none" stroke="#28121b" stroke-linecap="round" stroke-width="1"/>'
	     . '<path d="M1216,541.6c.392.226,4,4,4,4l-4,4" transform="translate(-1209 -541.602)" fill="none" stroke="#28121b" stroke-linecap="round" stroke-width="1"/>'
	     . '</g></svg> Liever een aanvraag?</a>';

	// GF's eigen knop krijgt de ontwerp-class mee in plaats van gform_button.
	$button = str_replace( 'gform_button', 'gform_button ct-submit', $button );

	$juridisch = '';
	foreach ( (array) $form['fields'] as $veld ) {
		if ( 'html' === $veld->type && ! empty( $veld->content ) ) {
			$juridisch = '<p class="ct-form-legal">' . $veld->content . '</p>';
			break;
		}
	}

	return $juridisch . '<div class="ct-form-actions">' . $alt . $button . '</div>';
}, 10, 2 );

/**
 * Het contactformulier op GF's legacy-thema.
 *
 * Dan zet GF de gform-theme--framework/orbital classes niet op de wrapper en
 * vervallen die opmaakregels in één keer — dat is wat de blauwe knop, de
 * 500/14px-labels en de 288px-textarea van "orbital" wegneemt. Een
 * wp_dequeue_style op die handles werkte hier niet (GF zet ze later in de
 * wachtrij) en is daarom bewust weer verwijderd: die haak stond site-breed
 * aan en zou elk toekomstig formulier onopgemaakt laten.
 */
add_filter( 'gform_form_theme_slug', function ( $slug, $form ) {
	// Ook het offerte- en sampleformulier: dezelfde reden, de eigen opmaak
	// wint dan.
	$eigen = sokkies_is_contactformulier( $form )
		|| ( function_exists( 'sokkies_is_offerte' ) && sokkies_is_offerte( $form ) )
		|| ( function_exists( 'sokkies_is_sample' ) && sokkies_is_sample( $form ) );
	return $eigen ? 'legacy' : $slug;
}, 10, 2 );

/**
 * Velden die de bezoeker niet ziet, horen ook niet in de notificatiemail.
 *
 * Het landveld ("Country", veld 10) staat wel op sokkies.com maar niet in het
 * ontwerp. Het blijft in het formulier staan omdat de veldnamen 1:1 gelijk
 * moeten blijven aan productie — input_10 wordt dus nog gewoon verzonden en
 * opgeslagen bij de inzending, en blijft beschikbaar voor het systeem dat de
 * data later ophaalt. Alleen in de mail was het zichtbaar, met de placeholder
 * "Select country" als waarde (melding Kulwant 2026-08-25, met screenshot).
 *
 * De markering is dezelfde als die het veld op de pagina verbergt: de
 * cssClass 'language' (zie .ct-form-card .gfield.language in style.css). Zo is
 * er één begrip — "language-velden zijn verborgen voor de bezoeker én voor de
 * mail" — in plaats van een los veld-ID op twee plekken.
 *
 * BEWUST GEEN {all_fields:exclude[10]} in de notificatie: die modifier bestaat
 * niet in GF 3.0 (common.php:1417-1422 kent alleen value/empty/admin), en het
 * zou bovendien een databasewijziging zijn die niet meedeployt. Via
 * gform_merge_tag_filter kan het in code: false teruggeven laat GF het veld
 * overslaan (common.php:1941-1943).
 */
function sokkies_veld_verborgen_in_mail( $veld ) {
	return ! empty( $veld->cssClass ) && preg_match( '/(^|\s)language(\s|$)/', $veld->cssClass );
}

add_filter( 'gform_merge_tag_filter', function ( $waarde, $merge_tag, $opties, $veld, $ruwe_waarde, $format ) {
	if ( 0 !== strpos( (string) $merge_tag, 'all_fields' ) || ! is_object( $veld ) ) {
		return $waarde;
	}
	if ( (int) rgobj( $veld, 'formId' ) !== sokkies_contactformulier_id() ) {
		return $waarde;
	}
	// false = GF slaat dit veld over in {all_fields}.
	return sokkies_veld_verborgen_in_mail( $veld ) ? false : $waarde;
}, 10, 6 );

/* -------------------------------------------------------------------------
 * Gravity Forms — Nederlandse meldingen op de front-end
 * -------------------------------------------------------------------------
 * De site draait op locale en_US en Gravity Forms is een commerciële plugin:
 * er komt dus géén nl_NL-taalpakket binnen via WordPress.org (de plugin
 * levert alleen een .pot, zie gravityforms/languages/). Alle meldingen lopen
 * wel netjes door __()/esc_html__() met textdomain 'gravityforms', dus we
 * vangen ze hier af in plaats van de site-locale om te gooien — dat laatste
 * zou het hele admin- en themagedrag raken.
 *
 * De formuleringen komen één-op-één van de huidige productiesite
 * (sokkies.com/nl/contact/), zodat de teksten identiek blijven.
 * Alleen front-end; de GF-beheerschermen laten we met rust.
 */
function sokkies_gf_nl_meldingen() {
	return array(
		// Samenvatting bovenaan het formulier. GF plakt deze twee aan elkaar:
		// "Er was een probleem met je inzending. Controleer de onderstaande velden."
		'There was a problem with your submission.' => 'Er was een probleem met je inzending.',
		'Please review the fields below.'           => 'Controleer de onderstaande velden.',
		'Your form was not submitted. Please try again in a few minutes.' => 'Je formulier is niet verzonden. Probeer het over een paar minuten opnieuw.',

		// Per veld.
		'This field is required.'                   => 'Dit veld is vereist.',
		'(Required)'                                => '(Verplicht)',
		'The email address entered is invalid.'     => 'Het ingevoerde e-mailadres is ongeldig.',
		'The email address entered is invalid, please check the formatting (e.g. email@domain.com).' => 'Het ingevoerde e-mailadres is ongeldig. Controleer de schrijfwijze (bijv. naam@domein.nl).',
		'Please enter a valid email address.'       => 'Voer een geldig e-mailadres in.',
		'Your emails do not match.'                 => 'De e-mailadressen komen niet overeen.',
		'Please enter a valid phone number.'        => 'Voer een geldig telefoonnummer in.',
		'Please enter a valid phone number in the correct format.' => 'Voer een geldig telefoonnummer in de juiste notatie in.',
		'The text entered exceeds the maximum number of characters.' => 'De ingevoerde tekst is langer dan het maximale aantal tekens.',

		// Ingebouwde standaardbevestiging van GF (vangnet; formulier 4 heeft
		// een eigen Nederlandse bevestiging, zie GF-instellingen).
		'Thanks for contacting us! We will get in touch with you shortly.' => 'Bedankt voor je bericht! We nemen zo snel mogelijk contact met je op.',

		// Uploadveld. De teksten volgen htmlv/offerte.html: 'Sleep uw bestanden
		// hierheen, of klik om te uploaden.' met daaronder de toegestane types.
		'Drop files here or'      => 'Sleep uw bestanden hierheen, of',
		'Select files'            => 'klik',
		'Accepted file types: %s'  => '%s',
		'Accepted file types: %s.' => '%s',
		'Max. file size: %s'       => 'max. %s per bestand',
		'Max. files: %s'           => 'maximaal %s bestanden',

		// Getalvelden (o.a. 'Aantal paar' op het offerteformulier).
		'Please enter a number greater than or equal to %s.' => 'Vul een aantal in van minimaal %s.',
		'Please enter a number less than or equal to %s.'    => 'Vul een aantal in van maximaal %s.',
		'Please enter a number from %1$s to %2$s.'          => 'Vul een aantal in tussen %1$s en %2$s.',
		'Please enter a valid number'                       => 'Vul een geldig getal in',

		// Keuzevelden (radio/select).
		'Invalid selection. Please select from the available choices.' => 'Ongeldige keuze. Maak een keuze uit de beschikbare opties.',
		'Invalid selection.'                        => 'Ongeldige keuze.',

		// Formulier niet beschikbaar / gesloten.
		'Sorry. This form is no longer accepting new submissions.' => 'Dit formulier accepteert geen nieuwe inzendingen meer.',
		'Oops! We could not locate your form.'      => 'Er ging iets mis: we konden het formulier niet vinden.',
	);
}

/* De kaart hangt aan de TAAL van de pagina: Nederlands krijgt de kaart
   hierboven, Duits en Frans hun eigen (inc/formulier-talen.php) en Engels
   geen enkele — Gravity Forms is zelf Engels, dus daar is vertalen juist
   het probleem. De taal wordt één keer per verzoek bepaald: dit filter
   vuurt honderden keren per pagina. */
function sokkies_gf_meldingkaart() {
	static $kaart = null;
	if ( null === $kaart ) {
		$taal  = function_exists( 'sokkies_form_taal' ) ? sokkies_form_taal() : 'nl';
		$kaart = ( 'nl' === $taal ) ? sokkies_gf_nl_meldingen() : sokkies_form_meldingen( $taal );
	}

	return $kaart;
}

add_filter( 'gettext', function ( $vertaald, $origineel, $domein ) {
	if ( 'gravityforms' !== $domein || is_admin() ) {
		return $vertaald;
	}
	$map = sokkies_gf_meldingkaart();
	return isset( $map[ $origineel ] ) ? $map[ $origineel ] : $vertaald;
}, 10, 3 );

// Sommige GF-strings lopen via _x() en komen dus op dit filter binnen.
add_filter( 'gettext_with_context', function ( $vertaald, $origineel, $context, $domein ) {
	if ( 'gravityforms' !== $domein || is_admin() ) {
		return $vertaald;
	}
	$map = sokkies_gf_meldingkaart();
	return isset( $map[ $origineel ] ) ? $map[ $origineel ] : $vertaald;
}, 10, 4 );

/**
 * Minimale funnelkop: logo + "Naar de collectie" + globe, zonder menu,
 * zoekicoon, account en CTA-knop.
 *
 * Het XD toont die kop op de funnelpagina's. Dat is op 2026-07-28 bewust
 * uitgesteld ("voorlopig zo laten") en op 2026-09-02 alsnog gevraagd voor de
 * offertepagina.
 *
 * Bewust op de SLUG en niet op een CMS-veld zoals footer_variant: een
 * veldwaarde staat in de database en die deployt niet mee, dus live zou de
 * volledige kop houden tot iemand het daar aanzet. Naast de offertepagina
 * staan nu ook de drie bedankpagina-s in de lijst: die horen bij dezelfde
 * trechter en tonen in het XD dezelfde kop. SAMPLE-REQUEST staat er nog
 * NIET bij — dat is een formulierpagina en is niet gevraagd; een slug
 * toevoegen (of de filter gebruiken) is genoeg. Contact heeft wel de
 * mini-FOOTER maar houdt het volledige menu, dus meeliften op
 * footer_variant kan niet.
 */
function sokkies_mini_header() {
	$paginas = apply_filters(
		'sokkies_mini_header_paginas',
		array( 'offerte', 'bedankt', 'bedankt-contact', 'bedankt-sample' )
	);
	return is_page( $paginas );
}

/**
 * Landingsheader: logo, telefoonnummer en de gele knop — geen menu.
 *
 * Per pagina te kiezen via het veld "Header" (pagina-opties), zodat elke
 * volgende landingspagina dezelfde kop krijgt zonder codewijziging. De
 * offertepagina houdt haar eigen mini-header (sokkies_mini_header).
 */
function sokkies_landing_header() {
	if ( ! function_exists( 'get_field' ) || ! is_singular() ) {
		return false;
	}
	return 'landing' === get_field( 'header_variant' );
}

/**
 * Telefoonvelden accepteren geen letters meer.
 *
 * De drie formulieren gebruiken een telefoonveld met formaat "international",
 * en dat valideert Gravity Forms NIET: in class-gf-field-phone.php draait de
 * regex-controle op $phone_format['regex'], en het internationale formaat
 * heeft geen regex. Alles werd dus geaccepteerd, inclusief "sdfsdfsdf5425".
 *
 * BEWUST GEEN CIJFERS-ALLEEN: het veld is internationaal en het eigen nummer
 * van Sokkies staat overal als +31 (0)413 410 411. Plus, spaties, streepjes,
 * haakjes, punt en schuine streep blijven daarom toegestaan; letters en de
 * rest niet, en er moet minstens één cijfer in staan. Wil je het strikter
 * (echt alleen 0-9), dan is dat één regex hieronder.
 *
 * In code en niet als formulierinstelling: instellingen staan in de database
 * en die deployt niet mee.
 */
function sokkies_eigen_gf_formulier( $form_of_id ) {
	$id = is_array( $form_of_id ) ? (int) rgar( $form_of_id, 'id' ) : (int) $form_of_id;
	if ( ! $id ) {
		return false;
	}
	$ids = array();
	if ( function_exists( 'sokkies_contactformulier_id' ) ) {
		$ids[] = sokkies_contactformulier_id();
	}
	if ( function_exists( 'sokkies_offerte_form_id' ) ) {
		$ids[] = sokkies_offerte_form_id();
	}
	if ( function_exists( 'sokkies_sample_form_id' ) ) {
		$ids[] = sokkies_sample_form_id();
	}
	return in_array( $id, array_filter( $ids ), true );
}

function sokkies_telefoon_validatie( $result, $value, $form, $field ) {
	if ( ! $field || 'phone' !== $field->type || ! sokkies_eigen_gf_formulier( $form ) ) {
		return $result;
	}
	$waarde = trim( (string) $value );
	if ( '' === $waarde ) {
		return $result; // leeg afhandelen blijft aan het verplicht-vinkje
	}
	$toegestaan = preg_match( '#^[0-9+()/.\s-]+$#', $waarde );
	$heeft_cijfer = preg_match( '#[0-9]#', $waarde );
	if ( ! $toegestaan || ! $heeft_cijfer ) {
		$result['is_valid'] = false;
		$result['message']  = 'Vul een geldig telefoonnummer in; letters zijn niet toegestaan.';
	}
	return $result;
}
add_filter( 'gform_field_validation', 'sokkies_telefoon_validatie', 10, 4 );

/**
 * Naamvelden accepteren geen cijfers meer.
 *
 * "dfgdfg4564564" en "456456456" kwamen er gewoon door: het zijn gewone
 * tekstvelden en Gravity Forms controleert daar niets op.
 *
 * WELKE VELDEN: Voornaam, Achternaam en Contactpersoon. BEWUST NIET
 * Bedrijfsnaam — een bedrijf mag cijfers in zijn naam hebben (Bouwbedrijf
 * 2000) — en ook niet Straat/Plaats/Postcode/Huisnummer, die hebben cijfers
 * juist nodig.
 *
 * TOEGESTAAN: letters (ook accenten, want Ümit en Renée moeten kunnen),
 * spatie, koppelteken, apostrof en punt: Anne-Marie, O'Brien, J. van Dijk.
 * Cijfers en overige tekens niet, en er moet minstens één letter in staan.
 *
 * Herkenning op LABEL (met een filter om aan te passen) plus de cssClass
 * of-contact van de funnelformulieren. Wordt een label in het CMS hernoemd,
 * dan vervalt de controle voor dat veld — vandaar het filter.
 */
function sokkies_is_naamveld( $field ) {
	if ( ! $field || 'text' !== $field->type ) {
		return false;
	}
	$labels = apply_filters( 'sokkies_naamvelden', array( 'voornaam', 'achternaam', 'contactpersoon' ) );
	$label  = strtolower( trim( wp_strip_all_tags( (string) $field->label ) ) );
	if ( in_array( $label, $labels, true ) ) {
		return true;
	}
	return false !== strpos( (string) $field->cssClass, 'of-contact' );
}

function sokkies_naam_validatie( $result, $value, $form, $field ) {
	if ( ! sokkies_eigen_gf_formulier( $form ) || ! sokkies_is_naamveld( $field ) ) {
		return $result;
	}
	$waarde = trim( (string) $value );
	if ( '' === $waarde ) {
		return $result; // leeg blijft aan het verplicht-vinkje
	}
	$toegestaan  = preg_match( "#^[\p{L}\p{M}\s.'’-]+$#u", $waarde );
	$heeft_letter = preg_match( '#\p{L}#u', $waarde );
	if ( ! $toegestaan || ! $heeft_letter ) {
		$result['is_valid'] = false;
		$result['message']  = 'Vul een geldige naam in; cijfers zijn niet toegestaan.';
	}
	return $result;
}
add_filter( 'gform_field_validation', 'sokkies_naam_validatie', 10, 4 );

/** Haakje voor de JS-kant: markeert de naamvelden in de HTML. */
function sokkies_naam_veld_class( $classes, $field, $form ) {
	if ( sokkies_eigen_gf_formulier( $form ) && sokkies_is_naamveld( $field ) ) {
		$classes .= ' sokkies-naamveld';
	}
	return $classes;
}
add_filter( 'gform_field_css_class', 'sokkies_naam_veld_class', 10, 3 );

/**
 * ===== Zoeken =====
 *
 * Dit is de TWEEDE opzet. De eerste is op 2026-08-24 teruggedraaid met
 * "werkt niet goed"; wat er precies aan mankeerde is toen niet vastgelegd,
 * maar nagemeten op de huidige database is het duidelijk: zoeken op
 * "sokken" gaf 51 treffers — vrijwel elke pagina van de site — op
 * datumvolgorde en zonder te laten zien WAAROM iets matchte. Dat is geen
 * zoekresultaat maar een inhoudsopgave.
 *
 * Drie dingen zijn daarom anders:
 *
 * 1. VOLGORDE OP RELEVANTIE. Een treffer in de titel komt boven een
 *    treffer ergens in een veld, en een concreet ding (soktype, case,
 *    blog) boven een algemene pagina. Dat is wat "sokken" bruikbaar
 *    maakt: de sokken staan bovenaan in plaats van de homepage.
 * 2. RUIS ERUIT. De sectievelden bevatten ook bestands-ID's, URL's,
 *    kleurcodes en geserialiseerde arrays. Daar zoeken levert treffers op
 *    die de bezoeker niet kan zien staan, dus die waarden vallen af.
 * 3. FRAGMENT BIJ HET RESULTAAT. Bij een treffer buiten de titel wordt
 *    het stukje tekst getoond waar het woord in stond, zodat zichtbaar is
 *    waarom het resultaat er staat.
 *
 * WAT er doorzocht wordt: alleen types met een eigen klikbare pagina —
 * pagina's, soktypes (/collectie/{slug}/), cases (/reviews-en-cases/{slug}/) en
 * blogs (/blog/{slug}/). FAQ-vragen, reviews en merklogo's zijn
 * hulp-CPT's zonder permalink; een treffer daarop zou nergens heen leiden.
 *
 * WAAR gezocht wordt: naast de titel ook in de postmeta, want de pagina's
 * zijn opgebouwd met de ACF-sectiebuilder en post_content is dus leeg —
 * standaard WordPress-zoeken vindt daar alleen titels.
 */

function sokkies_zoek_actief( $query ) {
	return ! is_admin() && $query->is_main_query() && $query->is_search();
}

function sokkies_zoek_types( $query ) {
	if ( ! sokkies_zoek_actief( $query ) ) {
		return;
	}
	$query->set( 'post_type', array( 'page', 'sokkies_soktype', 'sokkies_case', 'sokkies_blog' ) );
	$query->set( 'posts_per_page', 12 );
}
add_action( 'pre_get_posts', 'sokkies_zoek_types' );

/**
 * De join naar de postmeta, met de ruis er meteen uit.
 *
 * - meta_key NOT LIKE '_%' : ACF's eigen verwijzingen naar veldsleutels.
 * - niet puur cijfers      : bestands- en post-ID's uit image-/relatievelden.
 * - geen a:/s:/O: aan het begin : geserialiseerde arrays (repeaters e.d.).
 * - geen http.../#kleurcode: URL's en hexwaarden.
 * - minstens 4 tekens      : losse letters en cijfers zeggen niets.
 */
function sokkies_zoek_join( $join, $query ) {
	global $wpdb;
	if ( ! sokkies_zoek_actief( $query ) ) {
		return $join;
	}
	$join .= " LEFT JOIN {$wpdb->postmeta} AS sokkies_zm"
		. " ON {$wpdb->posts}.ID = sokkies_zm.post_id"
		. " AND sokkies_zm.meta_key NOT LIKE '\_%'"
		. " AND sokkies_zm.meta_value NOT REGEXP '^[0-9]+$'"
		. " AND sokkies_zm.meta_value NOT LIKE 'a:%'"
		. " AND sokkies_zm.meta_value NOT LIKE 's:%'"
		. " AND sokkies_zm.meta_value NOT LIKE 'O:%'"
		. " AND sokkies_zm.meta_value NOT LIKE 'http%'"
		. " AND sokkies_zm.meta_value NOT LIKE '#%'"
		. " AND CHAR_LENGTH(sokkies_zm.meta_value) > 3 ";
	return $join;
}
add_filter( 'posts_join', 'sokkies_zoek_join', 10, 2 );

/**
 * WordPress bouwt per zoekwoord een (post_title LIKE '…'); daar hangen we
 * de metawaarde naast. Via preg_replace i.p.v. een losse LIKE, zodat bij
 * meerdere woorden elk woord zijn eigen OR krijgt en de AND tussen de
 * woorden intact blijft.
 */
function sokkies_zoek_where( $where, $query ) {
	global $wpdb;
	if ( ! sokkies_zoek_actief( $query ) ) {
		return $where;
	}
	return preg_replace(
		"/\(\s*{$wpdb->posts}\.post_title\s+LIKE\s*(\'[^\']+\')\s*\)/",
		"({$wpdb->posts}.post_title LIKE $1) OR (sokkies_zm.meta_value LIKE $1)",
		$where
	);
}
add_filter( 'posts_where', 'sokkies_zoek_where', 10, 2 );

// De join levert een rij per metaveld; zonder DISTINCT komt een pagina net
// zo vaak terug als er velden matchen.
function sokkies_zoek_distinct( $distinct, $query ) {
	return sokkies_zoek_actief( $query ) ? 'DISTINCT' : $distinct;
}
add_filter( 'posts_distinct', 'sokkies_zoek_distinct', 10, 2 );

/**
 * Relevantie. Zonder dit staat alles op datum en komt bij een algemeen
 * woord de homepage boven het product dat je zocht.
 *
 * 1. titeltreffer eerst;
 * 2. dan op soort: soktype, case, blog, en pas daarna de algemene pagina's;
 * 3. binnen dezelfde groep de nieuwste eerst.
 */
function sokkies_zoek_orderby( $orderby, $query ) {
	global $wpdb;
	if ( ! sokkies_zoek_actief( $query ) ) {
		return $orderby;
	}
	$term = trim( (string) $query->get( 's' ) );
	if ( '' === $term ) {
		return $orderby;
	}
	$like = '%' . $wpdb->esc_like( $term ) . '%';

	return $wpdb->prepare(
		"({$wpdb->posts}.post_title LIKE %s) DESC,"
		. " FIELD({$wpdb->posts}.post_type,'sokkies_soktype','sokkies_case','sokkies_blog','page') ASC,"
		. " {$wpdb->posts}.post_date DESC",
		$like
	);
}
add_filter( 'posts_orderby', 'sokkies_zoek_orderby', 10, 2 );

/**
 * Het stukje tekst waarin het zoekwoord staat, voor onder het resultaat.
 *
 * Loopt de zichtbare metavelden af (zelfde ruisfilter als de join) en pakt
 * het eerste veld waar de term in staat. Geen treffer buiten de titel? Dan
 * een lege string — search.php valt dan terug op het normale fragment.
 */
function sokkies_zoek_fragment( $post_id, $term, $woorden = 30 ) {
	$term = trim( (string) $term );
	if ( '' === $term ) {
		return '';
	}
	$velden = get_post_meta( $post_id );
	if ( ! $velden ) {
		return '';
	}
	$titel = trim( wp_strip_all_tags( get_the_title( $post_id ) ) );
	$beste = '';

	foreach ( $velden as $sleutel => $waarden ) {
		if ( '_' === substr( $sleutel, 0, 1 ) ) {
			continue;
		}
		foreach ( (array) $waarden as $waarde ) {
			if ( ! is_string( $waarde ) || is_serialized( $waarde ) ) {
				continue;
			}
			$plat = trim( wp_strip_all_tags( $waarde ) );
			/* Korte velden zijn labels, knopteksten en namen: die leveren een
			   fragment op als "Kerstsokken", wat niets toevoegt naast de titel
			   die er al boven staat. Alleen echte lopende tekst dus. */
			if ( strlen( $plat ) < 40 || is_numeric( $plat ) || 0 === strpos( $plat, 'http' ) ) {
				continue;
			}
			if ( 0 === strcasecmp( $plat, $titel ) ) {
				continue;
			}
			if ( false === stripos( $plat, $term ) ) {
				continue;
			}
			// het langste veld geeft de meeste context
			if ( strlen( $plat ) > strlen( $beste ) ) {
				$beste = $plat;
			}
		}
	}
	if ( '' === $beste ) {
		return '';
	}

	// een stukje vóór de term meenemen zodat de zin loopt
	$pos   = stripos( $beste, $term );
	$start = max( 0, $pos - 60 );
	$stuk  = substr( $beste, $start );
	if ( $start > 0 ) {
		$stuk = '…' . ltrim( $stuk );
	}
	return wp_trim_words( $stuk, $woorden, '…' );
}

/**
 * De paginatitel van de zoekresultaten. WordPress draait hier op locale
 * en_US zonder Nederlands taalbestand, dus core maakt er "Search Results
 * for …" van op een verder Nederlandse site. Zelfde reden als
 * sokkies_datum_nl(): de sitetaal omzetten zou de hele beheeromgeving
 * meenemen, te grof voor één regel.
 */
function sokkies_zoek_titel( $delen ) {
	if ( is_search() ) {
		$term           = get_search_query();
		$delen['title'] = '' === trim( $term )
			? 'Zoeken'
			: sprintf( 'Zoeken naar &ldquo;%s&rdquo;', $term );
	}
	return $delen;
}
add_filter( 'document_title_parts', 'sokkies_zoek_titel' );

/**
 * De site is volledig Nederlands, maar draait op locale en_US (WPLANG leeg —
 * bewust zo gelaten, zie CLAUDE.md: omzetten raakt admin, thema en datums).
 * language_attributes() gaf daardoor <html lang="en-US"> terwijl htmlv overal
 * lang="nl" heeft. Gevolg: een browser hyphenateert Nederlandse tekst met het
 * ENGELSE woordenboek en vindt geen afbreekpunten, dus hyphens:auto deed niets
 * — zichtbaar op de PDP-toepassingskaarten, waar "Personeelsgeschenken" de
 * buurkaart in liep.
 *
 * Alleen het HTML-attribuut wordt gecorrigeerd, niet de locale: dit raakt geen
 * vertalingen, datums of het beheer. Staat een meertalig-plugin (TranslatePress
 * is gepland) de taal zelf te zetten, dan blijft die leidend.
 */
function sokkies_html_taal( $uitvoer ) {
	$inlogscherm = function_exists( 'is_login' ) ? is_login() : ( isset( $GLOBALS['pagenow'] ) && 'wp-login.php' === $GLOBALS['pagenow'] );
	if ( is_admin() || $inlogscherm || defined( 'TRP_PLUGIN_VERSION' ) || function_exists( 'pll_current_language' ) ) {
		return $uitvoer;
	}
	return preg_replace( '/lang="[^"]*"/', 'lang="nl"', $uitvoer, 1 );
}
add_filter( 'language_attributes', 'sokkies_html_taal' );

/**
 * Talen voor de globe-kiezer in de header.
 *
 * Leest de GEPUBLICEERDE talen uit TranslatePress en geeft per taal de URL van
 * de pagina waar de bezoeker nu staat. Zo blijft de kiezer vanzelf kloppen als
 * er later een taal bijkomt - er staat niets hardgecodeerd op NL/GB/DE/FR.
 *
 * Geeft een LEGE array terug zodra TranslatePress er niet is of er maar één
 * taal gepubliceerd staat. De header valt dan terug op de statische lijst uit
 * htmlv, zodat een omgeving zonder de plugin (de plugin zit niet in de repo,
 * dus dev heeft hem pas na een aparte installatie) gewoon blijft werken.
 *
 * De labels volgen het ontwerp: het VLAG-label is de regio (nl_NL -> NL,
 * en_GB -> GB), data-value blijft de taalcode (en) omdat de CSS en custom.js
 * daarop staan.
 */
function sokkies_talen() {
	if ( ! defined( 'TRP_PLUGIN_VERSION' ) || ! class_exists( 'TRP_Translate_Press' ) ) {
		return array();
	}

	$instellingen = get_option( 'trp_settings', array() );
	$gepubliceerd = isset( $instellingen['publish-languages'] ) ? (array) $instellingen['publish-languages'] : array();
	if ( count( $gepubliceerd ) < 2 ) {
		return array();
	}

	$trp  = TRP_Translate_Press::get_trp_instance();
	$urls = $trp ? $trp->get_component( 'url_converter' ) : null;
	if ( ! $urls ) {
		return array();
	}

	global $TRP_LANGUAGE;
	$talen = array();

	foreach ( $gepubliceerd as $code ) {
		$deel = explode( '_', $code );
		$taal = strtolower( $deel[0] );
		$vlag = strtoupper( isset( $deel[1] ) ? $deel[1] : $deel[0] );

		$talen[] = array(
			'code'     => $code,
			/* De SLUG en niet de taalcode: met nl_NL en nl_BE allebei op 'nl'
			   streepte custom.js (markSelected) ze allebei aan als huidige taal. */
			'waarde'   => isset( $instellingen['url-slugs'][ $code ] ) ? strtolower( $instellingen['url-slugs'][ $code ] ) : $taal,
			'vlag'     => $vlag,
			'hreflang' => str_replace( '_', '-', $code ),
			'url'      => $urls->get_url_for_language( $code ),
			'actief'   => ( $code === $TRP_LANGUAGE ),
		);
	}

	return $talen;
}

/**
 * De taalcode van de ACTIEVE taal, als korte waarde voor .lang[data-value].
 * Zonder TranslatePress blijft dat 'nl' - de taal waarin de site geschreven is.
 */
function sokkies_huidige_taal() {
	global $TRP_LANGUAGE;
	if ( ! $TRP_LANGUAGE ) {
		return 'nl';
	}
	$deel = explode( '_', $TRP_LANGUAGE );
	return strtolower( $deel[0] );
}

/**
 * DE TAAL ALS UNIEKE SLEUTEL, DUS MET REGIO.
 *
 * sokkies_huidige_taal() hierboven geeft de TAAL ('nl'), en dat is precies wat
 * je wilt voor dingen die taalkundig zijn: het decimaalteken, de veldlabels van
 * de formulieren, de landnamen. Vlaanderen schrijft Nederlands, dus daar hoort
 * Belgie gewoon 'nl' te zijn.
 *
 * Maar voor RICHTEN is dat te grof. Sinds nl_BE erbij staat (verzoek R4-4,
 * "Belgisch Nederlands als eigen taal, geen kopie van NL") viel Belgie samen
 * met Nederland: een footerlink of een merklogo kon niet op alleen Belgie
 * worden gezet, en in de taalkiezer kregen NL en BE allebei data-value "nl" -
 * waardoor custom.js ze allebei als de huidige taal aanstreepte.
 *
 * Deze functie geeft daarom de SLUG uit TranslatePress, die per taal uniek is:
 * nl, en, de, fr, nl_be. Zonder TranslatePress blijft het 'nl'.
 */
function sokkies_huidige_locale() {
	global $TRP_LANGUAGE;
	if ( ! $TRP_LANGUAGE ) {
		return 'nl';
	}

	$instellingen = get_option( 'trp_settings', array() );
	if ( ! empty( $instellingen['url-slugs'][ $TRP_LANGUAGE ] ) ) {
		return strtolower( $instellingen['url-slugs'][ $TRP_LANGUAGE ] );
	}

	return strtolower( str_replace( '-', '_', $TRP_LANGUAGE ) );
}

/**
 * Hoort de huidige taal bij de aangevinkte talen?
 *
 * Niets aangevinkt betekent overal tonen; dat is de bestaande afspraak en die
 * verandert niet.
 *
 * EEN BREDE KEUZE DEKT DE REGIOVARIANT. Staat er 'nl' aangevinkt, dan geldt
 * dat ook voor Belgie - anders zou elke bestaande footerlink en elk merklogo
 * dat op Nederlands staat op de Belgische site verdwijnen op het moment dat
 * nl_BE wordt aangezet. Wie iets ALLEEN in Belgie wil, vinkt 'nl_be' aan; dat
 * matcht dan niet op Nederland.
 */
function sokkies_taal_past( $gekozen ) {
	if ( ! is_array( $gekozen ) || ! $gekozen ) {
		return true;
	}

	$locale = sokkies_huidige_locale();
	$taal   = sokkies_huidige_taal();

	foreach ( $gekozen as $keuze ) {
		$keuze = strtolower( (string) $keuze );
		if ( $keuze === $locale ) {
			return true;
		}
		/* De brede keuze ('nl') dekt de regiovariant ('nl_be'), niet andersom. */
		if ( $keuze === $taal && 0 === strpos( $locale, $taal ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Het voorbeeldadres in de placeholder van elk e-mailveld.
 *
 * STAAT BEWUST IN CODE EN NIET IN TRANSLATEPRESS. Die kan deze string namelijk
 * structureel niet automatisch vertalen: skip_strings_that_cannot_be_auto_translated()
 * in de plugin weigert alles waar looks_like_email() waar op is, en een
 * machinale vertaling wordt voor zulke strings ook niet uitgeserveerd - alleen
 * een handmatig nagekeken vertaling (status 2) werkt. Dat betekende dat iemand
 * het op ELKE omgeving met de hand moest invullen; op dev bleef het daardoor
 * Nederlands terwijl het lokaal al goed stond.
 *
 * Zo reist het gewoon mee met een deploy en klopt het overal meteen.
 *
 * Onbekende taal valt terug op het Nederlandse adres.
 */
function sokkies_voorbeeld_email() {
	$adressen = array(
		'nl' => 'voorbeeld@domeinnaam.nl',
		'en' => 'example@domain.com',
		'de' => 'beispiel@domainname.de',
		'fr' => 'exemple@nomdedomaine.fr',
	);

	$taal = sokkies_huidige_taal();

	return isset( $adressen[ $taal ] ) ? $adressen[ $taal ] : $adressen['nl'];
}

/**
 * De introtekst van een pagina — de subtekst uit de paginakop.
 *
 * Gebruikt door de optiekaarten: op een kaart hoort dezelfde eenregelige
 * omschrijving als boven aan de pagina zelf, zodat de twee niet uit elkaar
 * gaan lopen zodra iemand de kop herschrijft.
 *
 * Er wordt niet gekeken WELKE kopsectie het is (hero, simple_hero, coll_hero
 * en lp_hero hebben allemaal een veld 'subtekst'): de eerste sectie met een
 * gevulde subtekst is in de praktijk altijd de paginakop.
 *
 * @param int $post_id De pagina.
 * @return string De subtekst, of '' als de pagina er geen heeft.
 */
function sokkies_pagina_intro( $post_id ) {
	$secties = get_post_meta( $post_id, 'secties', true );

	if ( ! is_array( $secties ) ) {
		return '';
	}

	foreach ( array_keys( $secties ) as $i ) {
		$tekst = get_post_meta( $post_id, 'secties_' . $i . '_subtekst', true );

		if ( is_string( $tekst ) && '' !== trim( $tekst ) ) {
			return trim( $tekst );
		}
	}

	return '';
}

/**
 * Een bruikbare afbeelding bij een pagina.
 *
 * Eerst de uitgelichte afbeelding; heeft de pagina die niet, dan de eerste
 * foto die in de secties staat. Zo krijgt een optiekaart vanzelf het juiste
 * beeld zonder dat iemand dezelfde foto nog een keer moet kiezen.
 *
 * LET OP: de secties-velden worden RUW uit postmeta gelezen, niet via
 * get_field(). De hele flexible content van een pagina ophalen om er één
 * bijlage-ID uit te vissen is onnodig zwaar, en de sleutels liggen vast
 * (secties_{index}_{veldnaam}).
 *
 * @param int $post_id De pagina.
 * @return int Bijlage-ID, of 0 als er niets te vinden is.
 */
function sokkies_pagina_foto( $post_id ) {
	$uitgelicht = get_post_thumbnail_id( $post_id );

	if ( $uitgelicht ) {
		return (int) $uitgelicht;
	}

	$secties = get_post_meta( $post_id, 'secties', true );

	if ( ! is_array( $secties ) ) {
		return 0;
	}

	foreach ( array_keys( $secties ) as $i ) {
		foreach ( array( 'foto', 'fotos', 'foto_groot' ) as $naam ) {
			$waarde = get_post_meta( $post_id, 'secties_' . $i . '_' . $naam, true );

			// Een galerijveld geeft een rij bijlage-ID's; daar pakken we de eerste van.
			if ( is_array( $waarde ) ) {
				$waarde = reset( $waarde );
			}

			if ( is_numeric( $waarde ) && (int) $waarde > 0 ) {
				return (int) $waarde;
			}
		}
	}

	return 0;
}

/**
 * De merknaam nooit laten vertalen.
 *
 * TranslatePress stuurt hele zinnen naar de vertaalmachine, en die behandelde
 * "Sokkies" als een gewoon woord: op de Duitse site werd het "Socken", op de
 * Franse "Chaussettes" en op de Engelse "Socks" of zelfs "Sockies". Dat raakte
 * 251 strings, van paginatitels ("Contact - Socken") tot lopende tekst
 * ("Team Socks") en zelfs "Sokki-Handschuhe" (= handschoenen) in het Duits.
 *
 * Dit filter is de oplossing aan de BRON: TranslatePress vervangt elk woord uit
 * deze lijst door een tijdelijke plaatshouder vóór het de zin naar de machine
 * stuurt en zet het er daarna onvertaald weer in
 * (class-machine-translator.php, rond regel 580 en 616). Zo kan de merknaam
 * niet meer sneuvelen bij een volgende vertaalronde.
 *
 * BEWUST IN CODE EN NIET IN HET TP-INSTELLINGENSCHERM: dat scherm schrijft naar
 * de database, en de database deployt hier niet mee. Zo reist de afspraak met
 * de push mee en geldt hij op elke omgeving.
 *
 * LET OP: dit werkt alleen vooruit. De strings die al verkeerd in de
 * woordenboeken staan zijn apart hersteld.
 */
function sokkies_merknaam_niet_vertalen( $woorden ) {
	$woorden[] = 'Sokkies';

	/* EN GEEN ENKEL BEDRAG. De vertaalmachine ziet "€7,99" als taal en maakte
	   er op de Engelse site "£7.99" van - en bij "€6,99" zelfs "£6.03", dus
	   inclusief een OMREKENING naar ponden. Sokkies rekent in euro's; een prijs
	   is geen tekst die vertaald mag worden.

	   De bedragen komen uit de staffels en uit "Vanaf … per paar", zodat de
	   lijst meegroeit als de prijzen wijzigen. Met deze uitsluiting vervangt
	   TranslatePress ze door een plaatshouder vóór het naar de machine gaat en
	   zet ze daarna onveranderd terug - de zin eromheen wordt dus gewoon
	   vertaald, alleen het bedrag blijft staan. */
	foreach ( sokkies_prijs_bedragen() as $bedrag ) {
		$woorden[] = $bedrag;
	}

	return $woorden;
}

/**
 * Alle bedragen die de site zelf publiceert, als tekst zoals ze in de pagina
 * staan. Wordt gebruikt om ze buiten de machinevertaling te houden.
 */
function sokkies_prijs_bedragen() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}

	$getallen = array();

	if ( function_exists( 'sokkies_staffel_matrix' ) ) {
		foreach ( sokkies_staffel_matrix() as $staffel ) {
			foreach ( (array) ( $staffel['rows'] ?? array() ) as $rij ) {
				if ( isset( $rij[1] ) ) {
					$getallen[] = (float) str_replace( ',', '.', (string) $rij[1] );
				}
			}
		}
	}

	/* De "Vanaf …"-prijs die op de kaarten en in het uitklapmenu staat. */
	$types = get_posts( array(
		'post_type'      => 'sokkies_soktype',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
		'fields'         => 'ids',
	) );
	foreach ( $types as $id ) {
		$ruw = function_exists( 'get_field' ) ? (string) get_field( 'prijs_vanaf', $id ) : '';
		if ( preg_match( '/([0-9]+)[.,]([0-9]{2})/', $ruw, $m ) ) {
			$getallen[] = (float) ( $m[1] . '.' . $m[2] );
		}
	}

	$cache = array();
	foreach ( array_unique( $getallen ) as $getal ) {
		/* Beide schrijfwijzen, want de komma- en de puntvariant komen allebei
		   in de pagina voor (Nederlands tegenover Engels). */
		$cache[] = '€' . number_format( $getal, 2, ',', '.' );
		$cache[] = '€' . number_format( $getal, 2, '.', ',' );
	}

	return $cache;
}

/**
 * Een bedrag schrijven zoals het in de taal van de bezoeker hoort.
 *
 * Nederlands, Duits en Frans gebruiken de komma als decimaalteken, Engels de
 * punt. Dat deed TranslatePress tot nu toe per ongeluk goed: het vertaalde
 * "€7,99" naar "€7.99". Nu de bedragen buiten de vertaling blijven (zie
 * hierboven) moet de opmaak hier gebeuren, anders staat er "€7,99" op de
 * Engelse site.
 *
 * Het euroteken blijft vooraan, ook in het Frans. Dat wijkt af van de Franse
 * gewoonte (7,99 €) maar is wel wat er nu op de site staat; dat veranderen is
 * een ontwerpkeuze en geen onderdeel van deze reparatie.
 */
function sokkies_bedrag( $getal ) {
	$taal = function_exists( 'sokkies_huidige_taal' ) ? sokkies_huidige_taal() : 'nl';

	return '€' . number_format( (float) $getal, 2, ( 'en' === $taal ? '.' : ',' ), ( 'en' === $taal ? ',' : '.' ) );
}
add_filter( 'trp_exclude_words_from_automatic_translation', 'sokkies_merknaam_niet_vertalen' );

/**
 * Een gedownload bestand niet door de vertaalmolen halen.
 *
 * Gravity Forms serveert een geuploade bijlage via index.php:
 * ?gf-download=...&form-id=..&field-id=..&entry-id=..&hash=.. Dat loopt dus
 * door de hele WordPress-bootstrap, inclusief de uitvoerbuffer van
 * TranslatePress. Die buffer parseert de respons als HTML en schrijft hem
 * daarna opnieuw weg - op een PNG is dat fataal.
 *
 * GEMETEN op een echte upload (3.png, 372.875 bytes): na translate_page()
 * bleven er 4.955 bytes over, veranderde de PNG-signatuur van
 * 89504e470d0a1a0a in 89504e470d0a0a0d en stonden er 12 keer &amp; in de
 * binary. Precies wat de browser liet zien: "cannot be displayed because it
 * contains errors". Een plaatje met XMP-metadata bevat <x:xmpmeta> en
 * <rdf:...>-tags, dus voor een HTML-parser ziet zo'n bestand er uit als een
 * document.
 *
 * trp_stop_translating_page is de haak die TranslatePress daar zelf voor
 * heeft (class-translation-render.php, begin van translate_page).
 *
 * LET OP: dit dekt alleen de downloadlink van Gravity Forms. Elke andere
 * route die binaire data via index.php uitstuurt loopt hetzelfde risico;
 * die moet hier dan ook bij.
 */
function sokkies_download_niet_vertalen( $stoppen ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- we kijken alleen of de parameter bestaat.
	if ( isset( $_GET['gf-download'] ) ) {
		return true;
	}

	return $stoppen;
}
add_filter( 'trp_stop_translating_page', 'sokkies_download_niet_vertalen' );

/**
 * Soktypes die als actie- of promotieproduct zijn gemarkeerd.
 *
 * Rick vroeg (feedback #38) om actieproducten — de kerstactie bijvoorbeeld —
 * uit de "Bekijk ook deze"-slider op de productpagina's te houden. Zo'n
 * product hoort bij een campagne en niet bij het vaste assortiment, dus het
 * is verwarrend als het als suggestie onder een gewone sok opduikt.
 *
 * Het veld 'promotie_type' op het soktype stuurt dit. LEEG = gewoon soktype,
 * dus zolang niemand iets kiest verandert er niets aan de site.
 *
 * BEWUST ALLEEN DE SUGGESTIESLIDER. De collectiepagina, het uitklapmenu en
 * de kaartenrijen blijven het actieproduct gewoon tonen — het moet immers
 * verkocht worden, en het heeft zijn eigen pagina. En een lijst die de
 * redacteur zélf heeft samengesteld wordt nooit gefilterd: wie het product
 * daar bewust in zet, krijgt het ook te zien.
 *
 * @return int[] Post-ID's, of een lege array.
 */
function sokkies_soktype_actie_ids() {
	static $ids = null;
	if ( null !== $ids ) {
		return $ids;
	}

	$ids = array();
	if ( ! function_exists( 'get_field' ) ) {
		return $ids;
	}

	$types = get_posts( array(
		'post_type'      => 'sokkies_soktype',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'no_found_rows'  => true,
		'fields'         => 'ids',
	) );
	foreach ( $types as $id ) {
		if ( trim( (string) get_field( 'promotie_type', $id ) ) !== '' ) {
			$ids[] = (int) $id;
		}
	}

	return $ids;
}

/**
 * Kleurkeuze -> CSS-class op de badge.
 *
 * 'beige' is de basisopmaak en heeft dus geen eigen class. 'rood' gebruikt de
 * bestaande .nieuw-regel; die naam is historisch (het was de vaste badge
 * "Nieuw"), maar hernoemen zou de opmaak veranderen van een badge die al live
 * staat, dus die blijft zoals hij is.
 *
 * De tekstkleur per vlak is op CONTRAST gekozen en niet op het oog: op geel,
 * groen, lichtblauw en roze leest de donkere huiskleur aantoonbaar beter dan
 * wit (ratio 8,5 tot 13,5 tegen 1,3 tot 2,1). Alleen "donker" krijgt witte
 * tekst (17,6).
 *
 * @param string $kleur Waarde uit het ACF-veld.
 * @return string Lege string = de standaardopmaak.
 */
function sokkies_badge_klasse( $kleur ) {
	$map = array(
		'beige'  => '',
		'rood'   => 'nieuw',
		'geel'   => 'badge-geel',
		'groen'  => 'badge-groen',
		'cyaan'  => 'badge-cyaan',
		'roze'   => 'badge-roze',
		'donker' => 'badge-donker',
	);
	return isset( $map[ $kleur ] ) ? $map[ $kleur ] : '';
}

/**
 * De badges die op een soktypekaart kunnen staan.
 *
 * Stond hardgecodeerd in twee sectietemplates (alleen Bestseller en Nieuw).
 * Rick vroeg of Sokkies er zelf bij kan zetten, dus de lijst komt nu uit
 * Website-instellingen > Productbadges.
 *
 * LEEG = DE OUDE TWEE. Een lege optie betekent hier "er is nog niets
 * ingevuld", niet "geen badges" — de opties-pagina staat in de database en
 * die reist niet mee met een deploy, dus zonder deze terugval zouden de
 * badges van Sportsokken, Reguliere sokken en Skisokken op live verdwijnen
 * zodra de code er staat.
 *
 * De SLEUTEL is sanitize_title() van de tekst, zodat de twee bestaande
 * waarden ('bestseller' en 'nieuw') blijven kloppen zonder migratie.
 * Keerzijde: wie een badge hernoemt, moet hem op de soktypes opnieuw kiezen.
 * Dat staat ook in de veldinstructie.
 *
 * @return array<string,array{label:string,klasse:string}>
 */
function sokkies_badges() {
	static $lijst = null;
	if ( null !== $lijst ) {
		return $lijst;
	}

	$lijst = array();
	$rijen = function_exists( 'get_field' ) ? get_field( 'badges', 'option' ) : null;
	if ( is_array( $rijen ) ) {
		foreach ( $rijen as $rij ) {
			$label = trim( (string) ( $rij['label'] ?? '' ) );
			if ( '' === $label ) {
				continue;
			}
			$lijst[ sanitize_title( $label ) ] = array(
				'label'  => $label,
				'klasse' => sokkies_badge_klasse( $rij['kleur'] ?? 'beige' ),
			);
		}
	}

	if ( ! $lijst ) {
		$lijst = array(
			'bestseller' => array( 'label' => 'Bestseller', 'klasse' => '' ),
			'nieuw'      => array( 'label' => 'Nieuw', 'klasse' => 'nieuw' ),
		);
	}

	return $lijst;
}

/**
 * De keuzelijst van het badge-veld vullen met de badges hierboven.
 */
function sokkies_badge_keuzes( $veld ) {
	$veld['choices'] = array();
	foreach ( sokkies_badges() as $sleutel => $badge ) {
		$veld['choices'][ $sleutel ] = $badge['label'];
	}
	return $veld;
}
add_filter( 'acf/load_field/key=field_soktype_badge', 'sokkies_badge_keuzes' );

/**
 * De badges van één soktype als kant-en-klare HTML.
 *
 * Eén plek, want de kaart wordt door twee secties gerenderd (de kaartenrij
 * en het collectie-grid) en die liepen anders uit elkaar.
 *
 * Een opgeslagen badge die niet meer in de lijst staat (verwijderd of
 * hernoemd) wordt overgeslagen in plaats van half gerenderd.
 *
 * @param int $type_id Post-ID van het soktype.
 * @return string Lege string als er niets te tonen is.
 */
function sokkies_badges_html( $type_id ) {
	$gekozen = function_exists( 'get_field' ) ? get_field( 'badge', $type_id ) : '';
	/* Vóór deze wijziging was het één waarde; (array) houdt die leesbaar. */
	$gekozen = array_filter( array_map( 'strval', (array) $gekozen ), 'strlen' );
	if ( ! $gekozen ) {
		return '';
	}

	$lijst = sokkies_badges();
	$html  = '';
	foreach ( $gekozen as $sleutel ) {
		if ( ! isset( $lijst[ $sleutel ] ) ) {
			continue;
		}
		$html .= '<span class="collection-badge' . ( $lijst[ $sleutel ]['klasse'] ? ' ' . esc_attr( $lijst[ $sleutel ]['klasse'] ) : '' ) . '">'
			. esc_html( $lijst[ $sleutel ]['label'] ) . '</span>';
	}

	return $html ? '<span class="collection-badges">' . $html . '</span>' : '';
}
