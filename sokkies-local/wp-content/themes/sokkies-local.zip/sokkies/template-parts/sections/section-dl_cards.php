<?php
/**
 * Sectie: Download-kaarten (.dl-cards) — 1:1 uit downloads.html. Kaart met
 * geüpload bestand linkt als download; anders de gekozen link; anders '#'.
 *
 * KOP: de sectie heeft een eigen "Kop boven deze groep", zodat downloads en
 * templates als twee zichtbaar gescheiden blokken op de pagina staan. De
 * downloadspagina gebruikte al TWEE van deze secties onder elkaar; ze misten
 * alleen een titel. Meer groepen = nog een blok met een eigen kop. Leeg = geen
 * kop en dus precies de weergave van hiervoor.
 */
$rijen = get_sub_field( 'kaarten' );
$standaard = array(
	array( 'titel' => 'Productbrochure 2026', 'tekst' => 'Het complete aanbod, materialen en mogelijkheden in één PDF.', 'link_label' => 'Aanvragen', 'link_url' => '#mis-niets' ),
	array( 'titel' => 'Ontwerpsjablonen', 'tekst' => 'Templates per soktype, klaar om je ontwerp in te plaatsen.', 'link_label' => 'Download', 'link_url' => '#' ),
	array( 'titel' => 'Prijslijst en staffels', 'tekst' => 'Actuele prijzen per oplage.', 'link_label' => 'Bekijk meer', 'link_url' => '#' ),
	array( 'titel' => 'Garenboek', 'tekst' => 'Alle beschikbare kleuren en garens op een rij.', 'link_label' => 'Download', 'link_url' => '#' ),
);
/* Alleen echte bestanden en externe links in een nieuw tabblad. Een anker
   (#mis-niets scrollt naar het formulier) of een nog lege stub (#) moet in
   HETZELFDE tabblad blijven: anders opent er een tweede kopie van de pagina
   in plaats van dat er iets gebeurt. */
/* function_exists-guard: de sectie kan in de bouwer twee keer op een
   pagina staan, en een tweede declaratie is een fatale fout. */
if ( ! function_exists( 'sokkies_dl_tabblad' ) ) {
function sokkies_dl_tabblad( $href ) {
	return ( '' !== $href && '#' !== substr( $href, 0, 1 ) ) ? ' target="_blank" rel="noopener"' : '';
}
}

$kop = trim( (string) get_sub_field( 'titel' ) );
?>
<section class="dl-cards">
  <div class="container">
    <?php if ( '' !== $kop ) : ?>
    <h2 class="dl-groep-kop"><?php echo esc_html( $kop ); ?></h2>
    <?php endif; ?>
    <?php if ( $rijen ) : ?>
    <div class="dl-cards-grid">
      <?php foreach ( $rijen as $teller => $rij ) :
        $href  = '#';
        $label = 'Download';
        $download = '';
        /* Bestand en afbeelding in de taal van de bezoeker; leeg = de
           Nederlandse. Beeld en bestand staan los: een Duitse PDF zonder
           Duitse cover krijgt gewoon de Nederlandse cover. */
        $bestand = sokkies_download_bestand( $rij );
        $foto    = sokkies_download_foto( $rij );
        if ( $bestand ) {
            $href = $bestand['url'];
            $download = ' download';
        } elseif ( ! empty( $rij['link']['url'] ) ) {
            $href  = $rij['link']['url'];
            $label = ! empty( $rij['link']['title'] ) ? $rij['link']['title'] : $label;
        }
      ?>
      <div class="dl-card" data-aos="fade-up" data-aos-delay="<?php echo (int) sokkies_aos_stap( $teller ); ?>">
        <div class="dl-card-img"><?php if ( $foto ) : ?><img src="<?php echo esc_url( $foto['url'] ); ?>" alt="<?php echo esc_attr( $rij['titel'] ); ?>"><?php else : ?><span class="dl-ph">Image placeholder</span><?php endif; ?></div>
        <div class="dl-card-body">
          <h3><?php echo esc_html( $rij['titel'] ); ?></h3>
          <p><?php echo esc_html( $rij['tekst'] ); ?></p>
          <a href="<?php echo esc_url( $href ); ?>"<?php echo sokkies_dl_tabblad( $href ); ?> class="dl-link"<?php echo $download; ?>>
            <svg xmlns="http://www.w3.org/2000/svg" width="12.199" height="9.39" viewBox="0 0 12.199 9.39">                   <g transform="translate(0.5 0.683)">                     <path d="M1289.087,543v4h11" transform="translate(-1289.087 -542.997)" fill="none" stroke="#28121b" stroke-linecap="round" stroke-width="1"/>                     <path d="M1216,541.6c.392.226,4,4,4,4l-4,4" transform="translate(-1209 -541.602)" fill="none" stroke="#28121b" stroke-linecap="round" stroke-width="1"/>                   </g>                 </svg>
            <?php echo esc_html( $label ); ?>
          </a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else : ?>
    <div class="dl-cards-grid">
      <?php foreach ( $standaard as $i => $rij ) : ?>
      <div class="dl-card" data-aos="fade-up" data-aos-delay="<?php echo (int) sokkies_aos_stap( $i ); ?>">
        <div class="dl-card-img"><span class="dl-ph">Image placeholder</span></div>
        <div class="dl-card-body">
          <h3><?php echo esc_html( $rij['titel'] ); ?></h3>
          <p><?php echo esc_html( $rij['tekst'] ); ?></p>
          <a href="<?php echo esc_url( $rij['link_url'] ); ?>"<?php echo sokkies_dl_tabblad( $rij['link_url'] ); ?> class="dl-link">
            <svg xmlns="http://www.w3.org/2000/svg" width="12.199" height="9.39" viewBox="0 0 12.199 9.39">                   <g transform="translate(0.5 0.683)">                     <path d="M1289.087,543v4h11" transform="translate(-1289.087 -542.997)" fill="none" stroke="#28121b" stroke-linecap="round" stroke-width="1"/>                     <path d="M1216,541.6c.392.226,4,4,4,4l-4,4" transform="translate(-1209 -541.602)" fill="none" stroke="#28121b" stroke-linecap="round" stroke-width="1"/>                   </g>                 </svg>
            <?php echo esc_html( $rij['link_label'] ); ?>
          </a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>
